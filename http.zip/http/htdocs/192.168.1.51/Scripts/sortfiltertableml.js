var SORT_LANG ="en";

var ALARM_TEXT_COLUMN = 4;

var BGZ_MASTERS_NAME_COLUMN =  1;
var BGZ_MASTERS_COMMENT_COLUMN = 3;

var BGZ_MEMBERS_PNIO_NAME_COLUMN =  1;
var BGZ_MEMBERS_PNIO_COMMENT_COLUMN = 6;

var BGZ_MEMBERS_DP_NAME_COLUMN =  1;
var BGZ_MEMBERS_DP_COMMENT_COLUMN = 5;


var BGZ_MODULES_NAME_COLUMN = 2;
var BGZ_MODULES_COMMENT_COLUMN = 7;

var BGZ_SUBMODS_NAME_COLUMN = 2;
var BGZ_SUBMODS_COMMENT_COLUMN = 7;

var FILTER_EMPTY_TEXT='<DIV class="filtertextempty" align="center"><BR>No Entries found</DIV>';

var SORT_COLUMN_INDEX = 0;  // First-tier sort column

var DATE_COLUMN_INDEX = 0;  // Column index holding the date part of the
                            // second-tier sort function

var TIME_COLUMN_INDEX = 0;  // Column index holding the time part of the
                            // second-tier sort function

var SECOND_SORT_FUNCTION = 0;

var IN_SECOND_SORT = 0;     // To avoid (endless) recursion

var sort_from_init = 0;

function isSortable(col){

 var url;
 url = top.location.href;

 if( (url.search(/PriNav=Alarm/) != -1) && (col == ALARM_TEXT_COLUMN) ) return false;
 if(url.search(/PriNav=Bgz/) != -1){
    if(url.search(/BgzView=Members/) != -1){
        if((url.search(/BgzType=DP/) != -1) && ( (col == BGZ_MEMBERS_DP_NAME_COLUMN) || (col == BGZ_MEMBERS_DP_COMMENT_COLUMN) ) ){
           return false;
        }
        if((url.search(/BgzType=PNIO/) != -1) && ( (col == BGZ_MEMBERS_PNIO_NAME_COLUMN) || (col == BGZ_MEMBERS_PNIO_COMMENT_COLUMN) ) ){
           return false;
        }
    }
    if( (url.search(/BgzView=Modules/) != -1)    && ( (col == BGZ_MODULES_NAME_COLUMN) || (col == BGZ_MODULES_COMMENT_COLUMN) ) )
        return false;
    if( (url.search(/BgzView=Submodules/) != -1) && ( (col == BGZ_SUBMODS_NAME_COLUMN) || (col == BGZ_SUBMODS_COMMENT_COLUMN) ) )
        return false;
    if( (url.search(/BgzView/) == -1)            && ( (col == BGZ_MASTERS_NAME_COLUMN) || (col == BGZ_MASTERS_COMMENT_COLUMN) ) )
        return false;
 }

 return true;

}

function ts_DisplayErrorMessage()
{
 if (!document.getElementsByTagName) return;
    var tbls = document.getElementsByTagName("body");
    var thisbdy;
    for (var ti=0;ti<tbls.length;ti++) {
        thisbdy = tbls[ti];
        if ( (thisbdy.className == "alarmtablebody") || (thisbdy.className == "bgztablebody") ){
            //initTable(thisTbl.id);
            thisbdy.innerHTML= FILTER_EMPTY_TEXT;
        }
    }
}

// because of sort-function - wenn die gesamte Tabelle umkopiert wird,
// funktioniert das onclick-Element in den Tabellenüberschriften nicht mehr.
// Deshalb müssen die Spaltenueberschriften nochmal mit dem onclick-Event versehen werden.
function sortables_init_fb_update()
{
    var thisTbl;
    if (!document.getElementsByTagName) return;
    var tbls = document.getElementsByTagName("table");
    for (var ti=0;ti<tbls.length;ti++) {
        thisTbl = tbls[ti];
        if (((' '+thisTbl.className+' ').indexOf("ContentTable") != -1) ) {
            ts_makeSortable(thisTbl);
        }
    }
}

function sortables_init(lang, filternoentry)
{
    // because of autom. Update
    if( ( (window == top.frames[0]) || (top.frames.length == 0)) && (top.frames.length != 1 ) )
    {
       if(lang != "dummy"){
         top.sort_lang = lang;
         top.sort_filternoentry = filternoentry;
       }
    }
    else{
        // in update page
       lang = top.sort_lang;
       filternoentry = top.sort_filternoentry;
    }
    // Find all tables with class sortable and make them sortable
    //a=b;
    var thisTbl;
    if( (lang != null) && (lang != "") && (lang != "dummy"))
    {
        SORT_LANG = lang;
    }
    if( (filternoentry != null) && (filternoentry!= "") && (filternoentry != "dummy"))
    {
        FILTER_EMPTY_TEXT = filternoentry;
    }
    if (!document.getElementsByTagName) return;
    var tbls = document.getElementsByTagName("table");
    for (var ti=0;ti<tbls.length;ti++) {
        thisTbl = tbls[ti];
        if (((' '+thisTbl.className+' ').indexOf("ContentTable") != -1) ) {
            //initTable(thisTbl.id);
            ts_makeSortable(thisTbl);
        }
    }

        // cookie sort
    var page = ts_getPage();
    var cName = "siemens_automation_sort_" + page;
    var value = getSortCookie(cName);
    if(value != "")
    {
         var p = value.split("__");
         var col = document.getElementById(p[0]);
         if(col != null)
         {
           if( ( (window == top.frames[0]) || (top.frames.length == 0)) && (top.frames.length != 1 ) )
           {
             top.sort_from_init = 1;
           }
           col.onclick();
         }
    }

    if(lang != "dummy"){    // for autom. Update
        initfilter(); // init filter, select first table row and load details
    }
}

function ts_makeSortable(table)
{
    if (table.rows && table.rows.length > 0) {
        var firstRow = table.rows[0];
    }
    if (!firstRow) return;

    // We have a first row: assume it's the header, and make its contents clickable links
    for (var i=0;i<firstRow.cells.length;i++) {
        var cell = firstRow.cells[i];
        //if( (cell.className != "BGZ_No_Sort_Header") && (cell.className != "Filebrowser_No_Sort_Header") ){
        if (((' '+cell.className+' ').indexOf("No_Sort_Header") == -1) ) {
          var txt = ts_getInnerText(cell);

          // do not filter alarm text in jp or zh (chinese)
          if( isSortable(i) || ((SORT_LANG != "zh") && (SORT_LANG != "ja")))
          {
              if(cell.className.indexOf("_sort") == -1) {
                cell.className= cell.className + "_sort";
                /* do both : href and onclick -> some browser ignore CURSOR: hand; -> CLA: done*/
                cell.innerHTML = '<a href="#" class="sortheader" onclick="return false;">'+txt+'<span class="sortarrow"></span></a>';
              }
              cell.onclick=ts_resortTablecll;


          }
        }
    }
}

function ts_getInnerText(el)
{
    if (typeof el == "string") return el;
    if (typeof el == "undefined") { return el };
    if (el.innerText) return el.innerText;  //Not needed but it is faster
    var str = "";

    var cs = el.childNodes;
    var l = cs.length;
    for (var i = 0; i < l; i++) {
        switch (cs[i].nodeType) {
            case 1: //ELEMENT_NODE
                str += ts_getInnerText(cs[i]);
                break;
            case 3: //TEXT_NODE
                var texttest = cs[i].nodeValue;
                if( (texttest.charAt(0) != '<') && (texttest.charAt(1) != '<')){
                     str += texttest;
                }
                break;
        }
    }
    return str;
}

var FILTER_NAME;
var FILTER_VALUE;

function initfilter()
{
    FILTER_NAME = parent.filtername;
    FILTER_VALUE = parent.filtervalue;
    {
        ts_filter();
    }
}

function ts_filter()
{
    var thisTbl;
    if (!document.getElementsByTagName) return;
    var tbls = document.getElementsByTagName("table");
    for (var ti=0;ti<tbls.length;ti++) {
        thisTbl = tbls[ti];
        if (((' '+thisTbl.className+' ').indexOf("ContentTable") != -1) ) {
            //initTable(thisTbl.id);
                ts_filterTable(thisTbl);
        }
    }
}

function ts_resortTablecll()
{
    //if( ( (window == top.frames[0]) || (top.frames.length == 0)) && (top.frames.length != 1 ) ){
    //   top.sort = ts_getInnerText(this);
    //}
    //else if( (window != top.frames[0]) && (top.frames.length == 1 ) )
    //{
    //   // filebrowser
    //   top.sort = ts_getInnerText(this);
    //}

    // get link
    for (var ci=0;ci<this.childNodes.length;ci++)
    {
        if(this.childNodes[ci].tagName =='A')
        {
            return ts_resortTable(this.childNodes[ci], this);
        }
    }
    return null;
}


// match the contents of a column to determine the appropriate sort function
function ts_getsortfunction( item , item_class )
{
    var sortfunction;

    if(item_class == "ContentTableField_IP"){
        // its necessary to treat the ip-address column different, because in this column
        // there a 2 different types possible:
        // 1. ip-address string
        // 2. possibly the string "nicht verfuegbar" (also in other languages)
        sortfunction = ts_sort_ip_address;
    }
    else if( (item_class == "ContentTableField_Address") || ( item_class == "BGZ_Details_Left") || (item_class == "ContentTableField_Comment") ){
        // its necessary to treat input and output addresses, because they can be
        // strings or numbers (AP00746424)
        sortfunction = ts_sort_caseinsensitive_ml;
    }
    else if(item_class == "ContentTableField_Filesize"){
        sortfunction = ts_sort_numeric;
    }
    else {
        sortfunction = ts_sort_caseinsensitive_ml;

        if (item.match(/^\d\d[:]\d\d[:]\d\d/)) sortfunction = ts_sort_time;
        if (item.match(/^\d\d[\/\-\.]\d\d[\/\-\.]\d\d\d\d$/)) sortfunction = ts_sort_date;
        if (item.match(/^\d\d[\/\-\.]\d\d[\/\-\.]\d\d$/)) sortfunction = ts_sort_date;
        if (item.match(/^\d\d\d\d[\/\-\.]\d\d[\/\-\.]\d\d$/)) sortfunction = ts_sort_date;
        if (item.match(/^\d\d[:]\d\d[:]\d\d\s(am|pm)?\s?\d\d[\/\-\.]\d\d[\/\-\.]\d\d\d\d$/)) sortfunction = ts_sort_date_time;
        if (item.match(/^\d\d[:]\d\d[:]\d\d\s(am|pm)?\s?\d\d[\/\-\.]\d\d[\/\-\.]\d\d$/)) sortfunction = ts_sort_date_time;
        if (item.match(/^\d\d[:]\d\d[:]\d\d\s(am|pm)?\s?\d\d\d\d[\/\-\.]\d\d[\/\-\.]\d\d$/)) sortfunction = ts_sort_date_time;
        if (item.match(/^[Â£$â¬]/)) sortfunction = ts_sort_currency;
        if (item.match(/^[\d]+$/)) sortfunction = ts_sort_numeric;
        if (item.match(/^[X\d]\s*/)) sortfunction = ts_sort_numeric;
		if (item.match(/-{3}/)) sortfunction = ts_sort_numeric; //RQ2301300, zero is represented as "---" and should be sorted as a number
    }

    return sortfunction;
}


function is_empty_column(table,number_of_rows, column)
{
  for (var row_index = 1; row_index < number_of_rows; row_index++)
  {
	if (/\S/.test(ts_getInnerText(table.rows[row_index].cells[column]))) //content isn't only empty spaces
	{
	  return false;
	}
  }
  return true;
}

function all_column_cells_have_same_value(table,number_of_rows,column)
{
  var repeated_value = ts_getInnerText(table.rows[1].cells[column]);

  for (var row_index = 2; row_index < number_of_rows; row_index++)
  {
	if (repeated_value != ts_getInnerText(table.rows[row_index].cells[column])) //content isn't all same values
	{
	  return false;
	}
  }
  return true;
}

function get_span_from_lnk(lnk)
{
  var span;

  for (var ci=0;ci<lnk.childNodes.length;ci++) 
  {
        if (lnk.childNodes[ci].tagName && 
			lnk.childNodes[ci].tagName.toLowerCase() == 'span') 
		{
		  span = lnk.childNodes[ci];
		}
  }

  return span;
}

function get_column_from_table(lnk,table)
{
  var column;

  for(column=0; column<table.rows[0].cells.length; column++)
  {
        if(ts_getInnerText(lnk) == ts_getInnerText(table.rows[0].cells[column]) )
		{
		  return column;
        }
  }

  return column;
}

function get_second_sort_function(table,itm,itm_class)
{
    var undefined_index = table.rows[1].cells.length;
    DATE_COLUMN_INDEX = undefined_index;
    TIME_COLUMN_INDEX = undefined_index;

    for ( var i = 0; i < table.rows[1].cells.length; i++ ) 
	{
        itm = ts_getInnerText(table.rows[1].cells[i]);
        itm_class = table.rows[1].cells[i].className;

        var sf = ts_getsortfunction( itm, itm_class );

        if ( sf == ts_sort_date ) 
		{
            DATE_COLUMN_INDEX = i;
        }
        else if ( sf == ts_sort_time ) 
		{
            TIME_COLUMN_INDEX = i;
        }
    }


	if ((TIME_COLUMN_INDEX == undefined_index) &&
         (DATE_COLUMN_INDEX == undefined_index )) 
	{
        return null;
    }
    else if ( TIME_COLUMN_INDEX == undefined_index ) {

	  if ( DATE_COLUMN_INDEX != SORT_COLUMN_INDEX ) {
            return ts_sort_date;
        }
        // else first-tier sort is "date", do nothing
    }
    else if ( DATE_COLUMN_INDEX == undefined_index ) {

        if ( TIME_COLUMN_INDEX != SORT_COLUMN_INDEX ) {
            return ts_sort_time;
        }
        // else first-tier sort is "time", do nothing
    }
    else {
        // both date and time colums present
        if (TIME_COLUMN_INDEX == SORT_COLUMN_INDEX ) {
            return ts_sort_date;
        }
        else if ( DATE_COLUMN_INDEX == SORT_COLUMN_INDEX ) {
            return ts_sort_time;
        }
        else {  // first-tier sort has nothing to do with date or time
            return ts_sort_date_time;
        }
    }

	return null;
}

function get_change_value(span,td_to_sort,page)
{
    var arrow;

    var set_sort_sequence = "";
    var set_sort_col = "";
    var cName = "siemens_automation_sort_" + page;
    var value = getSortCookie(cName);
    var change = 0;

    if(value != "")
    {
         var p = value.split("__");
         set_sort_sequence = p[1];
         set_sort_col      = p[0];
    }
    if( ( ( (window == top.frames[0]) || (top.frames.length == 0)) && (top.frames.length != 1 ) ) ||
       ((window != top.frames[0]) && (top.frames.length == 1 ) ) )
    {
        if((set_sort_col == td_to_sort.id) && (top.sort_from_init == 0) )
        {
            change = 1;
        }
        else
        {
            top.sort_from_init = 0;
            change = 0;
            if(set_sort_col != td_to_sort.id)
            {
               span.setAttribute("sortdir", 'down');
            }
            else
            {
               span.setAttribute("sortdir", set_sort_sequence);
            }
        }
    }
    else
    {
       // in update page
       span.setAttribute("sortdir", set_sort_sequence);
       change = 0;
    }

	return change;
}

function get_arrow_element(span,change)
{
    if(change == 0)
    {
       if(span.getAttribute("sortdir") == 'up')
       {
          arrow = '<img src="/Images/sortup.gif" align="middle" border="0" >';
          span.setAttribute('sortdir','up');
       }
       else
       {
          arrow = '<img src="/Images/sortdown.gif" align="middle" border="0" >';
          span.setAttribute('sortdir','down');
       }
    }
    else if(change == 1)
    {
      if(span.getAttribute("sortdir") == 'down') {
        arrow = '<img src="/Images/sortup.gif" align="middle" border="0" >';
        span.setAttribute('sortdir','up');
      } else {
        arrow = '<img src="/Images/sortdown.gif" align="middle" border="0" >';
        span.setAttribute('sortdir','down');
      }
    }
	
	return arrow;
}

function ts_resortTable(lnk, td_to_sort)
{
	var span = get_span_from_lnk(lnk);
    var spantext = ts_getInnerText(span);

    var td = lnk.parentNode;

    var table = getParent(td,'TABLE');
	var column = get_column_from_table(lnk,table);	 
    SORT_COLUMN_INDEX = column;

	if (table.rows.length <= 2 || 
		is_empty_column(table, table.rows.length, column) ||
		all_column_cells_have_same_value(table, table.rows.length, column))
	{
	  span.innerHTML = ""; //do not add the arrow
	  return;
	}

	var itm = ts_getInnerText(table.rows[1].cells[column]);
    var itm_class = table.rows[1].cells[column].className;
    var sortfn = ts_getsortfunction( itm,itm_class );

    var second_sort_fn = get_second_sort_function(table,itm,itm_class);
    SECOND_SORT_FUNCTION = second_sort_fn;

    var newRows = new Array();
    for (var j=1;j<table.rows.length;j++) 
	{ 
	  newRows[j-1] = table.rows[j]; // table.rows.length-1 ignore filling row
	} 

    newRows.sort(sortfn);

    var page = ts_getPage();

	var change = get_change_value(span,td_to_sort,page);
    var arrow = get_arrow_element(span,change);

	if(change == 0 && span.getAttribute("sortdir") == 'up')
	{
	  newRows.reverse();
	}
    else if(change == 1 && span.getAttribute("sortdir") == 'down' )
    {
	  newRows.reverse();
    }

    if( ( ( (window == top.frames[0]) || (top.frames.length == 0)) && (top.frames.length != 1 ) )  ||
        (   (window != top.frames[0]) && (top.frames.length == 1) ) )
    {
       // not in update page
       var sort_cookie = "siemens_automation_sort_" + page + "=" + td_to_sort.id + "__" + span.getAttribute("sortdir") +"; path=/";
       window.top.document.cookie = sort_cookie;
    }


    // We appendChild rows that already exist to the tbody, so it moves them rather than creating new ones
    // don't do sortbottom rows
    for (var i=0;i<newRows.length;i++) 
	{
	  if (!newRows[i].className ||
		  (newRows[i].className && (newRows[i].className.indexOf('sortbottom') == -1))
		 )
		  {
			  table.tBodies[0].appendChild(newRows[i]);
		  }
    }

    // do sortbottom rows only
    for (i=0;i<newRows.length;i++) { 
	  if (newRows[i].className && 
		  (newRows[i].className.indexOf('sortbottom') != -1)) 
	  {
		table.tBodies[0].appendChild(newRows[i]);
	  }
	}

    // Delete any other arrows there may be showing
    var allspans = document.getElementsByTagName("span");
    for (var ci=0;ci<allspans.length;ci++) {
        if (allspans[ci].className == 'sortarrow') {
            if (getParent(allspans[ci],"table") == getParent(lnk,"table")) { // in the same table as us?
                allspans[ci].innerHTML = "";
            }
        }
    }

    span.innerHTML = arrow;
}

function ts_preselect(table)
{
    // preselection - select first table row and load details
    if(table.tBodies[0].rows.length>2 && table.tBodies[0].rows[1].onclick != null)
    {
        table.tBodies[0].rows[1].onclick();
    }
    else { // for Bgz tables
         var cols = table.tBodies[0].rows[1].getElementsByTagName("a");
         for(var i=0;i<cols.length; i++){
            if(cols[i].className == "BGZ_Link" && cols[i].onclick != null){
                cols[i].onclick();
            }
         }

    }
    return;
 }

function ts_filterTable(table)
{
    // get the span


    // Work out a type for the column
    // var firstRow = new Array();   is not used
    var newRows = new Array();
    var FILTER_INDEX = -1;
    var filtername;
    var filtervalue;
    var lastRow;
    var i;

    if((FILTER_NAME == null)
        ||(FILTER_NAME == "")
        ||(FILTER_VALUE == null)
        ||(FILTER_VALUE == ""))
    {
        // do not filter
        // only preselection
        ts_preselect(table);
        return;
    }

    // for (i=0;i<table.rows[0].length;i++) { firstRow[i] = table.rows[0][i]; }
    for (var j=1;j<table.rows.length/*-1*/;j++) { newRows[j-1] = table.rows[j]; }   /* ignore filling row */

    /* do filling row */
    //lastRow = table.rows[table.rows.length-1];

    for (i = 0; i<table.rows[0].cells.length;i++)
    {
        filtername = ts_getInnerText(table.rows[0].cells[i]);
        if(filtername.indexOf(FILTER_NAME)!= -1)
        {
            FILTER_INDEX = i;
                break;
        }
    }
    if (FILTER_INDEX == -1 )
    {
        // only preselection
        ts_preselect(table);
        return;
    }

    // We appendChild rows that already exist to the tbody, so it moves them rather than creating new ones
    // don't do sortbottom rows
    var bfirst = true;

    for (i=0;i<newRows.length;i++) {
    if (!newRows[i].className ||
        (newRows[i].className && (newRows[i].className.indexOf('sortbottom') == -1)))
        {
           filtervalue = ts_getInnerText(newRows[i].cells[FILTER_INDEX]);
            if (filtervalue.indexOf(FILTER_VALUE) != -1)
            {
                table.tBodies[0].appendChild(newRows[i]);
                if(bfirst == true)
                {
                    bfirst = false;
                    if(table.tBodies[0].lastChild.onclick && table.tBodies[0].lastChild.onclick != undefined)
                        table.tBodies[0].lastChild.onclick();
                    else {
                        var cell_class;
                        for(var count=0; count<table.tBodies[0].lastChild.cells.length; count++){
                            if( (table.tBodies[0].lastChild.cells[count].className == "BGZ_Details") &&
                                (table.tBodies[0].lastChild.cells[count].firstChild.firstChild.onclick != undefined) ){
                                table.tBodies[0].lastChild.cells[count].firstChild.firstChild.onclick();
                            }
                        }
                    }  // end else
                }
            }
            else
            {
                table.tBodies[0].removeChild(newRows[i]);
            }
        }
    }

    // append filling row
    //table.tBodies[0].appendChild(lastRow);

    // do sortbottom rows only
    for (i=0;i<newRows.length;i++) { if (newRows[i].className && (newRows[i].className.indexOf('sortbottom') != -1)) table.tBodies[0].appendChild(newRows[i]);}

    // preselection
    ts_preselect(table);

    if(table.tBodies[0].rows.length<=1/*2*/) // filling row
    {
        ts_DisplayErrorMessage();
    }

    return;
}

function getParent(el, pTagName)
{
    if (el == null) return null;
    else if (el.nodeType == 1 && el.tagName.toLowerCase() == pTagName.toLowerCase())    // Gecko bug, supposed to be uppercase
        return el;
    else
        return getParent(el.parentNode, pTagName);
}


// Second-tier sort function, called when the designated first-tier
// sort function results in equality
function ts_second_sort(a,b)
{
    var tmp_column_index = SORT_COLUMN_INDEX;
    var result = 0;

    IN_SECOND_SORT = 1; // important to avoid recursion

    if ( SECOND_SORT_FUNCTION == null ) {
        return 0;  // first-tier equality stands
    } else if ( SECOND_SORT_FUNCTION == ts_sort_time ) {
        SORT_COLUMN_INDEX = TIME_COLUMN_INDEX;
        result = ts_sort_time(a,b);
    } else if (SECOND_SORT_FUNCTION == ts_sort_date ) {
        SORT_COLUMN_INDEX = DATE_COLUMN_INDEX;
        result = ts_sort_date(a,b);
    } else {
        SORT_COLUMN_INDEX = DATE_COLUMN_INDEX;
        result = ts_sort_date(a,b);
        if ( result == 0 ) {
            SORT_COLUMN_INDEX = TIME_COLUMN_INDEX;
            result = ts_sort_time(a,b);
        }
    }

    SORT_COLUMN_INDEX = tmp_column_index;
    IN_SECOND_SORT = 0;
    return result;
}



function ts_sort_date_time(a,b)
{
    var aa = check_parameter(a);
    var bb = check_parameter(b);

    // Early out for ".."
    if (aa == "")
    {
        return -1;
    }
    else if (bb == "")
    {
        return 1;
    }

    var lastIndexOfSpace = aa.lastIndexOf(" ");
    var atime = aa.substring(0, lastIndexOfSpace);
    var adate = aa.substring(lastIndexOfSpace+1);

    lastIndexOfSpace = bb.lastIndexOf(" ");
    var btime = bb.substring(0, lastIndexOfSpace);
    var bdate = bb.substring(lastIndexOfSpace+1);

    // Expected return values of the sorting functions
    // a is less than b: -1
    // a is greater than b: 1
    // a is equal to b: 0

    // If the dates do match we need to compare the times.
    // If they don't match there is no need to check the times.
    var dateresult = ts_sort_date(adate, bdate);
    if (dateresult == 0)
    {
        return ts_sort_time(atime, btime);
    }
    else
    {
        return dateresult;
    }
}

function check_parameter(parameter)
{
    if (typeof parameter == "string" && parameter.length > 0)
    {
        return parameter;
    }
    else if (typeof parameter == "undefined" || parameter.length == 0)
    {
        return "0";
    }
    else
    {
        return ts_getInnerText(parameter.cells[SORT_COLUMN_INDEX]);
    }
}

function ts_sort_time(a,b)
{
    var aa = check_parameter(a);
    var bb = check_parameter(b);

    if(SORT_LANG == "en")
    {
        // handle am, pm
        if (aa.match(/(am)/))
            aa = "0" + aa;
        else
            aa = "1" + aa;
        // handle am, pm
        if (bb.match(/(am)/))
            bb = "0" + bb;
        else
            bb = "1" + bb;
    }

    if ( (aa==bb) &&
         (SECOND_SORT_FUNCTION != null) &&
         (!IN_SECOND_SORT) ) {
        return ts_second_sort(a, b);
    }
    else if (aa==bb) {
        return 0;
    }
    if (aa<bb) return -1;
    return 1;
}

function getComparableDate(parameter, delimeter)
{
    var date, year;

    if (parameter.length == 10)
    {
        if(parameter.substr(2,1)==delimeter)
        {
            date = parameter.substr(6,4)+parameter.substr(3,2)+parameter.substr(0,2);
        }
        else
        {
            date = parameter.substr(0,4)+parameter.substr(5,2)+parameter.substr(8,2);
        }
    }
    else
    {
        year = parameter.substr(6,2);
        if (parseInt(year) < 50)
        {
            year = '20'+year;
        }
        else
        {
            year = '19'+year;
        }
        date = year+parameter.substr(3,2)+parameter.substr(0,2);
    }

    return date;
}

function ts_sort_date(a,b)
{
    // y2k notes: two digit years less than 50 are treated as 20XX, greater than 50 are treated as 19XX
    var aa = check_parameter(a);
    var bb = check_parameter(b);
    var dt1, dt2, yr;

    switch(SORT_LANG)
    {
        case "de":
        case "it":
        case "fr":
        case "es":
        case "tr":
        case "ru":
            dt1 = getComparableDate(aa, ".");
            dt2 = getComparableDate(bb, ".");
            break;

        case "pt":
            dt1 = getComparableDate(aa, "/");
            dt2 = getComparableDate(bb, "/");
            break;

        case "ko":
            dt1 = getComparableDate(aa, "-");
            dt2 = getComparableDate(bb, "-");
            break;

        case "zh":
        case "ja":
            dt1 = getComparableDate(aa, "/");
            dt2 = getComparableDate(bb, "/");
            break;

        case "en":
        default:
            // MM.TT.YYYY  here only en-us
            dt1 = aa.substr(6,4)+aa.substr(0,2)+aa.substr(3,2);
            dt2 = bb.substr(6,4)+bb.substr(0,2)+bb.substr(3,2);
            break;
    }


    if ( (dt1==dt2) &&
         (SECOND_SORT_FUNCTION != null) &&
         (!IN_SECOND_SORT) ) {
        return ts_second_sort(a, b);
    }
    else if ( dt1==dt2) {
        return 0;
    }
    if (dt1<dt2) return -1;
    return 1;
}

function ts_sort_currency(a,b)
{
    var result;
    var aa = ts_getInnerText(a.cells[SORT_COLUMN_INDEX]).replace(/[^0-9.]/g,'');
    var bb = ts_getInnerText(b.cells[SORT_COLUMN_INDEX]).replace(/[^0-9.]/g,'');
    result = parseFloat(aa) - parseFloat(bb);

    if ( (result == 0) &&
              (SECOND_SORT_FUNCTION != null) &&
              (!IN_SECOND_SORT) ) {
        return ts_second_sort(a, b);
    }

    return result;
}

function ts_sort_numeric(a,b)
{
    var result;

    var aa = parseFloat(ts_getInnerText(a.cells[SORT_COLUMN_INDEX]));
    if (isNaN(aa))
    {
        aa = ts_get_interface_numbervalue(a);
    }

    var bb = parseFloat(ts_getInnerText(b.cells[SORT_COLUMN_INDEX]));
    if (isNaN(bb))
    {
        bb = ts_get_interface_numbervalue(b);
    }

    result = aa-bb;

    if ( (result == 0) &&
         (SECOND_SORT_FUNCTION != null) &&
         (!IN_SECOND_SORT) ) {
        return ts_second_sort(a, b);
    }

    return result;
}

function ts_get_interface_numbervalue(value)
{
    var result;

    var temp = ts_getInnerText(value.cells[SORT_COLUMN_INDEX])
    if (temp.match(/^X\d+\sP\d+\s*/))
    {
        result = parseInt(temp.substring(1, temp.length)) - 1;
        var portNumber = temp.match(/P\d+/)[0].substring(1, temp.length);
        result = (result << 8) + 0x8000 + parseInt(portNumber);
    }
    else if (temp.match(/^X\d+\s*/))
    {
        var string_result = temp.replace(/[^\d]/g, '');
        result = parseInt(string_result,10);
    }
    else
    {
        result = 0;
    }

    return result;
}


// Entfernen von Leerzeichen und Steuerzeichen vor dem eigentlichen String
function ts_clean_string(a)
{
    return a.replace(/^\s+/, "");
}

function ts_sort_caseinsensitive_ml(a,b)
{
    var aa = ts_getInnerText(a.cells[SORT_COLUMN_INDEX]).toLowerCase();
    var bb = ts_getInnerText(b.cells[SORT_COLUMN_INDEX]).toLowerCase();
    // Entfernung der Leerzeichen und Steuerzeichen vor dem String
    aa = ts_clean_string(aa);
    bb = ts_clean_string(bb);

	//Avoiding unsable sorting algorithms from scrambling the rows while sorting
	if (aa.length == 0 && bb.length == 0)
	{
	  if (a.rowIndex < b.rowIndex)
	  {
		return -1;
	  }
	  else if (a.rowIndex > b.rowIndex)
	  {
		return 1;
	  }
	  else 
	  {
		return 0;
	  }

	}

	if (aa.length == 0)
	{
	  return -1; // means for example: aa: " " comes before bb: "abc"
	}

	if (bb.length == 0)
	{
	  return 1; // means for example: bb: " " comes before aa: "abc"
	}

	//Regular case where both strings have characters

    if(SORT_LANG == "de")
    {
        // german
        aa = aa.replace(/Ã¤/g,"a{");
        aa = aa.replace(/Ã¶/g,"o{");
        aa = aa.replace(/Ã¼/g,"u{");
        aa = aa.replace(/Ã/g,"ss");

        bb = bb.replace(/Ã¤/g,"a{");
        bb = bb.replace(/Ã¶/g,"o{");
        bb = bb.replace(/Ã¼/g,"u{");
        bb = bb.replace(/Ã/g,"ss");
    }
    else if (SORT_LANG == "fr")
    {
        // france
        aa = aa.replace(/Ã /g,"a{");
        aa = aa.replace(/Ã§/g,"c{");
        aa = aa.replace(/Ã©/g,"e{");
        aa = aa.replace(/Ã¨/g,"e{{");
        aa = aa.replace(/Ãª/g,"e{{{");
        aa = aa.replace(/Ã«/g,"e{{{{");
        aa = aa.replace(/Ã®/g,"i{");
        aa = aa.replace(/Ã¯/g,"i{{");
        aa = aa.replace(/Ã´/g,"o{");
        aa = aa.replace(/Å/g,"o{");
        aa = aa.replace(/Ã¹/g,"u{");
        aa = aa.replace(/Ã»/g,"o{{");

        bb = bb.replace(/Ã /g,"a{");
        bb = bb.replace(/Ã§/g,"c{");
        bb = bb.replace(/Ã©/g,"e{");
        bb = bb.replace(/Ã¨/g,"e{{");
        bb = bb.replace(/Ãª/g,"e{{{");
        bb = bb.replace(/Ã«/g,"e{{{{");
        bb = bb.replace(/Ã®/g,"i{");
        bb = bb.replace(/Ã¯/g,"i{{");
        bb = bb.replace(/Ã´/g,"o{");
        bb = bb.replace(/Å/g,"o{");
        bb = bb.replace(/Ã¹/g,"u{");
        bb = bb.replace(/Ã»/g,"o{{");
    }
    else if (SORT_LANG == "it")
    {
        // italy
        aa = aa.replace(/Ã /g,"a{");
        aa = aa.replace(/Ã¨/g,"e{");
        aa = aa.replace(/Ã©/g,"e{{");
        aa = aa.replace(/Ã¬/g,"i{");
        aa = aa.replace(/Ã²/g,"o{");
        aa = aa.replace(/Ã³/g,"o{");
        aa = aa.replace(/Ã¹/g,"u{");

        bb = bb.replace(/Ã /g,"a{");
        bb = bb.replace(/Ã¨/g,"e{");
        bb = bb.replace(/Ã©/g,"e{{");
        bb = bb.replace(/Ã¬/g,"i{");
        bb = bb.replace(/Ã²/g,"o{");
        bb = bb.replace(/Ã³/g,"o{");
        bb = bb.replace(/Ã¹/g,"u{");
    }
    else if (SORT_LANG == "sp")
    {
        // spain
        aa = aa.replace(/Ã¡/g,"a{");
        aa = aa.replace(/Ã©/g,"e{");
        aa = aa.replace(/Ã­/g,"i{");
        aa = aa.replace(/Ã±/g,"n{");
        aa = aa.replace(/Ã³/g,"o{");
        aa = aa.replace(/Ãº/g,"u{");

        bb = bb.replace(/Ã¡/g,"a{");
        bb = bb.replace(/Ã©/g,"e{");
        bb = bb.replace(/Ã­/g,"i{");
        bb = bb.replace(/Ã±/g,"n{");
        bb = bb.replace(/Ã³/g,"o{");
        bb = bb.replace(/Ãº/g,"u{");
    }
    // english -> do nothing
    // jp, zh -> do not sort

    if ( (aa==bb) &&
         (SECOND_SORT_FUNCTION != null) &&
         (!IN_SECOND_SORT) ) {
        return ts_second_sort(a, b);
    }
    else if (aa==bb) {
        return 0;
    }
    if (aa<bb) return -1;
     return 1;
}

function ts_sort_default(a,b) {
    aa = ts_getInnerText(a.cells[SORT_COLUMN_INDEX]);
    bb = ts_getInnerText(b.cells[SORT_COLUMN_INDEX]);

    if ( (aa==bb) &&
         (SECOND_SORT_FUNCTION != null) &&
         (!IN_SECOND_SORT) ) {
        return ts_second_sort(a, b);
    }
    else if (aa==bb) {
        return 0;
    }
    if (aa<bb) return -1;
    return 1;
}

function ts_sort_ip_address(a,b){

    var aa = ts_getInnerText(a.cells[SORT_COLUMN_INDEX]);
    var bb = ts_getInnerText(b.cells[SORT_COLUMN_INDEX]);

    if (aa.match(/\d/))     aa = prepare_ipstr_for_sort(aa);        // assume, that only ip-address contains a digit
    if (bb.match(/\d/))     bb = prepare_ipstr_for_sort(bb);

    if ( (aa==bb) &&
         (SECOND_SORT_FUNCTION != null) &&
         (!IN_SECOND_SORT) ) {
        return ts_second_sort(a, b);
    }
    else if (aa==bb) {
        return 0;
    }
    if (aa<bb) return -1;
     return 1;
}

function prepare_ipstr_for_sort(a){

     var ip_adr = a.split(".");
     var i;
     var erg = "";

     for(i=0; i<ip_adr.length;i++) {
        // in order to sort ip-addresses its necessary to fill the address as follows: 192.168.0.3 --> 192.168.000.003
        switch(ip_adr[i].length){
            case 1:
                ip_adr[i] = "00" + ip_adr[i];
                break;
            case 2:
                ip_adr[i] = "0" + ip_adr[i];
                break;
        } // end switch
     } // end for

    for(i=0; i<ip_adr.length;i++){
        erg += ip_adr[i];
        if(i != ip_adr.length-1) erg += ".";
    }
    return erg;
}


function getOptions(){
    var filterForm = parent.document.getElementById("bgzFilter");

    if(filterForm == null)
      return;

    var header = document.getElementsByTagName("div");
    var opt;
    var innertext = "";
    var first = 1;
    var newOption;
    var newText;
    for(var i=0; i<header.length; i++){
      if(header[i].className == "filter_opt") {
         opt = ts_getInnerText(header[i]);
         newOption = parent.document.createElement("option");
         newText = parent.document.createTextNode(opt);
         newOption.appendChild(newText);
         filterForm.appendChild(newOption);
      }
    }
}
/*
SelectRow for module state
*/
var rowNumberSelected = "";
var spanTextSelected = "";
function selectRowDetails(rowid, rownumber, link)
{
  if(rowid != 0)
  {
  // For automatic update:
  // The invisible update iframe always loads the state of the first row of the table, not the row selected in the visible table.
  // Therefore rowid, rownumber and link have to be stored in the top-window
  if(top.server_frame && window == top.server_frame.BgzTableFrame){
    rowid     = top.top_rowid;
    rownumber = top.top_rownumber;
    link      = top.top_link;
  }
  else {
    top.top_rowid = rowid;
    top.top_rownumber = rownumber;
    top.top_link = link;
  }

  var rowSelected, rowNewSelect, spanSelected;
  if(rowNumberSelected != "") {
      var rowidSelected = "row"+rowNumberSelected;
      rowSelected = document.getElementById(rowidSelected);
      if(rowSelected){
        rowSelected.bgColor = '#EAEAEA';
        spanSelected = document.getElementById("span"+rowNumberSelected);
        spanSelected.innerHTML = spanTextSelected;
      }
  }
  rowNewSelect = document.getElementById(rowid);
  rowNewSelect.bgColor = '#C1CEE9';
  spanTextSelected = document.getElementById("span" + rownumber).innerHTML;
  document.getElementById("span" + rownumber).innerHTML = parent.lang_str_details; //"Details";
  rowNumberSelected = rownumber;
  if(link)  parent.BgzDetailFrame.location.href=link;
  }
  else
  {
    if(link)  parent.BgzDetailFrame.location.href=link;
  }
}

function selectSecNavMenu(secnav_id, link)
{

        // visible page
     top.top_secnav_id = secnav_id;

     var temp_link = top.top_link;


     if     (temp_link.search(/BgzState/) != -1)       temp_link = temp_link.replace(/BgzState/,secnav_id);
     else if(temp_link.search(/BgzIdent/) != -1)       temp_link = temp_link.replace(/BgzIdent/,secnav_id);
     else if(temp_link.search(/BgzStatistics/) != -1)  temp_link = temp_link.replace(/BgzStatistics/,secnav_id);
     else if(temp_link.search(/BgzSafety/) != -1)      temp_link = temp_link.replace(/BgzSafety/,secnav_id);
     else if(temp_link.search(/BgzFWUpdate/) != -1)      temp_link = temp_link.replace(/BgzFWUpdate/,secnav_id);
     else                                              return;

     top.top_link = temp_link;

     parent.BgzDetailFrame.location.href = "../ClientArea/BgzSecNav.mwsl?SecNav=" + link;
}


function ts_getPage()
{
    var page = getParam("PriNav");

    if(page == "Bgz")
    {
        var bgzView = getParam("BgzView");
        if(bgzView == "")
          bgzView = "Masters";
        page = page + "_" + bgzView;
    }

    return page;
}

function getParam(url_param)
{
  var url = top.location.href;
  if ( url.indexOf("?") > -1 )
  {
    var params = url.substr(url.indexOf("?"));
    var params_array = params.split("&");
    for ( var i = 0; i < params_array.length; i++ )
    {
       if (params_array[i].indexOf(url_param + "=") > -1 )
       {
          var p = params_array[i].split("=");
          return  p[1];
       }
    }
  }
  return ("");
}

function getSortCookie(name)
{
   var c = window.top.document.cookie;
   var cookiename;
   var val;

   while(c != '')
   {
        while(c.substr(0,1) == ' ')
        {
          c = c.substr(1,c.length);
        }
        cookiename = c.substring(0,c.indexOf('='));

        if(c.indexOf(';') != -1)
        {
          val = c.substring(c.indexOf('=')+1,c.indexOf(';'));
        }
        else
        {
          val = c.substr(c.indexOf('=')+1,c.length);
        }
        if(name == cookiename)
        {
          return(val);
        }
        i = c.indexOf(';')+1;
        if(i == 0)
        {
          i = c.length
        }
        c = c.substring(i,c.length);
   }
   return("")
}

