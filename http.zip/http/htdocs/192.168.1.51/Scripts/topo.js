var OutputStr;

/***************************************************************************/
var DOMTreeGlobalDataOffset = 0;
var DOMTreeTopoOffset       = 1;

var DOMTreeGlobDataRecVarOffset = 0;
var DOMTreeGlobDataRecValOffset = (DOMTreeGlobDataRecVarOffset + 1);
var DOMTreeGlobDataRecSize = 2;

var DOMTreeNodeHighlightPosIdx = 0;
var DOMTreeNodesAttributePosIdx = (DOMTreeNodeHighlightPosIdx + 1);
var DOMTreeNodesDatePosIdx = (DOMTreeNodesAttributePosIdx + 1);
var DOMTreeNodesTimePosIdx = (DOMTreeNodesDatePosIdx + 1);
var DOMTreeNodesOffset = (DOMTreeNodesTimePosIdx + 1);

var DOMTreeNodeNamePosIdx = 0;
var DOMTreeNodeAttribPosIdx = (DOMTreeNodeNamePosIdx + 1);
var DOMTreeNodeDeviceTypePosIdx = (DOMTreeNodeAttribPosIdx + 1);
var DOMTreeNodeDiagInfoPosIdx = (DOMTreeNodeDeviceTypePosIdx + 1);
var DOMTreeNodeDiagInfoSubPosIdx = (DOMTreeNodeDiagInfoPosIdx + 1);
var DOMTreeNodeURL_BGZPosIdx = (DOMTreeNodeDiagInfoSubPosIdx + 1);

var DOMTreeConnDescrOffset = (DOMTreeNodeURL_BGZPosIdx + 1);
var DOMTreeConnDescrSize = 4;
var DOMTreeConnSrcPortOffset = 0;
var DOMTreeConnDestNodeOffset = 1;
var DOMTreeConnDestPortOffset = 2;
var DOMTreeConnStatusOffset   = 3;

var TableStatusImgObjPosAttrib  = 0;
var TableStatusImgObjPosDiag    = 1;
var TableStatusImgObjPosSubDiag = 2;

var TopoTableHeadGlobalTDObj = "";
var TopoTableHeadGlobalTDAttribObj = "";

var TopoTableGlobalTDObj = "";
var TopoTableGlobalTDAttribObj = "";

var ModeGlob = 0;
var DebugModeURL = 0;

var SetIntervalHighlight = "";

var GlobTopoPaintReady = false;
var GlobTopoNetDataReceived = false;
var GlobTopoDiagDataReceived = false;

var GlobTopoUpdateEnable = false;
var GlobNodeHighLiEnabled = false;
var GlobTextObjSizeX = 0;

var IframeObjXMLData = "";
var IframeObjXMLDiag = "";

var TopoListXML = "";
var TopoListXMLSave = "";
var TopoListXMLDiag = "";
var TopoGlobalData = "";

var TreeArray = "";

var TreeMatrixSize = new TreeMatrixSizeNew();

var NodeInTreeRefNodeXML = new NodeInTreeRefNodeXMLNew();

var NodeListXMLProcessedInTree = new Array();

var ConnectorPortArray  = "";
var ConnectorConnsArray = "";

var ModuleAtoGifs = new Array();
var DiagAtoGifs = new Array();
var NodeStateAtoGifs = new Array();

var GifHourGlas = "";
var TopoBgzLinkPraefix    = '/Images/Bgz/';
var TopoAtoGifLinkPraefix = '/Images/Topo/';
var NoSStringSizeStart = 0;

var ToolTipArray   = "";
var ToolTipTypePos = new ToolTipTypePosNew();

var RTM = new RunTimeData();
var OutputObj = "";

var PrintOutput = false;

var BlankString = "";

var mb_port_left_plug_ok       = 1;
var mb_port_left_unplug        = 2;
var mb_port_right_plug_ok      = 3;
var mb_port_right_unplug       = 4;
var mb_head                    = 5;
var mb_head_not_available      = 6;
var mb_head_not_of_project     = 7;
var connector                  = 8;
var port_label                 = 9;
var head_label                 = 10;
var port_tooltip_background    = 11;
var mb_head_overview           = 12;
var head_label_overview        = 13;
var mb_port_left_plug_error    = 14;
var mb_port_right_plug_error   = 15;
var mb_port_left_plug_no_diag  = 16;
var mb_port_right_plug_no_diag = 17;



var DiagAtoGif_Null          = 0;
var DiagAtoGif_Unaccessible  = 1;
var DiagAtoGif_Alarm         = 2;
var DiagAtoGif_Maintenance2  = 3;
var DiagAtoGif_Maintenance1  = 4;
var DiagAtoGif_Ok            = 5;
var DiagAtoGif_Deactivated   = 6;
var DiagAtoGif_SubFail       = 8;
var DiagAtoGif_NotAvailable  = 7;


var HighLiIntervalCount = 0;
var HighLiIntervalMax = 8;

function TopoOverviewNew()
{
    this.NodeSizeXmin = 28;
    this.NodeSizeYmin = 16;

    this.NodeSizeXmax = 128;
    this.NodeSizeYmax = 32;

    this.NodeSpacingXmin = 10;
    this.NodeSpacingYmin = 10;

    this.NodeSpacingXmax = 20;
    this.NodeSpacingYmax = 20;

    this.NodeSpacingX = this.NodeSpacingXmin;
    this.NodeSpacingY = this.NodeSpacingYmin;

    this.NodePaintSizeX = 0;
    this.NodePaintSizeY = 0;

    this.PaintSizeX = 0;
    this.PaintSizeY = 0;

    this.NodesNoX = 0;
    this.NodesNoY = 0;

    this.NoOfNodesXML = 0;

    this.SetNodePaintSizeX = function(NodeSize){ this.NodePaintSizeX = NodeSize;};
    this.GetNodePaintSizeX = function(){return this.NodePaintSizeX;};
    this.SetNodePaintSizeY = function(NodeSize){ this.NodePaintSizeY = NodeSize;};
    this.GetNodePaintSizeY = function(){return this.NodePaintSizeY;};

    this.SetNodesNoX = function(No){ this.NodesNoX = No;};
    this.GetNodesNoX = function(){ return this.NodesNoX;};
    this.SetNodesNoY = function(No){ this.NodesNoY = No;};
    this.GetNodesNoY = function(){ return this.NodesNoY;};

    this.GetNodeSizeXmin = function(){ return this.NodeSizeXmin;};
    this.GetNodeSizeYmin = function(){ return this.NodeSizeYmin;};

    this.GetNodeSizeXmax = function(){ return this.NodeSizeXmax;};
    this.GetNodeSizeYmax = function(){ return this.NodeSizeYmax;};

    this.GetNodeSpacingXmin = function(){ return this.NodeSpacingXmin;};
    this.GetNodeSpacingYmin = function(){ return this.NodeSpacingYmin;};

    this.GetNodeSpacingXmax = function(){ return this.NodeSpacingXmax;};
    this.GetNodeSpacingYmax = function(){ return this.NodeSpacingYmax;};

    this.SetNoOfNodesXML = function(No){this.NoOfNodesXML = No;};
    this.GetNoOfNodesXML = function(){ return this.NoOfNodesXML;};

    this.SetNodeSpacingX = function(Px){this.NodeSpacingX = Px;};
    this.GetNodeSpacingX = function(){ return this.NodeSpacingX;};

    this.SetNodeSpacingY = function(Px){this.NodeSpacingY = Px;};
    this.GetNodeSpacingY = function(){ return this.NodeSpacingY;};

    this.GetPaintSizeX = function()
                         {
                             var Quot = 0;
                             var Remainder = 0;

                             Quot = Math.floor(this.NoOfNodesXML / this.NodesNoX);

                             if(0 == Quot)
                             {
                                 this.PaintSizeX = (this.NoOfNodesXML % this.NodesNoX) * (this.NodePaintSizeX + this.NodeSpacingX);
                             }
                             else
                             {
                                 this.PaintSizeX = (this.NodesNoX * (this.NodePaintSizeX + this.NodeSpacingX));

                             }
                             return (this.PaintSizeX - this.NodeSpacingX);
                         };

    this.GetPaintSizeY = function()
                         {
                             var NoOfRows = 0;
                             NoOfRows = Math.ceil(this.NoOfNodesXML / this.NodesNoX);
                             this.PaintSizeY = (NoOfRows * (this.NodePaintSizeY + this.NodeSpacingY));
                             return (this.PaintSizeY - this.NodeSpacingY);
                         };
}


var TopoOverview = new TopoOverviewNew();


var PxMatrixCellSize = 32; // cube

var NodeMatrixXSize = 4;

var MatrixModuleSpacingX = 3;
var MatrixModuleSpacingY = 1;

var NodePortXOffset = 0;

var DeviceTypeLabelOffsetY = 16; //px
var DeviceTypeNodeLabelOffsetY = 3; //px

var DiagInfoIconSizeX = 16; //px
var DiagInfoIconSizeY = 16; //px
var DiagInfoIconOffsetX = 2; //px
var DiagInfoIconOffsetY = 7; //px

var NodeStateIconSizeX = 16;
var NodeStateIconSizeY = 16;

var DiagInfoSubIconOffsetX = DiagInfoIconSizeX + DiagInfoIconOffsetX; //px
var DiagInfoSubIconOffsetY = 7; //px



var LLDPPortIDEmpty = 0;
var LLDPPortIDShort = 8;
var LLDPPortIDLong = 14;
var PortNameLengthMax = 6;



var TopoPaintPxOffsetX = 10;
var TopoPaintPxOffsetY = 10;

var NodeCellBottHeightPx = 10;

var NodeCellWidth      = 4;
var NodeCellHeadHeight = 1;
var NodeCellBottHeight = 1;
var NodeCellPortWidth  = 2 * PxMatrixCellSize; //54; // px
var NodeCellPortHeight = 1;

var NodeConnectorWidth = 15; // px

var NodeConnectorLabelWidth = PxMatrixCellSize; // px
var NodeConnectorLabelHeight = 12; // px


var NodeCellConnectorPaddingLeft = 0;
var NodeCellConnectorPaddingTop = ((PxMatrixCellSize - NodeConnectorLabelHeight) >> 1);

var LabelObjAdjustmentPxX = NodeCellConnectorPaddingLeft;
var LabelObjAdjustmentPxY = NodeCellConnectorPaddingTop;


var PortLabelHeight = 14;
var PortLabelObjAdjustmentPxX = 15; // left side ports and div-size
var PortLabelObjAdjustmentPxY = ((PxMatrixCellSize - PortLabelHeight) >> 1);;


// ToolTipAttribute
var ToolTipAttribNodeHead  = 0; //NodeHead
var ToolTipAttribNodeLabel = 1; //NodeLabel
var ToolTipAttribPortLabel = 2; //PortLabel

var ConnLineThickness = 4; //px

var ConnLineSpacingX = ((PxMatrixCellSize - ConnLineThickness) >> 1);
var ConnLineSpacingY = ((PxMatrixCellSize - ConnLineThickness) >> 1);

var ImgObjHeadBorder = 2;

// global xml data attribute flags
var XMLNodesAttribActTopoBGColor  = 0x0001;

// Node attributes
var XMLNodeAttribDevOfProject     = 0x0001;
var XMLNodeAttribDevTypeIsCPU     = 0x0002;
var XMLNodeAttribDevNext2Project  = 0x0004;
var XMLNodeAttribDevNotAccessible = 0x0008;
var XMLNodeAttribPNIORecReadError = 0x0010;
var XMLNodeAttribPNIORecNotPlaus  = 0x0020;
var XMLNodeAttribDevDeactivated   = 0x0100;
// node head attribute during flashing
var XMLNodeAttribHighlight        = 0x8000;

// CnType:
var cn_type_not_conn  = "noconn";
var cn_type_corrupt   = "corrupt";
var cn_type_parent    = "parent";
var cn_type_child     = "child";
var cn_type_ring      = "ring";
var cn_type_ring_left      = "ring_left";
var cn_type_ring_right     = "ring_right";
var cn_type_connector_left  = "connector_left";
var cn_type_connector_right = "connector_right";

// Connection status
var ConnStatusMask             = 0x0007;
var ConnStatusConnectionOk     = 0x0001; // okay
var ConnStatusConnectionError  = 0x0002; // error
var ConnStatusConnectionNoDiag = 0x0004; // unknown, diag not possible

// NodeType
var node_type_line      = 0;
var node_type_line_last = 1;
var node_type_star      = 2;
var node_type_last      = 3;

var node_body_left_side = 0;
var node_body_right_side = 1;

var port_label_align_left  = "left";
var port_label_align_right = "right";

var NodeBody = new Array();
/***************************************************************************/

// ==== Basics/PH =====================================================

function TopoPaint(mode, dbg)
{
    ModeGlob = mode;

    DebugModeURL = dbg;

    switch (dbg)
    {
        case 0:
        switch (ModeGlob)
        {
            case "TopoGraph":
            case "TopoTable":
            case "TopoBrief":
            {
                // output topo graph and overview
                TopoPaintPxOffsetX = 20;
                TopoPaintPxOffsetY = 20;
                Topo();
            }
            break;

            case "TopoGraphPrint":
            case "TopoTablePrint":
            case "TopoBriefPrint":
            {
                // print output topo graph and overview
                TopoPaintPxOffsetX = 20;
                TopoPaintPxOffsetY = 20;
                PrintOutput = true;
                Topo();
            }
            break;

            default:
            TopoPaintPxOffsetX = 0;
            TopoPaintPxOffsetY = 0;
            PrintOutput = true;
            Topo();     // print output
//            PortNameToolTipVisibleAll();
            break;
        }
        break;

        case 1:
        case 2:
        default:
        Topo();         // dbg output no graphics & default oputput
        break;
    }
}

function TopoPutVal(value)
{
    OutputStr = OutputStr + value;
}


function TopoPrintVal()
{
    var picsec;

    picsec = top.document.getElementById("pic");

    picsec.innerHTML = OutputStr;
}


function TopoGetNodeInfo(NodeNo, InfoIdx, IframeObj)
{
    var NodeInfo = IframeObj.contentWindow.document.body.childNodes[0].childNodes[DOMTreeTopoOffset].childNodes[NodeNo + DOMTreeNodesOffset].childNodes[InfoIdx].innerHTML;
    return NodeInfo;
}

function TopoGetNodeHighlight(IframeObj)
{
    var NodeHighlight = IframeObj.contentWindow.document.body.childNodes[0].childNodes[DOMTreeTopoOffset].childNodes[DOMTreeNodeHighlightPosIdx].innerHTML;
    return NodeHighlight;
}

function TopoGetNodesAttribute(IframeObj)
{
    var NodesAttribute = IframeObj.contentWindow.document.body.childNodes[0].childNodes[DOMTreeTopoOffset].childNodes[DOMTreeNodesAttributePosIdx].innerHTML;
    return NodesAttribute;
}

function TopoGetNodesDate(IframeObj)
{
    var NodesDate = IframeObj.contentWindow.document.body.childNodes[0].childNodes[DOMTreeTopoOffset].childNodes[DOMTreeNodesDatePosIdx].innerHTML;
    return NodesDate;
}

function TopoGetNodesTime(IframeObj)
{
    var NodesTime = IframeObj.contentWindow.document.body.childNodes[0].childNodes[DOMTreeTopoOffset].childNodes[DOMTreeNodesTimePosIdx].innerHTML;
    return NodesTime;
}

function TopoGetNode(node_nbr, IframeObj)
{
    return TopoGetNodeInfo(node_nbr, DOMTreeNodeNamePosIdx, IframeObj);
}


function TopoGetAttrib(node_nbr, IframeObj)
{
    return TopoGetNodeInfo(node_nbr, DOMTreeNodeAttribPosIdx, IframeObj);
}


function TopoGetDeviceType(node_nbr, IframeObj)
{
    return TopoGetNodeInfo(node_nbr, DOMTreeNodeDeviceTypePosIdx, IframeObj);
}

function TopoGetDiagInfo(node_nbr, IframeObj)
{
    return TopoGetNodeInfo(node_nbr, DOMTreeNodeDiagInfoPosIdx, IframeObj);
}

function TopoGetDiagInfoSub(node_nbr, IframeObj)
{
    return TopoGetNodeInfo(node_nbr, DOMTreeNodeDiagInfoSubPosIdx, IframeObj);
}

function TopoGetURL_BGZ(node_nbr, IframeObj)
{
    var url_bgz;
    url_bgz = TopoGetNodeInfo(node_nbr, DOMTreeNodeURL_BGZPosIdx, IframeObj);
    url_bgz = url_bgz.replace(/&lt;/g,"<");
    url_bgz = url_bgz.replace(/&gt;/g,">");
    url_bgz = url_bgz.replace(/&amp;/g,"&");
    url_bgz = url_bgz.replace(/&apos;/g,"\'");
    url_bgz = url_bgz.replace(/&nbsp;/g," ");
    return(url_bgz);
}

function TopoGetSrcPort(node_nbr, con_nbr, IframeObj)
{
    var SrcPortIdx = DOMTreeConnDescrOffset + DOMTreeConnSrcPortOffset + (con_nbr * DOMTreeConnDescrSize);
    return TopoGetNodeInfo(node_nbr, SrcPortIdx, IframeObj);
}


function TopoGetDestNode(node_nbr, con_nbr, IframeObj)
{
    var DestNodeIdx = DOMTreeConnDescrOffset + DOMTreeConnDestNodeOffset + (con_nbr * DOMTreeConnDescrSize);
    return TopoGetNodeInfo(node_nbr, DestNodeIdx, IframeObj);
}


function TopoGetDestPort(node_nbr, con_nbr, IframeObj)
{
    var DestPortIdx = DOMTreeConnDescrOffset + DOMTreeConnDestPortOffset + (con_nbr * DOMTreeConnDescrSize);
    return TopoGetNodeInfo(node_nbr, DestPortIdx, IframeObj);
}


function TopoGetConnStatus(node_nbr, con_nbr, IframeObj)
{
    var ConnStatusIdx = DOMTreeConnDescrOffset + DOMTreeConnStatusOffset + (con_nbr * DOMTreeConnDescrSize);
    return TopoGetNodeInfo(node_nbr, ConnStatusIdx, IframeObj);
}

function TopoGetNodeCnt(IframeObj)
{
    var NoOfNodes = 0;

    if(0 != IframeObj.contentWindow.document.body.childNodes.length)
    {
        NoOfNodes = IframeObj.contentWindow.document.body.childNodes[0].childNodes[DOMTreeTopoOffset].childNodes.length;
    }

    return (NoOfNodes - DOMTreeNodesOffset);
}

function TopoGetNodeConnectionCnt(node_nbr, IframeObj)
{
    var NoOfConns = IframeObj.contentWindow.document.body.childNodes[0].childNodes[DOMTreeTopoOffset].childNodes[node_nbr + DOMTreeNodesOffset].childNodes.length;
    return ((NoOfConns - DOMTreeConnDescrOffset) / DOMTreeConnDescrSize);
}

// Functions regarding global data records **********************************************
function TopoGetGlobalDataRecordCnt(IframeObj)
{
    var NoOfRecords = 0;

    if(0 != IframeObj.contentWindow.document.body.childNodes.length)
    {
        NoOfRecords = IframeObj.contentWindow.document.body.childNodes[0].childNodes[DOMTreeGlobalDataOffset].childNodes.length;
    }

    return (NoOfRecords/DOMTreeGlobDataRecSize);
}

function TopoGetGlobDataRecordVar(RecordNo, IframeObj)
{
    return TopoGetRecordInfo(RecordNo, DOMTreeGlobDataRecVarOffset, IframeObj);
}

function TopoGetGlobDataRecordVal(RecordNo, IframeObj)
{
    return TopoGetRecordInfo(RecordNo, DOMTreeGlobDataRecValOffset, IframeObj);
}

function TopoGetRecordInfo(RecordNo, RecordIdx, IframeObj)
{
    var RecordInfo = IframeObj.contentWindow.document.body.childNodes[0].childNodes[DOMTreeGlobalDataOffset].childNodes[((RecordNo * DOMTreeGlobDataRecSize) + RecordIdx)].innerHTML;
    return RecordInfo;
}
// End of functions regarding global data records ***************************************

function TopoPutTable()
{
    var i, j;
    var NodeCnt, NodeName, NodeAttrib, NodeDeviceType, NodeDiagInfo, NodeDiagInfoSub, NodeURL_BGZ, HexNodeAttrib, SrcPortName, DestNodeName, DestPortName, ConnStatus, HexConnStatus;
    var ConnectionCnt;
    var IframeObjTemp = "";

    // data storage is the 1st XML-Data-IFrame (id = TopoXMLData)
    IframeTemp = IframeObjXMLData;

    TopoHourGlas(0); // hide hourglas
    OutputStr = "";

    NodeCnt = TopoGetNodeCnt(IframeTemp);

    TopoPutVal("<table class=\"ContentTableDbgTopo\"><td class=\"ContentTableField_1DbgTopo\">Node</td><td class=\"ContentTableField_1DbgTopo\">SrcPort</td><td class=\"ContentTableField_1DbgTopo\">DestNode</td><td class=\"ContentTableField_1DbgTopo\">DestPort</td><td class=\"ContentTableField_1DbgTopo\">Attribute</td><td class=\"ContentTableField_1DbgTopo\">ConnStatus</td><td class=\"ContentTableField_1DbgTopo\">DeviceType</td><td class=\"ContentTableField_1DbgTopo\">DiagInfo</td><td class=\"ContentTableField_1DbgTopo\">DiagInfoSub</td><td class=\"ContentTableField_1DbgTopo\">URL BGZ</td></tr>");
    for (i = 0; i < NodeCnt; i++)
    {
        NodeName        = TopoGetNode(i, IframeTemp);
        NodeAttrib      = TopoGetAttrib(i, IframeTemp);
        HexNodeAttrib   = Number(NodeAttrib).toString(16);
        NodeDeviceType  = TopoGetDeviceType(i, IframeTemp);
        NodeDiagInfo    = TopoGetDiagInfo(i, IframeTemp);
        NodeDiagInfoSub = TopoGetDiagInfoSub(i, IframeTemp);
        NodeURL_BGZ     = TopoGetURL_BGZ(i, IframeTemp);
        ConnectionCnt   = TopoGetNodeConnectionCnt(i, IframeTemp);
        for (j = 0; j < ConnectionCnt; j++)
        {
            TopoPutVal("<tr>");

            TopoPutVal("<td class=\"ContentTableFieldDbgTopo\">"+NodeName+"</td>");

            SrcPortName = TopoGetSrcPort(i,j,IframeTemp);
            TopoPutVal("<td class=\"ContentTableFieldDbgTopo\">"+SrcPortName+"</td>");

            DestNodeName = TopoGetDestNode(i,j,IframeTemp);
            TopoPutVal("<td class=\"ContentTableFieldDbgTopo\">"+DestNodeName+"</td>");

            DestPortName = TopoGetDestPort(i,j,IframeTemp);
            TopoPutVal("<td class=\"ContentTableFieldDbgTopo\">"+DestPortName+"</td>");

            TopoPutVal("<td class=\"ContentTableFieldDbgTopo\">0x"+HexNodeAttrib+"</td>");

            ConnStatus = TopoGetConnStatus(i,j,IframeTemp);
            HexConnStatus = Number(ConnStatus).toString(16);
            TopoPutVal("<td class=\"ContentTableFieldDbgTopo\">0x"+HexConnStatus+"</td>");

            TopoPutVal("<td class=\"ContentTableFieldDbgTopo\">"+NodeDeviceType+"</td>");
            TopoPutVal("<td class=\"ContentTableFieldDbgTopo\">"+NodeDiagInfo+"</td>");
            TopoPutVal("<td class=\"ContentTableFieldDbgTopo\">"+NodeDiagInfoSub+"</td>");
            TopoPutVal("<td class=\"ContentTableFieldDbgTopo\">"+NodeURL_BGZ+"</td>");

            TopoPutVal("</tr>");
        }
        TopoPutVal("<tr><td class=\"ContentTableFieldDbgTopo\">*****</td><td class=\"ContentTableFieldDbgTopo\">*****</td><td class=\"ContentTableFieldDbgTopo\">*****</td><td class=\"ContentTableFieldDbgTopo\">*****</td><td class=\"ContentTableFieldDbgTopo\">*****</td><td class=\"ContentTableFieldDbgTopo\">*****</td><td class=\"ContentTableFieldDbgTopo\">*****</td><td class=\"ContentTableFieldDbgTopo\">*****</td><td class=\"ContentTableFieldDbgTopo\">*****</td><td class=\"ContentTableFieldDbgTopo\">*****</td></tr>");
    }
    TopoPutVal("</table>");
    TopoPrintVal();
}

function TopoXMLTableInsertRow(TableObj, RowIdx, Data)
{
    var TableRow = "";
    var TableDataText = "";
    var TableData = "";

    TableRow = TableObj.insertRow(RowIdx);
    TableDataText = top.document.createTextNode(Data);

    TableData = top.document.createElement("td");
    TableData.style.whiteSpace = "nowrap";
    TableData.style.border = "0px solid #000000";
    TableData.style.padding = "0px";

    TableData.appendChild(TableDataText);
    TableRow.appendChild(TableData);
    TableRow.style.padding = "0px";
}

function TopoXMLTableOutput(IframeObjXML)
{
    var i, j;
    var NodeCnt, NodeName, NodeAttrib, NodeDeviceType, NodeDiagInfo, NodeDiagInfoSub, NodeURL_BGZ, SrcPortName, DestNodeName, DestPortName, ConnStatus;
    var ConnectionCnt;
    var IframeObjTemp = "";

    var TopoXMLTable = "";
    var TableRow = "";
    var TableData = "";
    var TableDataText = "";
    var TableRowIdx = 0;

    var RecordCnt = 0;
    var RecordVar = "", RecordVal = "";

    var TempString = "";

    var NodeNameHighlight, NodesAttrib, NodesDate, NodesTime;


    TopoHourGlas(0); // hide hourglas


    TopoXMLTable = top.document.createElement("table");
    TopoXMLTable.setAttribute("class", "TopoToolTipTable");

    top.document.getElementById("pic").appendChild(TopoXMLTable);

    TopoXMLTableInsertRow(TopoXMLTable, TableRowIdx++,'<?xml version="1.0" standalone="yes"?>');

    TopoXMLTableInsertRow(TopoXMLTable, TableRowIdx++,'<IFrameData>');

    TopoXMLTableInsertRow(TopoXMLTable, TableRowIdx++,'<GlobalData>');
    // get number of global records
    RecordCnt = TopoGetGlobalDataRecordCnt(IframeObjXML);

    for (i = 0; i < RecordCnt; i++)
    {
        RecordVar = TopoGetGlobDataRecordVar(i,IframeObjXML);
        RecordVal = TopoGetGlobDataRecordVal(i,IframeObjXML);

        TempString = '<Data Var="' +
                     RecordVar     +
                     '" Val="'     +
                     RecordVal     +
                     '"/>';

        TopoXMLTableInsertRow(TopoXMLTable, TableRowIdx++, TempString);
    }

    TopoXMLTableInsertRow(TopoXMLTable, TableRowIdx++,'</GlobalData>');


    NodeNameHighlight = TopoGetNodeHighlight(IframeObjXML);

    NodesAttrib = TopoGetNodesAttribute(IframeObjXML);

    NodesDate = TopoGetNodesDate(IframeObjXML);

    NodesTime = TopoGetNodesTime(IframeObjXML);

    TempString = '<Nodes NodeHighlight="' +
                 NodeNameHighlight        +
                 '" NodesAttribute="'     +
                 NodesAttrib              +
                 '" NodesDate="'          +
                 NodesDate                +
                 '" NodesTime="'          +
                 NodesTime                +
                 '">';

    TopoXMLTableInsertRow(TopoXMLTable, TableRowIdx++, TempString);


    NodeCnt = TopoGetNodeCnt(IframeObjXML);

    for (i = 0; i < NodeCnt; i++)
    {
        NodeName        = TopoGetNode(i, IframeObjXML);
        NodeAttrib      = TopoGetAttrib(i, IframeObjXML);
        NodeDeviceType  = TopoGetDeviceType(i, IframeObjXML);
        NodeDiagInfo    = TopoGetDiagInfo(i, IframeObjXML);
        NodeDiagInfoSub = TopoGetDiagInfoSub(i, IframeObjXML);

        NodeURL_BGZ     = TopoGetURL_BGZ(i, IframeObjXML);

        TempString = '<Node Name="'    +
                     NodeName          +
                     '" Attribute="'   +
                     NodeAttrib        +
                     '" DeviceType="'  +
                     NodeDeviceType    +
                     '" DiagInfo="'    +
                     NodeDiagInfo      +
                     '" DiagInfoSub="' +
                     NodeDiagInfoSub   +
                     '" URL_BGZ="'     +
                     NodeURL_BGZ       +
                     '">';

        TopoXMLTableInsertRow(TopoXMLTable, TableRowIdx++, TempString);

        ConnectionCnt   = TopoGetNodeConnectionCnt(i, IframeObjXML);

        for (j = 0; j < ConnectionCnt; j++)
        {
            SrcPortName  = TopoGetSrcPort(i,j,IframeObjXML);
            DestNodeName = TopoGetDestNode(i,j,IframeObjXML);
            DestPortName = TopoGetDestPort(i,j,IframeObjXML);
            ConnStatus   = TopoGetConnStatus(i,j,IframeObjXML);

            TempString = '<Connection SrcPort="' +
                         SrcPortName             +
                         '" DestNode="'          +
                         DestNodeName            +
                         '" DestPort="'          +
                         DestPortName            +
                         '" ConnStatus="'        +
                         ConnStatus              +
                         '"/>';

            TopoXMLTableInsertRow(TopoXMLTable, TableRowIdx++, TempString);
        }

        TopoXMLTableInsertRow(TopoXMLTable, TableRowIdx++, '</Node>');
     }

    TopoXMLTableInsertRow(TopoXMLTable, TableRowIdx++,'</Nodes>');
    TopoXMLTableInsertRow(TopoXMLTable, TableRowIdx++,'</IFrameData>');
}
// ==== End Basics/PH ==================================================

/********* Topo classes ******************************************************/
function XMLRefToTreeIdxAndNodeIdxNew()
{
    this.TreeIdx = 0;
    this.NodeIdx = 0;
}

function NodeInTreeRefNodeXMLNew()
{
    this.XMLNodes = new Array();
    this.AddNewXMLRef = function(XMLNodeIdx, TreeIdx, NodeIdx)
                        {
                             this.XMLNodes[XMLNodeIdx] = new XMLRefToTreeIdxAndNodeIdxNew();
                             this.XMLNodes[XMLNodeIdx].TreeIdx = TreeIdx;
                             this.XMLNodes[XMLNodeIdx].NodeIdx = NodeIdx;
                        };

    this.GetTreeIdx     = function(XMLNodeIdx) {return this.XMLNodes[XMLNodeIdx].TreeIdx; };
    this.GetTreeNodeIdx = function(XMLNodeIdx) {return this.XMLNodes[XMLNodeIdx].NodeIdx; };
};

var RTMTopoIFrame              = 0;
var RTMDiagIFrame              = 1;
var RTMPrintInit               = 2;
var RTMImportTopoIFrame        = 3;
var RTMImportDiagIFrame        = 4;
var RTMTreeGeneration          = 5;
var RTMNodeStructureGeneration = 6;
var RTMGraphPrint              = 7;
var RTMDiagPrint               = 8;

var RTMTopoStart2Net           = 100;
var RTMTopoStart2Diag          = 200;

function RunTimeData()
{

    this.RTMStartTime = new Array();
    this.RTMEndTime = new Array();
    this.RTMRunTime = new Array();
    this.RTMid = new Array();

    this.StartRTM = function(ArrayIdx, id)
                    {
                        this.RTMStartTime[ArrayIdx] = new Date();
                        this.RTMid[ArrayIdx] = id;
                    };

    this.StopRTM  = function(ArrayIdx)
                    {
                        this.RTMEndTime[ArrayIdx] = new Date();

                        this.RTMRunTime[ArrayIdx] = (this.RTMEndTime[ArrayIdx].getTime() - this.RTMStartTime[ArrayIdx].getTime());
                    };
    this.GetRTMTime = function(ArrayIdx){return this.RTMRunTime[ArrayIdx];};

    this.GetTimeSum = function()
                      {
                          var TimeSum = 0;
                          TimeSum = this.RTMRunTime[RTMTopoStart2Diag];
                          return TimeSum;
                      };

    this.GetPercent = function(ArrayIdx) {return ((this.RTMRunTime[ArrayIdx] / this.GetTimeSum()) * 100).toFixed(2);};

    this.GetNoOfMeasure = function(){ return this.RTMRunTime.length;};
    this.GetRTMid = function(ArrayIdx){ return this.RTMid[ArrayIdx];};

};

function GlobalDataRecord_New(Var, Val)
{
    this.RecVar = Var;
    this.RecVal = Val;
};

function TopoGlobalData_New()
{
    this.DebugModeCPU = 0;
    this.Records = new Array();
    this.AddNewRecord = function(RecordVar, RecordVal)
                        { this.Records[this.Records.length] = new GlobalDataRecord_New(RecordVar, RecordVal);
                          if("DebugModeCPU" == RecordVar) this.DebugModeCPU = RecordVal;
                        };
    this.GetDebugModeCPU = function(){return this.DebugModeCPU;};
    this.GetRecordCnt = function(){return this.Records.length;};

    this.GetRecordVarAtIdx = function(Idx){return this.Records[Idx].RecVar;};
    this.GetRecordValAtIdx = function(Idx){return this.Records[Idx].RecVal;};

    this.GetRecordIdxAtVar = function(RecordVar)
                              {    var NoOfRecords = this.GetRecordCnt();
                                   for (var i = 0; i < NoOfRecords; i++)
                                   {
                                       if(this.Records[i].RecVar == RecordVar) return i;
                                   }
                                   return null;
                              };

    this.GetRecordValAtVar = function(RecordVar)
                              {    var NoOfRecords = this.GetRecordCnt();
                                   for (var i = 0; i < NoOfRecords; i++)
                                   {
                                       if(this.Records[i].RecVar == RecordVar) return this.Records[i].RecVal;
                                   }
                                   return null;
                              };
}

// node-list object stucture
function NodeListXML_NewNode()
{
   this.NodeName = "";
   this.NodeAttrib = 0;
   this.DeviceType = "";
   this.NodeDiagInfo = "";
   this.NodeDiagInfoSub = "";
   this.NodeURL_BGZ = "";
   // additional overview data
   this.OverHeadDivObj = "";
   this.OverDiagInfoDivObj = "";
   this.OverDiagInfoSubDivObj = "";
   this.OverNodeNameDivObj = "";
   this.OverDeviceTypeDivObj = "";
   this.OverNodeURL_BGZObj = "";
   // additional table status data
   this.TableDeviceObjTR = "";
   //-------------------------
   this.NodeHighlight = false;
   this.Conn = new Array(); // array of NodeListXML_NewConn
}

function NodeListXML_NewConn(SrcNode, SrcPort, DestNode, DestPort, ConnStatus)
{
    this.SrcNode      = SrcNode;
    this.SrcPort      = SrcPort;
    this.DestNode     = DestNode;
    this.DestPort     = DestPort;
    this.Src          = SrcNode  + SrcPort;
    this.Dest         = DestNode + DestPort;
    this.Validity     = true;
    this.MultiPort    = false;
    this.MuPoDestDev  = "";
    this.ConnStatus   = ConnStatus;
    this.ConnPortObj  = "";
    this.PortLabelObj = "";
    this.ConnPaintObj = new Array(); // array of painted connection objects
}

/***************************************************************/
// Class node list xml
function NodeListXML_New()
{
    this.NodesAttrib = "";
    this.NodesDate = "";
    this.NodesTime = "";
    this.Nodes = new Array();
    this.AddNewNode = function(){ this.Nodes[this.Nodes.length] = new NodeListXML_NewNode();
                                  return this.Nodes.length;
                                };
    this.AddNewConn2Node = function(SrcNode, SrcPort, DestNode, DestPort, ConnStatus, ConnValidity){ var IdxLastUsedNode = this.Nodes.length-1;
                                                                                       var IdxNewConn = this.Nodes[this.Nodes.length-1].Conn.length;
                                                                                       this.Nodes[IdxLastUsedNode].Conn[IdxNewConn] = new NodeListXML_NewConn(SrcNode, SrcPort, DestNode, DestPort, ConnStatus);
                                                                                       return this.Nodes[this.Nodes.length-1].Conn.length; // return no of connections
                                                                                     };

    this.AddNewConnPaintObj2Conn  = function(NodeIdx, ConnIdx, ConnPaintObj){ this.Nodes[NodeIdx].Conn[ConnIdx].ConnPaintObj.push(ConnPaintObj);};
    this.GetConnPaintObjAtConnIdx = function(NodeIdx, ConnIdx, PaintObjIdx){ return this.Nodes[NodeIdx].Conn[ConnIdx].ConnPaintObj[PaintObjIdx];};
    this.GetNoOfConnPaintObjts    = function(NodeIdx, ConnIdx){ return this.Nodes[NodeIdx].Conn[ConnIdx].ConnPaintObj.length; };

    this.SetNodesAttrib = function(NodesAttrib){ this.NodesAttrib = NodesAttrib;};
    this.GetNodesAttrib = function(){return this.NodesAttrib;};
    this.SetNodesDate = function(NodesDate){ this.NodesDate = NodesDate;};
    this.GetNodesDate = function(){return this.NodesDate;};
    this.SetNodesTime = function(NodesTime){ this.NodesTime = NodesTime;};
    this.GetNodesTime = function(){return this.NodesTime;};
    this.SetNodeNameAtIdx = function(NodeIdx, NodeName){ this.Nodes[NodeIdx].NodeName = NodeName;};
    this.GetNodeNameAtNodeIdx = function(NodeIdx){ return this.Nodes[NodeIdx].NodeName;};
    this.SetNodeAttribAtIdx = function(NodeIdx, NodeAttrib){ this.Nodes[NodeIdx].NodeAttrib = NodeAttrib;};
    this.GetNodeAttribAtIdx = function(NodeIdx){ return this.Nodes[NodeIdx].NodeAttrib;};
    this.SetNodeDeviceTypeAtIdx = function(NodeIdx, DeviceType){ this.Nodes[NodeIdx].DeviceType = DeviceType;};
    this.GetNodeDeviceTypeAtIdx = function(NodeIdx){ return this.Nodes[NodeIdx].DeviceType;};
    this.SetNodeDiagInfoAtIdx = function(NodeIdx, NodeDiagInfo){ this.Nodes[NodeIdx].NodeDiagInfo = NodeDiagInfo;};
    this.GetNodeDiagInfoAtIdx = function(NodeIdx){ return this.Nodes[NodeIdx].NodeDiagInfo;};
    this.SetNodeDiagInfoSubAtIdx = function(NodeIdx, NodeDiagInfoSub){ this.Nodes[NodeIdx].NodeDiagInfoSub = NodeDiagInfoSub;};
    this.GetNodeDiagInfoSubAtIdx = function(NodeIdx){ return this.Nodes[NodeIdx].NodeDiagInfoSub;};
    this.SetNodeURL_BGZAtIdx = function(NodeIdx, NodeURL_BGZ){ this.Nodes[NodeIdx].NodeURL_BGZ = NodeURL_BGZ;};
    this.GetNodeURL_BGZAtIdx = function(NodeIdx){ return this.Nodes[NodeIdx].NodeURL_BGZ;};
/* additional overview methods */
    this.SetOverHeadDivObjAtIdx = function(NodeIdx, OverHeadDivObj){ this.Nodes[NodeIdx].OverHeadDivObj = OverHeadDivObj;};
    this.GetOverHeadDivObjAtIdx = function(NodeIdx){ return this.Nodes[NodeIdx].OverHeadDivObj;};

    this.SetOverDiagInfoDivObjAtIdx = function(NodeIdx, OverDiagInfoDivObj){ this.Nodes[NodeIdx].OverDiagInfoDivObj = OverDiagInfoDivObj;};
    this.GetOverDiagInfoDivObjAtIdx = function(NodeIdx){ return this.Nodes[NodeIdx].OverDiagInfoDivObj;};

    this.SetOverDiagInfoSubDivObjAtIdx = function(NodeIdx, OverDiagInfoSubDivObj){ this.Nodes[NodeIdx].OverDiagInfoSubDivObj = OverDiagInfoSubDivObj;};
    this.GetOverDiagInfoSubDivObjAtIdx = function(NodeIdx){ return this.Nodes[NodeIdx].OverDiagInfoSubDivObj;};

    this.SetOverNodeNameDivObjAtIdx = function(NodeIdx, OverNodeNameDivObj){ this.Nodes[NodeIdx].OverNodeNameDivObj = OverNodeNameDivObj;};
    this.GetOverNodeNameDivObjAtIdx = function(NodeIdx){ return this.Nodes[NodeIdx].OverNodeNameDivObj;};

    this.SetOverDeviceTypeDivObjAtIdx = function(NodeIdx, OverDeviceTypeDivObj){ this.Nodes[NodeIdx].OverDeviceTypeDivObj = OverDeviceTypeDivObj;};
    this.GetOverDeviceTypeDivObjAtIdx = function(NodeIdx){ return this.Nodes[NodeIdx].OverDeviceTypeDivObj;};

    this.SetOverNodeURL_BGZObjAtIdx = function(NodeIdx, OverNodeURL_BGZObj){ this.Nodes[NodeIdx].OverNodeURL_BGZObj = OverNodeURL_BGZObj;};
    this.GetOverNodeURL_BGZObjAtIdx = function(NodeIdx){ return this.Nodes[NodeIdx].OverNodeURL_BGZObj;};
/* additional table methods */
    this.SetTableDeviceObjTRAtIdx = function(NodeIdx, TableDeviceObjTR){ this.Nodes[NodeIdx].TableDeviceObjTR = TableDeviceObjTR;};
    this.GetTableDeviceObjTRAtIdx = function(NodeIdx){ return this.Nodes[NodeIdx].TableDeviceObjTR;};
/*******************************/
    this.SetNodeHighlightAtIdx = function(NodeIdx){ this.Nodes[NodeIdx].NodeHighlight = true;};
    this.GetNodeHighlightAtIdx = function(NodeIdx){ return this.Nodes[NodeIdx].NodeHighlight;};

    this.GetConnDescrDestNode = function(NodeIdx, ConnIdx){ return this.Nodes[NodeIdx].Conn[ConnIdx].DestNode;};
    this.GetConnDescrDestPort = function(NodeIdx, ConnIdx){ return this.Nodes[NodeIdx].Conn[ConnIdx].DestPort;};
    this.GetConnDescrSrcPort = function(NodeIdx, ConnIdx){ return this.Nodes[NodeIdx].Conn[ConnIdx].SrcPort;};
    this.GetConnDescrSrc = function(NodeIdx, ConnIdx){ return this.Nodes[NodeIdx].Conn[ConnIdx].Src;};
//    this.GetConnDescrDest = function(NodeIdx, ConnIdx){ return this.Nodes[NodeIdx].Conn[ConnIdx].Dest;};

    this.SetConnValidity = function(NodeIdx, ConnIdx, Validity){ this.Nodes[NodeIdx].Conn[ConnIdx].Validity = Validity;};
    this.GetConnValidity = function(NodeIdx, ConnIdx){ return this.Nodes[NodeIdx].Conn[ConnIdx].Validity;};

    this.SetConnMultiPort = function(NodeIdx, ConnIdx, MultiPort){ this.Nodes[NodeIdx].Conn[ConnIdx].MultiPort = MultiPort;};
    this.GetConnMultiPort = function(NodeIdx, ConnIdx){ return this.Nodes[NodeIdx].Conn[ConnIdx].MultiPort;};

    this.SetConnMuPoDestDev = function(NodeIdx, ConnIdx, MuPoDestDev){ this.Nodes[NodeIdx].Conn[ConnIdx].MuPoDestDev = MuPoDestDev;};
    this.GetConnMuPoDestDev = function(NodeIdx, ConnIdx){ return this.Nodes[NodeIdx].Conn[ConnIdx].MuPoDestDev;};

    this.SetConnStatus = function(NodeIdx, ConnIdx, Status){ this.Nodes[NodeIdx].Conn[ConnIdx].ConnStatus = Status;};
    this.GetConnStatus = function(NodeIdx, ConnIdx){ return this.Nodes[NodeIdx].Conn[ConnIdx].ConnStatus;};

    this.SetConnPortObj = function(NodeIdx, ConnIdx, ConnPortObj){ this.Nodes[NodeIdx].Conn[ConnIdx].ConnPortObj = ConnPortObj;};
    this.GetConnPortObj = function(NodeIdx, ConnIdx){ return this.Nodes[NodeIdx].Conn[ConnIdx].ConnPortObj;};

    this.SetPortLabelObj = function(NodeIdx, ConnIdx, PortLabelObj){ this.Nodes[NodeIdx].Conn[ConnIdx].PortLabelObj = PortLabelObj;};
    this.GetPortLabelObj = function(NodeIdx, ConnIdx){ return this.Nodes[NodeIdx].Conn[ConnIdx].PortLabelObj;};

    this.GetConnDescrAtConnIdx = function(NodeIdx, ConnIdx){ var ConnDescrTemp = new NodeListXML_NewConn();
                                                            ConnDescrTemp.SrcNode = this.Nodes[NodeIdx].Conn[ConnIdx].SrcNode;
                                                            ConnDescrTemp.SrcPort = this.Nodes[NodeIdx].Conn[ConnIdx].SrcPort;
                                                            ConnDescrTemp.DestNode = this.Nodes[NodeIdx].Conn[ConnIdx].DestNode;
                                                            ConnDescrTemp.DestPort = this.Nodes[NodeIdx].Conn[ConnIdx].DestPort;
                                                            ConnDescrTemp.Src      = this.Nodes[NodeIdx].Conn[ConnIdx].Src;
                                                            ConnDescrTemp.Dest     = this.Nodes[NodeIdx].Conn[ConnIdx].Dest;
                                                            ConnDescrTemp.Validity = this.Nodes[NodeIdx].Conn[ConnIdx].Validity;
                                                            return ConnDescrTemp;
                                                           };
                                                           
    this.GetIdxOfNodeByName = function(NodeName)
                              {    var TempNoOfNodes = this.GetNoOfNodes();
                                   for (var i = 0; i < TempNoOfNodes; i++)
                                   {
                                       if(this.Nodes[i].NodeName == NodeName) return i;
                                   }
                                   return null;
                              };

    this.GetIdxOfConnByPortName = function(NodeIdx, PortName)
                              {    var TempNoOfConns = this.GetNoOfConnAtNodeIdx(NodeIdx);
                                   for (var i = 0; i < TempNoOfConns; i++)
                                   {
                                       if(this.Nodes[NodeIdx].Conn[i].SrcPort == PortName) return i;
                                   }
                                   return null;
                              };

    this.GetIdxOfDestConnBySrcAndPortName = function(NodeNameSrc, NodeIdxDest, PortNameDest)
                                        {   var TempNoOfConns = this.GetNoOfConnAtNodeIdx(NodeIdxDest);
                                            for (var i = 0; i < TempNoOfConns; i++)
                                            {
                                                if((this.Nodes[NodeIdxDest].Conn[i].SrcPort == PortNameDest) &&
                                                   (this.Nodes[NodeIdxDest].Conn[i].DestNode == NodeNameSrc)) return i;
                                            }
                                            return null;
                                        };

    this.GetIdxOfConnAtCorrespRingNode = function(CorrespRingNodeIdx, SrcNodeName, SrcPortName)
                              {    var TempNoOfConns = this.GetNoOfConnAtNodeIdx(CorrespRingNodeIdx);

                                   for (var i = 0; i < TempNoOfConns; i++)
                                   {
                                       if((this.Nodes[CorrespRingNodeIdx].Conn[i].DestNode == SrcNodeName) &&
                                          (this.Nodes[CorrespRingNodeIdx].Conn[i].DestPort == SrcPortName))
                                       return i;

                                   }
                                   return null;
                              };

    this.GetNoOfNodes = function(){ return this.Nodes.length;};
    this.GetNoOfConnAtNodeIdx = function(NodeIdx){ return this.Nodes[NodeIdx].Conn.length;};
    this.GetNoOfAllConn = function(){ var TempNoOfConns = 0;
                                      var TempNoOfNodes = this.GetNoOfNodes();
                                      for(var i = 0; i < TempNoOfNodes; i++)
                                      {
                                          TempNoOfConns += this.GetNoOfConnAtNodeIdx(i);
                                      }
                                      return TempNoOfConns;
                                    };
}

function NodeConn()
{
    this.PortName = "";
    this.CnType = 0;
    this.ChildNo = 0xFF;
    this.RingCnCorrespIdxOfNode = 0;
    this.RingCnCorrespIdxOfConn = 0;
    this.DisconNo = 0xFF;
    this.PortPosX = 0;
    this.PortPosY = 0;
    this.ConnectorPortIdx = 0xFFFF;
    this.ConnStatus = 0;
}

// tree object stucture
function Tree_NewTreeNode()
{
   this.NodeName = "";
   this.NodeAttrib = 0;
   this.DeviceType = "";
   this.NodeDiagInfo = "";
   this.NodeDiagInfoSub = "";
   this.NodeURL_BGZ = "";
   this.NodeConn = new Array();

   this.IdxOfConnInXMLList = 0;
   this.IdxOfNodeInXMLList = 0;
   this.IdxOfParentNode = 0;
   this.IdxOfChildNode = new Array();
   this.IdxOfRingConnNode = new Array();
   this.NodeSizeYCrop = 0;
   this.NodeVertLayer = 0;
   this.NodeType = 0;
   this.LineSize = 0;

   this.NodePosX = 0;
   this.NodePosY = 0;
   this.NodeSizeX = 0;
   this.NodeSizeY = 0;
}

function NodeHighlightNew()
{
   this.TreeIdx = 0xFFFF;
   this.TreeNodeIdx = 0xFFFF;
}

function TreeArrayNew()
{

   this.Tree = new Array();

   this.NodeHighlight = new NodeHighlightNew();

   this.SetNodeHighlight = function(TreeIdx, TreeNodeIdx)
                           {
                               this.NodeHighlight.TreeIdx = TreeIdx;
                               this.NodeHighlight.TreeNodeIdx = TreeNodeIdx;
                           };

   this.GetNodeHighlightTreeIdx = function(){return this.NodeHighlight.TreeIdx;};
   this.GetNodeHighlightNodeIdx = function(){return this.NodeHighlight.TreeNodeIdx;};

   this.SetNodePosX  = function(TreeIdx, TreeNodeIdx, NodePosX) {this.Tree[TreeIdx][TreeNodeIdx].NodePosX = NodePosX;};
   this.GetNodePosX  = function(TreeIdx, TreeNodeIdx) {return this.Tree[TreeIdx][TreeNodeIdx].NodePosX;};

   this.SetNodePosY  = function(TreeIdx, TreeNodeIdx, NodePosY) {this.Tree[TreeIdx][TreeNodeIdx].NodePosY = NodePosY;};
   this.GetNodePosY  = function(TreeIdx, TreeNodeIdx) {return this.Tree[TreeIdx][TreeNodeIdx].NodePosY;};

   this.SetNodeSizeX  = function(TreeIdx, TreeNodeIdx, NodeSizeX) {this.Tree[TreeIdx][TreeNodeIdx].NodeSizeX = NodeSizeX;};
   this.GetNodeSizeX  = function(TreeIdx, TreeNodeIdx) {return this.Tree[TreeIdx][TreeNodeIdx].NodeSizeX;};

   this.SetNodeSizeY  = function(TreeIdx, TreeNodeIdx, NodeSizeY) {this.Tree[TreeIdx][TreeNodeIdx].NodeSizeY = NodeSizeY;};
   this.GetNodeSizeY  = function(TreeIdx, TreeNodeIdx) {return this.Tree[TreeIdx][TreeNodeIdx].NodeSizeY;};

   this.AddNewTree = function()
                     {
                         this.Tree[this.Tree.length] = new Array(); // array of TreeNodes
                         return this.Tree.length;
                     };
   this.GetNoOfTrees = function(){ return this.Tree.length;};
   this.AddNewTreeNode = function()
                         {
                             var IdxLastUsedTree = this.Tree.length-1;
                             var IdxNewTreeNode = this.Tree[IdxLastUsedTree].length;
                             this.Tree[IdxLastUsedTree][IdxNewTreeNode] = new Tree_NewTreeNode();
                             return this.Tree[this.Tree.length-1].length; // return no. of used nodes
                         };

   this.AddNewTreeNodeWithParentIdx = function(ParentIdx)
                                      {
                                           var IdxLastUsedTree = this.Tree.length-1;
                                           var IdxNewTreeNode = this.Tree[IdxLastUsedTree].length;
                                           this.Tree[IdxLastUsedTree][IdxNewTreeNode] = new Tree_NewTreeNode();
                                           this.Tree[IdxLastUsedTree][IdxNewTreeNode].IdxOfParentNode = ParentIdx;
                                           return (this.Tree[this.Tree.length-1].length - 1); // return child node idx
                                      };

   this.SetIdxOfChildNodeInParentNode = function(TreeIdx, ParentIdx, ChildIdx)
                                      {
                                           var IdxOfLastNotUsedChildNode = this.Tree[TreeIdx][ParentIdx].IdxOfChildNode.length;
                                           this.Tree[TreeIdx][ParentIdx].IdxOfChildNode[IdxOfLastNotUsedChildNode] = ChildIdx;
                                           IdxOfLastNotUsedChildNode = this.Tree[TreeIdx][ParentIdx].IdxOfChildNode.length;
                                           return (IdxOfLastNotUsedChildNode-1);
                                      };
   this.InitNodeConnStruct = function(TreeIdx, TreeNodeIdx, ConnNo)
                            {
                                for (var i = 0; i < ConnNo; i++) this.Tree[TreeIdx][TreeNodeIdx].NodeConn[i] = new NodeConn();
                            };

   this.GetNoOfNodeConn = function(TreeIdx, TreeNodeIdx){return this.Tree[TreeIdx][TreeNodeIdx].NodeConn.length;};

   this.SetNodeConnPortName = function(TreeIdx, TreeNodeIdx, ConnNo, PortName){ this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].PortName = PortName;};
   this.GetNodeConnPortName = function(TreeIdx, TreeNodeIdx, ConnNo){ return this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].PortName;};

   this.SetNodeConnCnType = function(TreeIdx, TreeNodeIdx, ConnNo, CnType){ this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].CnType = CnType;};
   this.GetNodeConnCnType = function(TreeIdx, TreeNodeIdx, ConnNo){ return this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].CnType;};

   this.SetNodeConnChildNo = function(TreeIdx, TreeNodeIdx, ConnNo, ChildNo){ this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].ChildNo = ChildNo;};
   this.GetNodeConnChildNo = function(TreeIdx, TreeNodeIdx, ConnNo){ return this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].ChildNo;};

   this.SetNodeConnRingNo = function(TreeIdx, TreeNodeIdx, ConnNo, RingNo){ this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].RingNo = RingNo;};
   this.GetNodeConnRingNo = function(TreeIdx, TreeNodeIdx, ConnNo){ return this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].RingNo;};

   this.SetNodeConnPortPosX = function(TreeIdx, TreeNodeIdx, ConnNo, PortPosX){ this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].PortPosX = PortPosX;};
   this.GetNodeConnPortPosX = function(TreeIdx, TreeNodeIdx, ConnNo){ return this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].PortPosX;};
   this.SetNodeConnPortPosY = function(TreeIdx, TreeNodeIdx, ConnNo, PortPosY){ this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].PortPosY = PortPosY;};
   this.GetNodeConnPortPosY = function(TreeIdx, TreeNodeIdx, ConnNo){ return this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].PortPosY;};

   this.SetNodeConnectorPortIdx = function(TreeIdx, TreeNodeIdx, ConnNo, ConnectorPortIdx){ this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].ConnectorPortIdx = ConnectorPortIdx;};
   this.GetNodeConnectorPortIdx = function(TreeIdx, TreeNodeIdx, ConnNo){ return this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].ConnectorPortIdx;};

   this.SetNodeConnStatus = function(TreeIdx, TreeNodeIdx, ConnNo, ConnStatus){ this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].ConnStatus = ConnStatus;};
   this.GetNodeConnStatus = function(TreeIdx, TreeNodeIdx, ConnNo){ return this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].ConnStatus;};

   this.SetRingCnCorrespIdxOfNode = function(TreeIdx, TreeNodeIdx, ConnNo, RingCnCorrespIdxOfNode){ this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].RingCnCorrespIdxOfNode = RingCnCorrespIdxOfNode;}
   this.GetRingCnCorrespIdxOfNode = function(TreeIdx, TreeNodeIdx, ConnNo){ return this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].RingCnCorrespIdxOfNode;}

   this.SetRingCnCorrespIdxOfConn = function(TreeIdx, TreeNodeIdx, ConnNo, RingCnCorrespIdxOfConn){ this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].RingCnCorrespIdxOfConn = RingCnCorrespIdxOfConn;}
   this.GetRingCnCorrespIdxOfConn = function(TreeIdx, TreeNodeIdx, ConnNo){ return this.Tree[TreeIdx][TreeNodeIdx].NodeConn[ConnNo].RingCnCorrespIdxOfConn;}

   this.GetNodeConnParentPortIdx =  function(TreeIdx, TreeNodeIdx)
                                     {
                                         var ConnNo = this.Tree[TreeIdx][TreeNodeIdx].NodeConn.length;

                                         var i;
                                         for(i = 0; i < ConnNo; i++)
                                         {
                                             if(cn_type_parent == this.Tree[TreeIdx][TreeNodeIdx].NodeConn[i].CnType) return i;
                                         }
                                         return null;
                                     };

   this.GetNoOfChildNodes  = function(TreeIdx, TreeNodeIdx){ return this.Tree[TreeIdx][TreeNodeIdx].IdxOfChildNode.length; };

   this.GetIdxTreeNodeByChildIdx = function(TreeIdx, TreeNodeIdx, ChildIdx){return this.Tree[TreeIdx][TreeNodeIdx].IdxOfChildNode[ChildIdx];};

   this.SetNodeSizeYCrop  = function(TreeIdx, TreeNodeIdx, NodeSizeYCrop){this.Tree[TreeIdx][TreeNodeIdx].NodeSizeYCrop = NodeSizeYCrop;};
   this.GetNodeSizeYCrop  = function(TreeIdx, TreeNodeIdx) {return this.Tree[TreeIdx][TreeNodeIdx].NodeSizeYCrop;};

   this.SetNodeType  = function(TreeIdx, TreeNodeIdx, NodeType){this.Tree[TreeIdx][TreeNodeIdx].NodeType = NodeType;};
   this.GetNodeType  = function(TreeIdx, TreeNodeIdx) {return this.Tree[TreeIdx][TreeNodeIdx].NodeType;};

   this.SetLineSize  = function(TreeIdx, TreeNodeIdx, LineSize) {this.Tree[TreeIdx][TreeNodeIdx].LineSize = LineSize;};
   this.GetLineSize  = function(TreeIdx, TreeNodeIdx) {return this.Tree[TreeIdx][TreeNodeIdx].LineSize;};

   this.SetNodeVertLayer  = function(TreeIdx, TreeNodeIdx, NodeVertLayer) {this.Tree[TreeIdx][TreeNodeIdx].NodeVertLayer = NodeVertLayer; };
   this.GetNodeVertLayer  = function(TreeIdx, TreeNodeIdx) {return this.Tree[TreeIdx][TreeNodeIdx].NodeVertLayer; };

   this.SetNodeName = function(TreeIdx, NodeIdx, NodeName) {this.Tree[TreeIdx][NodeIdx].NodeName = NodeName; };
   this.GetNodeName = function(TreeIdx, NodeIdx) {return this.Tree[TreeIdx][NodeIdx].NodeName;};

   this.SetNodeAttrib = function(TreeIdx, NodeIdx, NodeAttrib) {this.Tree[TreeIdx][NodeIdx].NodeAttrib = NodeAttrib; };
   this.GetNodeAttrib = function(TreeIdx, NodeIdx) {return this.Tree[TreeIdx][NodeIdx].NodeAttrib;};

   this.SetNodeDeviceType = function(TreeIdx, NodeIdx, DeviceType) {this.Tree[TreeIdx][NodeIdx].DeviceType = DeviceType; };
   this.GetNodeDeviceType = function(TreeIdx, NodeIdx) {return this.Tree[TreeIdx][NodeIdx].DeviceType;};

   this.SetNodeDiagInfo = function(TreeIdx, NodeIdx, NodeDiagInfo) {this.Tree[TreeIdx][NodeIdx].NodeDiagInfo = NodeDiagInfo; };
   this.GetNodeDiagInfo = function(TreeIdx, NodeIdx) {return this.Tree[TreeIdx][NodeIdx].NodeDiagInfo;};

   this.SetNodeDiagInfoSub = function(TreeIdx, NodeIdx, NodeDiagInfoSub) {this.Tree[TreeIdx][NodeIdx].NodeDiagInfoSub = NodeDiagInfoSub; };
   this.GetNodeDiagInfoSub = function(TreeIdx, NodeIdx) {return this.Tree[TreeIdx][NodeIdx].NodeDiagInfoSub;};

   this.SetNodeURL_BGZ = function(TreeIdx, NodeIdx, NodeURL_BGZ) {this.Tree[TreeIdx][NodeIdx].NodeURL_BGZ = NodeURL_BGZ; };
   this.GetNodeURL_BGZ = function(TreeIdx, NodeIdx) {return this.Tree[TreeIdx][NodeIdx].NodeURL_BGZ;};

   this.SetIdxOfRingConnNodeInNode = function(TreeIdx, NodeIdx, RingConnNodeIdx)
                                     {
                                          var IdxOfLastNotUsedRingConnNode = this.Tree[TreeIdx][NodeIdx].IdxOfRingConnNode.length;
                                          this.Tree[TreeIdx][NodeIdx].IdxOfRingConnNode[IdxOfLastNotUsedRingConnNode] = RingConnNodeIdx;
                                     };

   this.GetIdxOfRingConnNode = function(TreeIdx, NodeIdx, RingConnNo){return this.Tree[TreeIdx][NodeIdx].IdxOfRingConnNode[RingConnNo];};

   this.SetIdxOfNodeInXMLList = function(TreeIdx, NodeIdxTree, NodeIdxXML){this.Tree[TreeIdx][NodeIdxTree].IdxOfNodeInXMLList = NodeIdxXML; };
   this.GetIdxOfNodeInXMLList = function(TreeIdx, NodeIdxTree){return this.Tree[TreeIdx][NodeIdxTree].IdxOfNodeInXMLList; };

   this.SetIdxOfConnInXMLList = function(TreeIdx, NodeIdxTree, ConnIdxXML){this.Tree[TreeIdx][NodeIdxTree].IdxOfConnInXMLList = ConnIdxXML; };
   this.GetIdxOfConnInXMLList = function(TreeIdx, NodeIdxTree){return this.Tree[TreeIdx][NodeIdxTree].IdxOfConnInXMLList; };

   this.GetParentIdxOfNode = function(TreeIdx, NodeIdx){return this.Tree[TreeIdx][NodeIdx].IdxOfParentNode; };
   this.SetParentIdxOfNode = function(TreeIdx, NodeIdx, ParentIdx){this.Tree[TreeIdx][NodeIdx].IdxOfParentNode = ParentIdx; };
}

function ToolTipNew()
{
    this.ReferenceID = "";       //ID des Anker-Elements
    this.ToolTipID = "";         //ID des Div-Elements, das als vollstaendiges ToolTip erscheint
    this.ToolTipAttrib = "";
    this.ToolTipDefaultPosX = 0;
    this.ToolTipDefaultPosY = 0;
}

function ToolTipArrayNew()
{
    this.ToolTip = new Array();

    this.AddNewToolTip  = function(Attrib)
                          {
                              var ToolTipIdx = this.ToolTip.length;
                              this.ToolTip[ToolTipIdx] = new ToolTipNew();
                              this.ToolTip[ToolTipIdx].ReferenceID = "ReferenceID" + ToolTipIdx.toString();
                              this.ToolTip[ToolTipIdx].ToolTipID = "ToolTipID" + ToolTipIdx.toString();
                              this.ToolTip[ToolTipIdx].ToolTipAttrib = Attrib;
                              return (ToolTipIdx);
                          };

    this.GetReferenceID    = function(ToolTipIdx){return this.ToolTip[ToolTipIdx].ReferenceID; };
    this.GetToolTipID   = function(ToolTipIdx){return this.ToolTip[ToolTipIdx].ToolTipID; };
    this.SetToolTipIDAtIdx = function(ToolTipIdx, ToolTipID){this.ToolTip[ToolTipIdx].ToolTipID = ToolTipID; };

    this.SetToolTipDefaultPosX = function(ToolTipIdx, ToolTipDefaultPosX){this.ToolTip[ToolTipIdx].ToolTipDefaultPosX = ToolTipDefaultPosX; };
    this.GetToolTipDefaultPosX = function(ToolTipIdx){return this.ToolTip[ToolTipIdx].ToolTipDefaultPosX; };
    this.SetToolTipDefaultPosY = function(ToolTipIdx, ToolTipDefaultPosY){this.ToolTip[ToolTipIdx].ToolTipDefaultPosY = ToolTipDefaultPosY; };
    this.GetToolTipDefaultPosY = function(ToolTipIdx){return this.ToolTip[ToolTipIdx].ToolTipDefaultPosY; };

    this.GetTooTipIdxByReferenceID = function(ReferenceID) { var NoOfToolTips = this.ToolTip.length;
                                                       var i = 0;
                                                       for(i = 0; i < NoOfToolTips; i++)
                                                       {
                                                          if(ReferenceID == this.ToolTip[i].ReferenceID) return i;
                                                       }
                                                         return null;
                                                     };

    this.GetToolTipAttrib = function(ToolTipIdx){return this.ToolTip[ToolTipIdx].ToolTipAttrib;};

    this.GetToolTipCount = function(){return this.ToolTip.length;};
}

function ToolTipCoordinatesNew()
{
    this.x = 0;
    this.y = 0;

    this.SetX = function(ValX){ this.x = ValX;};
    this.GetX = function(){ return this.x;};
    this.SetY = function(ValY){ this.y = ValY;};
    this.GetY = function(){ return this.y;};
}

function ToolTipPosNew()
{
    this.DefaultRel = new ToolTipCoordinatesNew();
    this.Adjustment = new ToolTipCoordinatesNew();

    this.SetDefaultRelX = function(ValX){ this.DefaultRel.SetX(ValX);};
    this.GetDefaultRelX = function(){ return this.DefaultRel.GetX();};
    this.SetDefaultRelY = function(ValY){ this.DefaultRel.SetY(ValY);};
    this.GetDefaultRelY = function(){ return this.DefaultRel.GetY();};

    this.SetAdjustmentX = function(ValX){ this.Adjustment.SetX(ValX);};
    this.GetAdjustmentX = function(){ return this.Adjustment.GetX();};
    this.SetAdjustmentY = function(ValY){ this.Adjustment.SetY(ValY);};
    this.GetAdjustmentY = function(){ return this.Adjustment.GetY();};
}

function ToolTipTypePosNew()
{
    this.ToolTipTypeArray = new Array();

    this.Init = function(ToolTipType, DefRelX, DefRelY, AdjX, AdjY)
                {
                    this.ToolTipTypeArray[ToolTipType] = new ToolTipPosNew();
                    this.ToolTipTypeArray[ToolTipType].SetDefaultRelX(DefRelX);
                    this.ToolTipTypeArray[ToolTipType].SetDefaultRelY(DefRelY);
                    this.ToolTipTypeArray[ToolTipType].SetAdjustmentX(AdjX);
                    this.ToolTipTypeArray[ToolTipType].SetAdjustmentY(AdjY);
                }

    this.GetTTTPosDefRelX = function(ToolTipType){ return this.ToolTipTypeArray[ToolTipType].GetDefaultRelX();};
    this.GetTTTPosDefRelY = function(ToolTipType){ return this.ToolTipTypeArray[ToolTipType].GetDefaultRelY();};
    this.GetTTTPosAdjX = function(ToolTipType){ return this.ToolTipTypeArray[ToolTipType].GetAdjustmentX();};
    this.GetTTTPosAdjY = function(ToolTipType){ return this.ToolTipTypeArray[ToolTipType].GetAdjustmentY();};
}

function ConnectorNew()
{
    this.ConnectorLabel = "";
}

function ConnectorArrayNew()
{
   this.Connector = new Array();

   this.AddNewConnector  = function() { var IdxNewConnector = this.Connector.length;
                                        this.Connector[IdxNewConnector] = new ConnectorNew();
                                        return (this.Connector.length - 1);
                                      };

   this.SetConnectorLabel = function(ConnectorIdx, ConnectorLabel) {this.Connector[ConnectorIdx].ConnectorLabel = ConnectorLabel;};
   this.GetConnectorLabel = function(ConnectorIdx) {return this.Connector[ConnectorIdx].ConnectorLabel;};

}

function RingConnArrayNew()
{
    this.ConnectorLabel = "A";
    this.AddNewConnectorLabel  = function() { var CurrentConnectorLabel = this.ConnectorLabel;
                                              var CurrentLabelLenght = this.ConnectorLabel.length;

                                              var LabelPart = new Array(CurrentLabelLenght);

                                              var AddNewPart = false;
                                              var IncPartBefore = false;

                                              var i;

                                              for(i = (CurrentLabelLenght - 1); i >= 0; i--)
                                              {
                                                  LabelPart[i] = this.ConnectorLabel.charCodeAt(i);
                                              }

                                              LabelPart[CurrentLabelLenght-1]++;

                                              for(i = (CurrentLabelLenght - 1); i >= 0; i--)
                                              {
                                                  if(IncPartBefore == true)
                                                  {
                                                      LabelPart[i]++;
                                                      IncPartBefore = false;
                                                  }

                                                  if(LabelPart[i] > 90)
                                                  {
                                                      if(i != 0)
                                                      {
                                                          IncPartBefore = true;
                                                          LabelPart[i] = 65;
                                                      }
                                                      else
                                                      {
                                                          LabelPart[i] = 65;
                                                          AddNewPart = true;
                                                      }
                                                  }
                                              }

                                              this.ConnectorLabel = "";

                                              if(AddNewPart == true)
                                              {
                                                  this.ConnectorLabel = "A";
                                              }

                                              for(i = 0; i < CurrentLabelLenght; i++)
                                              {
                                                  this.ConnectorLabel += String.fromCharCode(LabelPart[i]);
                                              }
                                                  return CurrentConnectorLabel;
                                            };
}

function MatrixSizeNew()
{
    this.SizeX = 0;
    this.SizeY = 0;
}

function TreeMatrixSizeNew()
{
    this.Tree = new Array();

    this.AddNewSizeElem = function(IdxOfTree){ this.Tree[IdxOfTree] = new MatrixSizeNew(); };

    this.SetMatrixSize = function(IdxOfTree, MatrixSize)
                         {
                             this.Tree[IdxOfTree].SizeX = MatrixSize.SizeX;
                             this.Tree[IdxOfTree].SizeY = MatrixSize.SizeY;
                         };

    this.GetMatrixSize = function(IdxOfTree)
                         {
                             var MatrixSize = new MatrixSizeNew();
                             MatrixSize.SizeX = this.Tree[IdxOfTree].SizeX;
                             MatrixSize.SizeY = this.Tree[IdxOfTree].SizeY;
                             return (MatrixSize);
                         };
}

/********* end of topo classes ***********************************************/
/*****************************************************************************/

function TopoHourGlas(par)
{
    var ImgObjHourGlas = "";
    var GifHourGlas = '/Images/Topo/topo_hour_glas.gif';

    if(1 == par)
    {
        ImgObjHourGlas = top.document.getElementById("HourGlas");
        if (ImgObjHourGlas == null)
        {
            // Sanduhr anzeigen
            ImgObjHourGlas = top.document.createElement("img");
            ImgObjHourGlas.id = "HourGlas";
            ImgObjHourGlas.src = GifHourGlas;
            ImgObjHourGlas.style.width  = (64) + "px";
            ImgObjHourGlas.style.height = (64) + "px";
            ImgObjHourGlas.style.border = "0px solid #000000";
            top.document.getElementById("pic").appendChild(ImgObjHourGlas);
        }
    }
    else
    {
        ImgObjHourGlas = top.document.getElementById("HourGlas");
        if (ImgObjHourGlas != null)
            top.document.getElementById("pic").removeChild(ImgObjHourGlas);
    }
}

function Topo()
{
    var EnableJSObj = "";
    var DivPicObj = "";

    // erase warning (Please enable javascript), if java script is enabled
    EnableJSObj = top.document.getElementById("EnableJS");
    DivPicObj   = top.document.getElementById("pic");
    DivPicObj.removeChild(EnableJSObj);

    TopoHourGlas(1); // display hourglas

    GlobTopoPaintReady = false;
    GlobTopoDiagDataReceived = false;

    RTM.StartRTM(RTMTopoStart2Net, "Summe: Start->Ausgabe: Netzwerk");
    RTM.StartRTM(RTMTopoStart2Diag, "Summe: Start->Ausgabe: Diagnose");

    GlobTopoNetDataReceived = false;
    GlobTopoDiagDataReceived = false;

    RTM.StartRTM(RTMTopoIFrame, "IFrame: Topo");

    TopoGetXMLNet();
}

function TopoContinue()
{
      RTM.StopRTM(RTMTopoIFrame);

      RTM.StartRTM(RTMPrintInit, "Ausgabe: Init");

    TopoInitAtoGifs();
    TopoInitDiagAtoGifs();
    TopoInitNodeStateAtoGifs();
    NodeBodyInit();
    ToolTipTypePosInit();

      RTM.StopRTM(RTMPrintInit);

      RTM.StartRTM(RTMImportTopoIFrame, "Datenimport: IFrameTopo");
    // import global data from the Iframe into the Topo-JavaScript
    TopoGlobalData = new TopoGlobalData_New();
    TopoGenGlobalData(TopoGlobalData, IframeObjXMLData);

    switch(DebugModeURL)
    {
        case 100:
        case 102:
        {
            // debug mode has to be called here because of debug table output and direct iframe-access
            DebugOutput();
            break;
        }

        case 103:
            // debug output uses diag-iframe-access and will be processed after diag iframe received
        break;

        default:
        {
            TopoListXML = new NodeListXML_New();
            TopoGenModuleList(TopoListXML, IframeObjXMLData);

            RTM.StopRTM(RTMImportTopoIFrame);

            /*******************************************************************************/
            switch(ModeGlob)
            {
                case "TopoGraph":
                case "TopoGraphPrint":
                case "TopoGraphUpdate":
                {   /* topo graph */
                    /*******************************************************************************/
                    NoSStringSizeStart = 6;
                    TopoGraphHandle();
                    /*******************************************************************************/
                    break;
                }
                case "TopoTable":
                case "TopoTablePrint":
                case "TopoTableUpdate":
                {   /* topo table */
                    /*******************************************************************************/
                    TopoTableHandle();
                    /*******************************************************************************/
                    break;
                }

                case "TopoBrief":
                case "TopoBriefPrint":
                case "TopoBriefUpdate":
                {   /* topo overview */
                    /*******************************************************************************/
                    NoSStringSizeStart = 1;
                    TopoOverviewHandle();
                   /*******************************************************************************/
                   break;
                }

                default:
                {
                    console && console.log && console.log("Erronous global mode @ TopoContinue: " + ModeGlob);
                    break;
                }
            }// end of switch(ModeGlob)
        }
    }// end of switch(DebugModeURL)

}// end of function Topo()
/*****************************************************************************/

function TopoGraphHandle()
{

    var NoOfXMLNodes    = 0;
    var NodeIdxXML      = 0;
    var IdxOfTree       = 0;
    var IdxOfNodeInTree = 0;
    var TreeRootNodeIdx = 0;
    var TopoBackgroundDiv = "";
    var PaintOffsetY = 0;

    var i;

    // signal that painting of topology network started
    GlobTopoPaintReady = false;

    // create new array of connectors
    ConnectorPortArray  = new ConnectorArrayNew();
    // init connector label generator
    ConnectorConnsArray = new RingConnArrayNew();
    // init new array of tool tips
    ToolTipArray   = new ToolTipArrayNew();

    PaintOffsetY = TopoPaintPxOffsetY;

    TopoBackgroundDiv = top.document.getElementById("TopoBackgroundDiv");

    if(null != TopoBackgroundDiv) top.document.getElementById("pic").removeChild(TopoBackgroundDiv);

    TopoHourGlas(1); // display hourglas

    // check for node doublet
    XMLNodePlausibCheck();
    // check connection partners according to bidirectionla connections
    XMLNodeConnPlausibCheckPartner();
    // check devices for multiports
    XMLNodeConnMultiPortCheck();
    // save all (=0xFFFF) nodes of xml-node-list for auto update
    TopoGenModuleListSave(0xFFFF);

    NoOfXMLNodes = TopoListXML.GetNoOfNodes();

    // for all nodes of xml-node-list
    for(i=0; i<NoOfXMLNodes; i++)
    {
        // set node as not processed yet
        NodeListXMLProcessedInTree[i] = false;
    }
    // run time measurement: beginning of tree generator processing
    RTM.StartRTM(RTMTreeGeneration, "Baumgenerator");

    // init new tree-array object
    TreeArray = new TreeArrayNew();

    for(i=0; i<NoOfXMLNodes; i++)
    {
        // if node (i) is not processed yet
        if(NodeListXMLProcessedInTree[i] == false)
        {
            // this is the first node of a tree
            // add a new tree object to tree-array
            IdxOfTree       = (TreeArray.AddNewTree() - 1);
            // add first node of new tree object to tree
            IdxOfNodeInTree = (TreeArray.AddNewTreeNode() - 1);
            // set index of parent node of this node within new tree; parent index for this node is always its self index
            TreeArray.SetParentIdxOfNode(IdxOfTree, IdxOfNodeInTree, IdxOfNodeInTree);
            // assign nodes reference within xml-node-list to this node within the node tree
            TreeArray.SetIdxOfNodeInXMLList(IdxOfTree, IdxOfNodeInTree, i);
            // assign some attibutes of this node within node tree by copying them from the xml-node-list
            TreeArray.SetNodeName(IdxOfTree,IdxOfNodeInTree, TopoListXML.GetNodeNameAtNodeIdx(i));
            TreeArray.SetNodeAttrib(IdxOfTree,IdxOfNodeInTree, TopoListXML.GetNodeAttribAtIdx(i));
            TreeArray.SetNodeDeviceType(IdxOfTree,IdxOfNodeInTree, TopoListXML.GetNodeDeviceTypeAtIdx(i));
            TreeArray.SetNodeDiagInfo(IdxOfTree,IdxOfNodeInTree, TopoListXML.GetNodeDiagInfoAtIdx(i));
            TreeArray.SetNodeDiagInfoSub(IdxOfTree,IdxOfNodeInTree, TopoListXML.GetNodeDiagInfoSubAtIdx(i));
            TreeArray.SetNodeURL_BGZ(IdxOfTree,IdxOfNodeInTree, TopoListXML.GetNodeURL_BGZAtIdx(i));
            // set this node as already processed
            NodeListXMLProcessedInTree[i] = true;
            // assign the reference of this node in node tree to array of nodes in xml-node-list
            NodeInTreeRefNodeXML.AddNewXMLRef(i,IdxOfTree,0);
            // recursive function call of tree generator to process connections of this node
            TreeGenerate(TopoListXMLSave, IdxOfTree,IdxOfNodeInTree);
        }
     }

     // run time measurement: end of tree generator processing
     RTM.StopRTM(RTMTreeGeneration);

     IdxOfNodeInTree = 0;

     // run time measurement: beginning of node structure generation processing
     RTM.StartRTM(RTMNodeStructureGeneration, "Knotenstruktur");

     // for every tree of tree-array
     for(IdxOfTree = 0; IdxOfTree < TreeArray.GetNoOfTrees(); IdxOfTree++)
     {
         // these functions process the topo design of all node within all trees
         // starting with the first node of every tree
         // 1.relate every node to a vertical column
         TreeCalcNodeVertLayer(IdxOfTree, IdxOfNodeInTree, 0);
         // 2.define the painting side of ring and connector ports of a node
         TreeNodeRingCheck(IdxOfTree, IdxOfNodeInTree);
         // 3.define the height of following node types
         // line, line_last, last, star (only left side)
         TreeCalcNodeStructStarLeftLineLast(IdxOfTree, IdxOfNodeInTree);
         // 4.define the height of a star node and line of nodes
         TreeClacNodeSize(IdxOfTree, IdxOfNodeInTree);
         // 5.set the order of ports depending on node types
         NodeCalcPortPosition(IdxOfTree, IdxOfNodeInTree);
         // 6.define the node position depaneding on node height and node type
         NodeCalcNodePosition(IdxOfTree, IdxOfNodeInTree,0,0);
         // 7.define the position or ring ports at the right side of nodes depending
         // on the position of corresponding port at left side of node
         NodeCalcRingPortPosition(IdxOfTree, IdxOfNodeInTree);
         // 8.define the position of connector and not connected ports within node
         NodeConnectorRightAndUnusedPortPosition(IdxOfTree, IdxOfNodeInTree);
         // 9.crop the node height to the last painted port of a node
         NodeCropYSize(IdxOfTree, IdxOfNodeInTree);
     }

     // run time measurement: end of node structure processing
     RTM.StopRTM(RTMNodeStructureGeneration);
     // process and output the background image for all painted node trees
     TopoPrintSize();

     TopoInitGlobalParamaters();

     // new matrix (background image) size object
     var TreeTableSizeTemp = new MatrixSizeNew();

     TopoHourGlas(0); // hide hourglas

     // run time measurement: beginning of output processing
     RTM.StartRTM(RTMGraphPrint, "Ausgabe: Netzwerk");

     // for every tree of tree-array
     for(IdxOfTree = 0; IdxOfTree < TreeArray.GetNoOfTrees(); IdxOfTree++)
     {
         // paint node div-element and node ports div-elements
         TreeNode2OutputDiv(IdxOfTree, IdxOfNodeInTree, TopoPaintPxOffsetX, PaintOffsetY);
         // paint node connection div-elements
         TreeNode2OutputDivConnections(IdxOfTree, IdxOfNodeInTree, TopoPaintPxOffsetX, PaintOffsetY);
         // get width and height of tree (IdxOfTree)
         TreeTableSizeTemp = TreeMatrixSize.GetMatrixSize(IdxOfTree);
         // increase the height offset position of the next painted tree
         PaintOffsetY += ((TreeTableSizeTemp.SizeY + MatrixModuleSpacingY) * PxMatrixCellSize);
     }

     // run time measurement: end of output processing
     RTM.StopRTM(RTMGraphPrint);
     // if no print output
     if(false == PrintOutput)
     {
         RTM.StopRTM(RTMTopoStart2Net);

        if((0 == TopoGlobalData.GetDebugModeCPU()) || (0 == DebugModeURL))
        {
            // center and highlight selected node for some time
            // only if no debug mode selected
            TopoNodeHighlight();
        }
         // update date and time
         TopoUpdateTimeDate();
         // signal that painting of topology network is ready
         GlobTopoPaintReady = true;

         if((0 == TopoGlobalData.GetDebugModeCPU()) || (0 == DebugModeURL))
         {
             GlobTopoUpdateEnable = true;
         }
     }
}// end of function TopoGraphHandle()

function TopoOverviewHandle()
{
    var TopoBackgroundDiv = "";

    TopoBackgroundDiv = top.document.getElementById("TopoBackgroundDiv");
    if(null != TopoBackgroundDiv) top.document.getElementById("pic").removeChild(TopoBackgroundDiv);    // AP00762625

    TopoHourGlas(1); // display hourglas

    // init new array of tool tips
    ToolTipArray   = new ToolTipArrayNew();

    TopoGenModuleListSave(XMLNodeAttribDevOfProject);
    CalcOverviewMatrix();
    TopoHourGlas(0); // hide hourglas
    PrintOverview();

    if(false == PrintOutput)
    {
        // update date and time
        TopoUpdateTimeDate();
    }

    GlobTopoPaintReady = true;

    if((0 == TopoGlobalData.GetDebugModeCPU()) || (0 == DebugModeURL))
    {
        GlobTopoUpdateEnable = true;
    }
}

function TopoTableHandle()
{
    var TopoBackgroundDiv = "";
    var TopoTableObj = "";
    var TopoTableBodyObj = "";
    var TopoTableAttibObj = "";
    var TopoTable1stHeadRowObj = "";
    var TopoTable2ndHeadRowObj = "";
    var TableDeviceRowObj = "";
    var TableConnRowObj = "";

    var NoOfNodes = 0;
    var NoOfConns = 0;
    var NoS, DevType, NodeAttrib, DiagInfo, DiagSubInfo;
    var NodeURL_BGZ = "";
    var SrcPort, DestNode, DestPort;

    var i, j;

    TopoBackgroundDiv = top.document.getElementById("TopoBackgroundDiv");
    if(null != TopoBackgroundDiv) top.document.getElementById("pic").removeChild(TopoBackgroundDiv);    // AP00762625

    if(true == PrintOutput)
    {
        TopoPrintBackground('auto', 'auto', '#FFFFFF');
    }
    else
    {
        TopoPrintBackground('auto', 'auto', '#EAEAEA');
        TopoHourGlas(1); // display hourglas
    }

    TopoGenModuleListSave(0xFFFF);

    // Table output
    TopoHourGlas(0); // hide hourglas

    TopoTableHeadGlobalTDObj = top.document.createElement("td");

    if(true == PrintOutput)
    {
        TopoTableHeadGlobalTDObj.setAttribute("class", "alarmlistheader");
    }
    else
    {
        TopoTableHeadGlobalTDObj.setAttribute("class", "ContentTableField_1");
    }

    TopoTableGlobalTDObj = top.document.createElement("td");
    if(true == PrintOutput)
    {
        TopoTableGlobalTDObj.setAttribute("class", "aliste");
    }
    else
    {
        TopoTableGlobalTDObj.setAttribute("class", "ContentTableField");
    }

    TopoTableObj = top.document.createElement("table");
    TopoTableObj.id = "TopoTable";
    if(true == PrintOutput)
    {       
        TopoTableGlobalTDObj.setAttribute("class", "alarmtablelist");
    }
    else
    {       
        TopoTableGlobalTDObj.setAttribute("class", "ContentTable");
    }

    TopoTableBodyObj = top.document.createElement("tbody");
    TopoTableObj.appendChild(TopoTableBodyObj);

    OutputDOMObj(TopoTableObj);

    TopoTable1stHeadRowObj = TopoTableGen1stHeadRowObj();
    TopoTableBodyObj.appendChild(TopoTable1stHeadRowObj);

    TopoTable2ndHeadRowObj = TopoTableGen2ndHeadRowObj();
    TopoTableBodyObj.appendChild(TopoTable2ndHeadRowObj);

    NoOfNodes = TopoListXML.GetNoOfNodes();

    for(i = 0; i < NoOfNodes; i++)
    {
        NoS             = TopoListXMLSave.GetNodeNameAtNodeIdx(i);
        DevType         = TopoListXMLSave.GetNodeDeviceTypeAtIdx(i);
        NodeAttrib      = TopoListXMLSave.GetNodeAttribAtIdx(i);
        NodeDiagInfo    = TopoListXMLSave.GetNodeDiagInfoAtIdx(i);
        NodeDiagInfoSub = TopoListXMLSave.GetNodeDiagInfoSubAtIdx(i);

        if(false == PrintOutput)
        {
            NodeURL_BGZ = TopoListXMLSave.GetNodeURL_BGZAtIdx(i);
        }

        TableDeviceRowObj = TopoTableGenDeviceRow(NoS, DevType, NodeAttrib, NodeDiagInfo, NodeDiagInfoSub, NodeURL_BGZ);

        TopoListXMLSave.SetTableDeviceObjTRAtIdx(i, TableDeviceRowObj);

        TopoTableBodyObj.appendChild(TableDeviceRowObj);

        NoOfConns = TopoListXMLSave.GetNoOfConnAtNodeIdx(i);

        for(j = 0; j < NoOfConns; j++)
        {

            SrcPort  = TopoListXMLSave.GetConnDescrSrcPort(i,j);
            DestNode = TopoListXMLSave.GetConnDescrDestNode(i, j);
            DestPort = TopoListXMLSave.GetConnDescrDestPort(i, j);

            TableConnRowObj = TopoTableGenConnRow(SrcPort, DestNode, DestPort);

            TopoTableBodyObj.appendChild(TableConnRowObj);

        }// end of for(j = 0; j < NoOfConns; j++)
    }

    if(false == PrintOutput)
    {
        // update date and time
        TopoUpdateTimeDate();
    }

    GlobTopoPaintReady = true;

    if((0 == TopoGlobalData.GetDebugModeCPU()) || (0 == DebugModeURL))
    {
        GlobTopoUpdateEnable = true;
    }
}

//ContentTableField
function ProcessNodeAttribAtoGif(NodeAttribImgObj, NodeAttrib, GifSizeX, GifSizeY)
{

    NodeAttribImgObj.style.width  = (GifSizeX) + "px";
    NodeAttribImgObj.style.height = (GifSizeY) + "px";

    if(0 == NodeAttrib)
    {
        NodeAttribImgObj.style.width  = (0) + "px";
        NodeAttribImgObj.style.height = (0) + "px";
        NodeAttribImgObj.src = NodeStateAtoGifs[XMLNodeAttribDevOfProject]; // as default gif
    }
    else if (XMLNodeAttribPNIORecReadError == (NodeAttrib & XMLNodeAttribPNIORecReadError))
         {
             NodeAttribImgObj.src = NodeStateAtoGifs[XMLNodeAttribPNIORecReadError];
         }
         else if(XMLNodeAttribPNIORecNotPlaus == (NodeAttrib & XMLNodeAttribPNIORecNotPlaus))
              {
                  NodeAttribImgObj.src = NodeStateAtoGifs[XMLNodeAttribPNIORecNotPlaus];
              }
              else if(XMLNodeAttribDevDeactivated == (NodeAttrib & XMLNodeAttribDevDeactivated))
                   {
                       NodeAttribImgObj.src = NodeStateAtoGifs[XMLNodeAttribDevDeactivated];
                   }
                   else if(XMLNodeAttribDevNotAccessible == (NodeAttrib & XMLNodeAttribDevNotAccessible))
                        {
                            NodeAttribImgObj.src = NodeStateAtoGifs[XMLNodeAttribDevNotAccessible];
                        }
                        else if(XMLNodeAttribDevNext2Project == (NodeAttrib & XMLNodeAttribDevNext2Project))
                             {
                                 NodeAttribImgObj.src = NodeStateAtoGifs[XMLNodeAttribDevNext2Project];
                             }
                             else if(XMLNodeAttribDevOfProject == (NodeAttrib & XMLNodeAttribDevOfProject))
                                  {
                                      NodeAttribImgObj.src = NodeStateAtoGifs[XMLNodeAttribDevOfProject];
                                  }
                                  else
                                  {
                                      console && console.log && console.log("Erronous node attrib!");
                                      NodeAttribImgObj.style.width  = (0) + "px";
                                      NodeAttribImgObj.style.height = (0) + "px";
                                      NodeAttribImgObj.src = NodeStateAtoGifs[XMLNodeAttribDevOfProject];
                                  }
}

function TopoTableGen1stHeadRowObj()
{

    var TableRowObj = "";

    var TableDataPort = "";
    var TableDataPartnerPort = "";

    var TextPort = "";
    var TextPartnerPort = "";

    TextPort = top.document.createTextNode(top.topo_table_port);
    TableDataPort = TopoTableHeadGlobalTDObj.cloneNode(true);
    TableDataPort.colSpan = 4;
    TableDataPort.appendChild(TextPort);

    TextPartnerPort = top.document.createTextNode(top.topo_table_port_partner);
    TableDataPartnerPort = TopoTableHeadGlobalTDObj.cloneNode(true);
    TableDataPartnerPort.colSpan = 2;
    TableDataPartnerPort.appendChild(TextPartnerPort);

    TableRowObj = top.document.createElement("tr");

    TableRowObj.appendChild(TableDataPort);
    TableRowObj.appendChild(TableDataPartnerPort);

    return TableRowObj;
}

function TopoTableGen2ndHeadRowObj()
{

    var TableRowObj = "";

    var TableDataStatus = "";
    var TableDataNameSrc = "";
    var TableDataType = "";
    var TableDataPortSrc = "";
    var TableDataNameDst = "";
    var TableDataPortDst = "";

    var TextStatus = "";
    var TextName = "";
    var TextType = "";
    var TextPort = "";

    TextStatus = top.document.createTextNode(top.topo_table_status);
    TableDataStatus = TopoTableHeadGlobalTDObj.cloneNode(true);
    TableDataStatus.appendChild(TextStatus);

    TextName = top.document.createTextNode(top.topo_table_name);
    TableDataNameSrc = TopoTableHeadGlobalTDObj.cloneNode(true);
    TableDataNameSrc.appendChild(TextName);

    TextType = top.document.createTextNode(top.topo_table_type);
    TableDataType = TopoTableHeadGlobalTDObj.cloneNode(true);
    TableDataType.appendChild(TextType);

    TextPort = top.document.createTextNode(top.topo_table_port);
    TableDataPortSrc = TopoTableHeadGlobalTDObj.cloneNode(true);
    TableDataPortSrc.appendChild(TextPort);

    TableDataNameDst = TableDataNameSrc.cloneNode(true);
    TableDataPortDst = TableDataPortSrc.cloneNode(true);

    TableRowObj = top.document.createElement("tr");

    TableRowObj.appendChild(TableDataStatus);
    TableRowObj.appendChild(TableDataNameSrc);
    TableRowObj.appendChild(TableDataType);
    TableRowObj.appendChild(TableDataPortSrc);
    TableRowObj.appendChild(TableDataNameDst);
    TableRowObj.appendChild(TableDataPortDst);

    return TableRowObj;
}

function ProcessDiagInfoAtoGif(DiagInfoImgObj, DiagInfo, GifSizeX, GifSizeY)
{
    DiagInfoImgObj.style.width  = (GifSizeX) + "px";
    DiagInfoImgObj.style.height = (GifSizeY) + "px";

    switch (parseInt(DiagInfo))
    {
        case DiagAtoGif_Null:
        {
            DiagInfoImgObj.style.width  = (0) + "px";
            DiagInfoImgObj.style.height = (0) + "px";
            DiagInfoImgObj.src = DiagAtoGifs[DiagAtoGif_Null];
            break;
        }

        case DiagAtoGif_Unaccessible:
        case DiagAtoGif_Alarm:
        case DiagAtoGif_Maintenance2:
        case DiagAtoGif_Maintenance1:
        case DiagAtoGif_Ok:
        case DiagAtoGif_Deactivated:
        case DiagAtoGif_NotAvailable:
        case DiagAtoGif_SubFail:
        {
            DiagInfoImgObj.src = DiagAtoGifs[DiagInfo];
            break;
        }

        default:
        {
            console && console.log && console.log("Erronous DiagInfo or DiagSubInfo: " + DiagInfo);
        }
    }
}

function TopoTableGenDeviceRow(Name, Type, NodeAttrib, DiagInfo, DiagSubInfo, NodeURL_BGZ)
{
    var TableRowObj = "";
    var TableRowAttribObj = "";

    var TableDataStatus = "";
    var TableDataName = "";
    var TableDataType = "";
    var TableDataDummy1 = "";
    var TableDataDummy2 = "";
    var TableDataDummy3 = "";

    var NodeAttribImgObj = "";
    var DiagInfoImgObj = "";
    var DiagSubInfoImgObj = "";

    var TextNodeName = "";
    var NodeNameObj = "";
    var TextNodeType = "";

    var NodeStatusText = "";


    // create node state attribute image *****************************************
    NodeAttribImgObj = top.document.createElement("img");

    NodeStatusText = GetNodeStatusText(NodeAttrib, DiagSubInfo);

    NodeAttribImgObj.title = NodeStatusText;

    NodeAttrib &= ~XMLNodeAttribDevTypeIsCPU; // there is no cpu icon

    ProcessNodeAttribAtoGif(NodeAttribImgObj, NodeAttrib, NodeStateIconSizeX, NodeStateIconSizeY);
   //****************************************************************************

    // create diag info image ****************************************************
    DiagInfoImgObj = top.document.createElement("img");
    DiagInfoImgObj.title= "device diagnose";

    ProcessDiagInfoAtoGif(DiagInfoImgObj, DiagInfo, DiagInfoIconSizeX, DiagInfoIconSizeY);
    //****************************************************************************

    // create diag info image ****************************************************
    DiagSubInfoImgObj = top.document.createElement("img");
    DiagSubInfoImgObj.title= "device diagnose subfault";

    ProcessDiagInfoAtoGif(DiagSubInfoImgObj, DiagSubInfo, DiagInfoIconSizeX, DiagInfoIconSizeY);
    //****************************************************************************

//    TableDataText = top.document.createTextNode(Data);

    TableDataStatus = TopoTableGlobalTDObj.cloneNode(true);
    if(true == PrintOutput)
    {
        TableDataStatus.className = "alarmtablelist"; //"TopoState";
    }
    TableDataStatus.appendChild(NodeAttribImgObj);
    TableDataStatus.appendChild(DiagInfoImgObj);
    TableDataStatus.appendChild(DiagSubInfoImgObj);

    TextNodeName = top.document.createTextNode(Name);
    NodeNameObj = BindLink2Obj(NodeURL_BGZ, TextNodeName, 'AnchorObjTable');
    TableDataName = TopoTableGlobalTDObj.cloneNode(true);
    TableDataName.appendChild(NodeNameObj);

    TextNodeType = top.document.createTextNode(Type);
    TableDataType = TopoTableGlobalTDObj.cloneNode(true);
    TableDataType.appendChild(TextNodeType);

    TableDataDummy1 = TopoTableGlobalTDObj.cloneNode(true);
    TableDataDummy2 = TopoTableGlobalTDObj.cloneNode(true);
    TableDataDummy3 = TopoTableGlobalTDObj.cloneNode(true);

    TableRowObj = top.document.createElement("tr");

    TableRowObj.appendChild(TableDataStatus);
    TableRowObj.appendChild(TableDataName);
    TableRowObj.appendChild(TableDataType);
    TableRowObj.appendChild(TableDataDummy1);
    TableRowObj.appendChild(TableDataDummy2);
    TableRowObj.appendChild(TableDataDummy3);

    return TableRowObj;
}

function TopoTableGenConnRow(SrcPort, DestNode, DestPort)
{

    var TableRowObj = "";
    var TableRowAttribObj = "";

    var TableDataDummy1 = "";
    var TableDataDummy2 = "";
    var TableDataDummy3 = "";
    var TableDataSrcPort = "";
    var TableDataDestNode = "";
    var TableDataDestPort = "";

    var TextNodeSrcPort = "";
    var TextNodeDestNode = "";
    var TextNodeDestDestPort = "";

    TableDataDummy1 = TopoTableGlobalTDObj.cloneNode(true);
    TableDataDummy2 = TopoTableGlobalTDObj.cloneNode(true);
    TableDataDummy3 = TopoTableGlobalTDObj.cloneNode(true);

    TextNodeSrcPort = top.document.createTextNode(SrcPort);
    TableDataSrcPort = TopoTableGlobalTDObj.cloneNode(true);
    TableDataSrcPort.appendChild(TextNodeSrcPort);

    TextNodeDestNode = top.document.createTextNode(DestNode);
    TableDataDestNode = TopoTableGlobalTDObj.cloneNode(true);
    TableDataDestNode.appendChild(TextNodeDestNode);

    TextNodeDestDestPort = top.document.createTextNode(DestPort);
    TableDataDestPort = TopoTableGlobalTDObj.cloneNode(true);
    TableDataDestPort.appendChild(TextNodeDestDestPort);

    TableRowObj = top.document.createElement("tr");

    TableRowObj.appendChild(TableDataDummy1);
    TableRowObj.appendChild(TableDataDummy2);
    TableRowObj.appendChild(TableDataDummy3);

    TableRowObj.appendChild(TableDataSrcPort);
    TableRowObj.appendChild(TableDataDestNode);
    TableRowObj.appendChild(TableDataDestPort);

    return TableRowObj;
}

function ProcessImgObjState(ImgObjHead, NodeAttrib)
{
    var NodeSizeXWithBorder = 0;
    var NodeSizeYWithBorder = 0;

    var NodeSizeXWithBorder = NodeSizeX - (2 * ImgObjHeadBorder);
    var NodeSizeYWithBorder = NodeSizeY - (2 * ImgObjHeadBorder);

    ImgObjHead.style.width  = (NodeSizeXWithBorder) + "px";
    ImgObjHead.style.height = (NodeSizeYWithBorder) + "px";
    ImgObjHead.style.borderWidth = (ImgObjHeadBorder) + "px";

    if (XMLNodeAttribDevNext2Project == (NodeAttrib & XMLNodeAttribDevNext2Project))
    {
        if(XMLNodeAttribDevNotAccessible == (NodeAttrib & XMLNodeAttribDevNotAccessible))
        {
            ImgObjHead.src = ModuleAtoGifs[mb_head_not_available];
            ImgObjHead.style.borderStyle = "dashed";
            ImgObjHead.style.borderColor = "#FF2557";
        }
        else
        {
            ImgObjHead.src = ModuleAtoGifs[mb_head_not_of_project];
            ImgObjHead.style.borderStyle = "dashed";
            ImgObjHead.style.borderColor = "#808080";
        }
    }
    else if(XMLNodeAttribDevDeactivated == (NodeAttrib & XMLNodeAttribDevDeactivated))
    {
        ImgObjHead.src = ModuleAtoGifs[mb_head_not_of_project];
        ImgObjHead.style.borderStyle = "solid";
        ImgObjHead.style.borderColor = "#808080";
    }
    else if(XMLNodeAttribDevNotAccessible == (NodeAttrib & XMLNodeAttribDevNotAccessible))
    {
        ImgObjHead.src = ModuleAtoGifs[mb_head_not_available];
        ImgObjHead.style.borderStyle = "solid";
        ImgObjHead.style.borderColor = "#FF2557";
    }
    else if(XMLNodeAttribPNIORecReadError == (NodeAttrib & XMLNodeAttribPNIORecReadError))
    {
        if(("TopoGraph" == ModeGlob) || ("TopoGraphUpdate" == ModeGlob) || ("TopoGraphPrint" == ModeGlob))
        {
            ImgObjHead.src = ModuleAtoGifs[mb_head];
            ImgObjHead.style.borderStyle = "solid";
            ImgObjHead.style.borderColor = "#808080";
        }
        else if(("TopoBrief" == ModeGlob) || ("TopoBriefUpdate" == ModeGlob) || ("TopoBriefPrint" == ModeGlob))
        {
                 ImgObjHead.src = ModuleAtoGifs[mb_head_overview];
                 ImgObjHead.style.borderStyle = "solid";
                 ImgObjHead.style.borderColor = "#a9a9a9";
        }
    }
    else if(XMLNodeAttribPNIORecNotPlaus == (NodeAttrib & XMLNodeAttribPNIORecNotPlaus))
    {   // should never happen but SCALANCE-X208 ...
        ImgObjHead.src = ModuleAtoGifs[mb_head_not_of_project];
        ImgObjHead.style.borderStyle = "solid";
        ImgObjHead.style.borderColor = "#FF2557";
    }
    else if(XMLNodeAttribHighlight == (NodeAttrib & XMLNodeAttribHighlight))
    {
        ImgObjHead.style.borderStyle = "solid";
        ImgObjHead.style.borderColor = "#00FF00";
    }
    else
    {
        if(("TopoGraph" == ModeGlob) || ("TopoGraphUpdate" == ModeGlob) || ("TopoGraphPrint" == ModeGlob))
        {
            ImgObjHead.src = ModuleAtoGifs[mb_head];
            ImgObjHead.style.borderStyle = "solid";
            ImgObjHead.style.borderColor = "#808080";
        }
        else if(("TopoBrief" == ModeGlob) || ("TopoBriefUpdate" == ModeGlob) || ("TopoBriefPrint" == ModeGlob))
        {
            ImgObjHead.src = ModuleAtoGifs[mb_head_overview];
            ImgObjHead.style.borderStyle = "solid";
            ImgObjHead.style.borderColor = "#a9a9a9";
        }
    }
}

/*****************************************************************************/
function TopoNodeHighlight()
{
    var TreeIdx = "";
    var NodeIdx = "";
    var NodeIdxXMLList = "";
    var DivNodeHighlight = "";
    var ImgObj = "";
    var NodePosX = 0;
    var NodePosY = 0;

    TreeIdx = TreeArray.GetNodeHighlightTreeIdx();
    NodeIdx = TreeArray.GetNodeHighlightNodeIdx();

    if(0xFFFF != TreeIdx)
    {
        GlobNodeHighLiEnabled = true;

        NodeIdxXMLList = TreeArray.GetIdxOfNodeInXMLList(TreeIdx, NodeIdx);
        DivNodeHighlight = TopoListXMLSave.GetOverHeadDivObjAtIdx(NodeIdxXMLList);

        NodePosX = DivNodeHighlight.offsetLeft;
        NodePosY = DivNodeHighlight.offsetTop;
        window.scrollTo(NodePosX, NodePosY);

        SetIntervalHighlight = setInterval(CheckIntervalHighlight, 500);
    }
}

function CheckIntervalHighlight()
{
    var TreeIdx = "";
    var NodeIdx = "";
    var NodeIdxXMLList = 0;
    var DivNodeHead = "";
    var ImgObjHead = "";
    var NodeAttrib = "";

    TreeIdx = TreeArray.GetNodeHighlightTreeIdx();
    NodeIdx = TreeArray.GetNodeHighlightNodeIdx();

    NodeIdxXMLList = TreeArray.GetIdxOfNodeInXMLList(TreeIdx, NodeIdx);

    DivNodeHead = TopoListXMLSave.GetOverHeadDivObjAtIdx(NodeIdxXMLList);

    ImgObjHead = DivNodeHead.getElementsByTagName("img")[0];
    NodeAttrib = TreeArray.GetNodeAttrib(TreeIdx, NodeIdx);

    if(0x00 == (HighLiIntervalCount & 0x01))
    {
        ProcessImgObjHead(ImgObjHead, XMLNodeAttribHighlight, DivNodeHead.offsetWidth, DivNodeHead.offsetHeight);
    }
    else
    {
        ProcessImgObjHead(ImgObjHead, NodeAttrib, DivNodeHead.offsetWidth, DivNodeHead.offsetHeight);
    }

    if(HighLiIntervalCount > HighLiIntervalMax)
    {
        ProcessImgObjHead(ImgObjHead, NodeAttrib, DivNodeHead.offsetWidth, DivNodeHead.offsetHeight);
        clearInterval(SetIntervalHighlight);

        GlobNodeHighLiEnabled = false;

         if(true == GlobTopoDiagDataReceived)
         {
             TopoGraphDiag();
         }
    }

    HighLiIntervalCount++;
}

// RTMOutput prints the values of run time measurement in a alert box
function RTMOutput()
{
    console && console.log && console.log(
        RTM.GetRTMid(RTMTopoIFrame) + ": " +
        RTM.GetRTMTime(RTMTopoIFrame) + " [ms]  " +
        RTM.GetPercent(RTMTopoIFrame) + " [%]" + "\n" +

        RTM.GetRTMid(RTMDiagIFrame) + ": " +
        RTM.GetRTMTime(RTMDiagIFrame) + " [ms]  " +
        RTM.GetPercent(RTMDiagIFrame) + " [%]" + "\n" +

        RTM.GetRTMid(RTMPrintInit) + ": " +
        RTM.GetRTMTime(RTMPrintInit) + " [ms]  " +
        RTM.GetPercent(RTMPrintInit) + " [%]" + "\n" +

        RTM.GetRTMid(RTMImportTopoIFrame) + ": " +
        RTM.GetRTMTime(RTMImportTopoIFrame) + " [ms]  " +
        RTM.GetPercent(RTMImportTopoIFrame) + " [%]" + "\n" +

        RTM.GetRTMid(RTMImportDiagIFrame) + ": " +
        RTM.GetRTMTime(RTMImportDiagIFrame) + " [ms]  " +
        RTM.GetPercent(RTMImportDiagIFrame) + " [%]" + "\n" +

        RTM.GetRTMid(RTMTreeGeneration) + ": " +
        RTM.GetRTMTime(RTMTreeGeneration) + " [ms]  " +
        RTM.GetPercent(RTMTreeGeneration) + " [%]" + "\n" +

        RTM.GetRTMid(RTMNodeStructureGeneration) + ": " +
        RTM.GetRTMTime(RTMNodeStructureGeneration) + " [ms]  " +
        RTM.GetPercent(RTMNodeStructureGeneration) + " [%]" + "\n" +

        RTM.GetRTMid(RTMGraphPrint) + ": " +
        RTM.GetRTMTime(RTMGraphPrint) + " [ms]  " +
        RTM.GetPercent(RTMGraphPrint) + " [%]" + "\n" +

        RTM.GetRTMid(RTMDiagPrint) + ": " +
        RTM.GetRTMTime(RTMDiagPrint) + " [ms]  " +
        RTM.GetPercent(RTMDiagPrint) + " [%]" + "\n" +

        RTM.GetRTMid(RTMTopoStart2Net) + ": " +
        RTM.GetRTMTime(RTMTopoStart2Net) + " [ms]  " +
        RTM.GetPercent(RTMTopoStart2Net) + " [%]" + "\n" +

        RTM.GetRTMid(RTMTopoStart2Diag) + ": " +
        RTM.GetRTMTime(RTMTopoStart2Diag) + " [ms]  " +
        RTM.GetPercent(RTMTopoStart2Diag) + " [%]" + "\n" +

        "Summe: " + RTM.GetTimeSum() + " [ms]"
    );
}

// RTMOutputCPU prints the values of run time measurement in a alert box
function RTMOutputCPU()
{
    var time_iframe_topo       = RTM.GetRTMTime(RTMTopoIFrame);        // Topo Request IFrame
    var time_iframe_diag       = RTM.GetRTMTime(RTMDiagIFrame);        // Diagnose Request IFrame
    var time_load_topo         = RTM.GetRTMTime(RTMImportTopoIFrame);  // Datenimport Topo
    var time_load_diag         = RTM.GetRTMTime(RTMImportDiagIFrame);  // Datenimport Diagnose
    var time_algo              = RTM.GetRTMTime(RTMPrintInit) + RTM.GetRTMTime(RTMTreeGeneration) + RTM.GetRTMTime(RTMNodeStructureGeneration); // Ausgabe Init / Baumgenerator / Knotenstruktur
    var time_disp_topo_out     = RTM.GetRTMTime(RTMGraphPrint);        // Ausgabe Topo
    var time_disp_diag_out     = RTM.GetRTMTime(RTMDiagPrint);         // Ausgabe Diagnose
    var time_disp_topo_browser = RTM.GetRTMTime(RTMTopoStart2Net);     // Ausgabe Topo Browser
    var time_disp_diag_browser = RTM.GetRTMTime(RTMTopoStart2Diag) - time_disp_topo_browser;    // Ausgabe Diagnose Browser

    var time_measure           = TopoGlobalData.GetRecordValAtVar("Time_Measure"); // gets variable value stuck to variable name stored in global data
    var time_get_pnio_recs     = TopoGlobalData.GetRecordValAtVar("Time_GetPnioRecs");
    var time_get_comp_stat     = TopoGlobalData.GetRecordValAtVar("Time_GetCompStat");
    var time_total_toporq      = TopoGlobalData.GetRecordValAtVar("Time_Total_TopoRQ");
    var time_total_diagrq      = TopoGlobalData.GetRecordValAtVar("Time_Total_DiagRQ");
    var time_MWSL_TopoRequest  = TopoGlobalData.GetRecordValAtVar("Time_MWSL_TopoRQ");
    var time_MWSL_DiagRequest  = TopoGlobalData.GetRecordValAtVar("Time_MWSL_DiagRQ");

    if (time_measure == 4)
    {
        console && console.log && console.log(
            "Datenausgabezyklus\n\n" +
            "Server TopoAppl    : Read PNIO records: "                        + time_get_pnio_recs     + " [ms]\n"   +
            "Server TopoAppl    : Get diagnostics with SFM: "                 + time_get_comp_stat     + " [ms]\n"   +
            "Server TopoAppl    : Total Topo request: "                       + time_total_toporq      + " [ms]\n"   +
            "Server TopoAppl    : Total Diagnosis request: "                  + time_total_diagrq      + " [ms]\n\n" +
            "Server MiniWebCore : MWSL Topo response: "                       + time_MWSL_TopoRequest  + " [ms]\n"   +
            "Server MiniWebCore : MWSL Diagnosis response: "                  + time_MWSL_DiagRequest  + " [ms]\n\n" +
            "Client/Server      : Total Topology Server Response (IFrame): "  + time_iframe_topo       + " [ms]\n"   +
            "Client/Server      : Total Diagnosis Server Response (IFrame): " + time_iframe_diag       + " [ms]\n\n" +
            "Client             : Import Topology XML Data: "                 + time_load_topo         + " [ms]\n"   +
            "Client             : Import Diagnosis XML Data: "                + time_load_diag         + " [ms]\n"   +
            "Client             : Topology Algorithm: "                       + time_algo              + " [ms]\n"   +
            "Client             : Topology Display Output: "                  + time_disp_topo_out     + " [ms]\n"   +
            "Client             : Diagnosis Display Output: "                 + time_disp_diag_out     + " [ms]\n\n" +
            "Client             : First Appearance Topology Display: "        + time_disp_topo_browser + " [ms]\n"   +
            "Client             : Additional Diagnosis Display: "             + time_disp_diag_browser + " [ms]\n"
        );
    }
    if ((time_measure >= 1) && (time_measure <= 3))
    {
        console && console.log && console.log(
            "Datenmesszyklus: Zur Ausgabe der Messdaten Seite nochmals laden (F5)\n\n"
            );
    }
}


function DebugOutput()
{
    var DebugModeCPU = TopoGlobalData.GetDebugModeCPU();

    switch(DebugModeURL)
    {
        // band of numbers for the "Debug" url parameter regarding CPU debug output
        // 1..99
        case 0: // Debug mode URL do nothing
        {
            break;
		}

        case 2: // Debug mode URL to enable CPU run time data
        {
            if(1 == DebugModeCPU)
            {
                RTMOutputCPU();
            }
            break;
		}

        // band of numbers for the "Debug" url parameter regarding client internal debug output
        // 10..
        case 100: // Debug mode URL XML data will be printed as a table, will be moved into here later
        {
            TopoPutTable();
            // DOM-Iframe with xml data will be deleted
            top.document.getElementById("XMLData").removeChild(IframeObjXMLData);
            // DOM-Iframe with xml data will be deleted
            top.document.getElementById("XMLData").removeChild(IframeObjXMLDiag);
            break;
		}

        case 101: // Debug mode URL for JavaScript internal run time measurement output
        {
            RTMOutput();
            break;
		}

        case 102: // Debug mode URL for XML-structure output of topo device data
        {
            TopoXMLTableOutput(IframeObjXMLData);
            // DOM-Iframe with xml data will be deleted
            top.document.getElementById("XMLData").removeChild(IframeObjXMLData);
            // DOM-Iframe with xml data will be deleted
            top.document.getElementById("XMLData").removeChild(IframeObjXMLDiag);
            break;
		}

        case 103: // Debug mode URL for XML-structure output of diag device data
        {
            TopoXMLTableOutput(IframeObjXMLDiag);
            // DOM-Iframe with xml data will be deleted
            top.document.getElementById("XMLData").removeChild(IframeObjXMLData);
            // DOM-Iframe with xml data will be deleted
            top.document.getElementById("XMLData").removeChild(IframeObjXMLDiag);
            break;
		}

        default:
        {
            console && console.log && console.log("Erroneous URL debug mode:" + DebugModeURL);
            break;
		}
	}
}

// ret
// 1 - ok
// 2 - busy
// 0 - not ok
function CheckIframeXML()
{
    var IframeDataRet = 1;

    //check if Iframe has correct data
    if(0 == IframeObjXMLData.contentWindow.document.body.childNodes.length)
    {
        // received IFrame data is corrupt
        IframeDataRet = 0;

        TopoHourGlas(0); // hide hourglas
    }
    else
    {
    	var text = IframeObjXMLData.contentWindow.document.body.childNodes[0].childNodes[1].childNodes[1].innerHTML;
    	if(text == "busy")
    	{
          IframeDataRet = 2;   //busy
          TopoHourGlas(0); // hide hourglas
    	}
    }

    return IframeDataRet;
}

function CheckIframeDiag()
{
    var IframeDataOK = true;

    //check if Iframe has correct data
    if(0 == IframeObjXMLDiag.contentWindow.document.body.childNodes.length)
    {
        // received IFrame data is corrupt
        IframeDataOK = false;
    }

    return IframeDataOK;
}

// ReceivedXMLData is called when Iframe (xml-data) reception is completed
function ReceivedXMLData()
{
    RTM.StartRTM(RTMDiagIFrame, "IFrame: Diag");
    // get additional diagnostic data
    //TopoGetXMLDiag();
    ProcessDataNet();
}

// ReceivedXMLData is called when Iframe (xml-data) reception is completed
function ReceivedXMLDiag()
{
    ProcessDataDiag();
}

function ProcessDataNet()
{
	var ret = CheckIframeXML();
    if(ret == 1)
    {
        GlobTopoNetDataReceived = true;
        switch(ModeGlob)
        {
            case "TopoGraph":
//          case "TopoGraphPrint": no print page for topo graph
            case "TopoTable":
            case "TopoTablePrint":
            case "TopoBrief":
            case "TopoBriefPrint":
            {
                TopoContinue();
                break;
            }

            case "TopoGraphUpdate":
            {
            	if(TopoListXMLSave=="")
            	{
            		TopoContinue();
            	}
            	else
            	{
                    TopoGraphUpdate();
            	}
                break;
            }

            case "TopoBriefUpdate":
            {
            	if(TopoListXMLSave=="")
            	{
            		TopoContinue();
            	}
            	else
            	{
                	TopoOverviewUpdate();
            	}
                break;
            }

            case "TopoTableUpdate":
            {
            	if(TopoListXMLSave=="")
            	{
            		TopoContinue();
            	}
            	else
            	{
                	TopoTableUpdate();
            	}
                break;
            }

            default:
            {
                console && console.log && console.log("Erroneous global mode @ TopoNet-IFrame response (Mode->):" + ModeGlob);
            }
        }
    }
    else if(ret == 2)
    {
        // if busy do nothing than the next update
        if(0 == DebugModeURL)
        {
            GlobTopoUpdateEnable = true;
        }
    }
    else
    {
    	console && console.log && console.log("TopoDataNet: No IFrame data!");
    }
}

function ProcessDataDiag()
{
    RTM.StopRTM(RTMDiagIFrame);

    if(CheckIframeDiag())
    {
        if(103 == DebugModeURL)
        {
            // additional import of diag global data, because of fast diag-iframe processing
            // import global data from the Iframe into the Topo-JavaScript
            TopoGlobalData = new TopoGlobalData_New();
            TopoGenGlobalData(TopoGlobalData, IframeObjXMLDiag);
            // debug mode has to be called here because of debug table output and direct iframe-access
            DebugOutput();
        }
        else
        {
            GlobTopoDiagDataReceived = true;

            if(true == GlobTopoNetDataReceived)
            {
                // check if painting of network ready
                // yes -> update node and connection stati
                // no  -> do nothing; after painting of network is finished, node and connection stati will be updated
                if(true == GlobTopoPaintReady)
                {
	                switch(ModeGlob)
	                {
	                    case "TopoGraph":
              //        case "TopoGraphPrint": no print page for topo graph
	                    case "TopoGraphUpdate":
	                    {
	                        TopoGraphDiag();
	                        break;
	                    }

	                    case "TopoBrief":
	                    case "TopoBriefPrint":
	                    case "TopoBriefUpdate":
	                    {
                            TopoOverviewDiag();
	                        break;
	                    }

	                    case "TopoTable":
	                    case "TopoTableUpdate":
	                    case "TopoTablePrint":
	                    {
                            TopoTableDiag();
	                        break;
	                    }

	                    default:
	                    {
                            console && console.log && console.log("Erroneous global mode @ TopoDiag-IFrame response (Mode->):" + ModeGlob);
	                    }
                     }
                }
            }
            else
            {
                GlobTopoNetDataReceived = false;
                GlobTopoDiagDataReceived = false;
                GlobTopoUpdateEnable = true;
            }
        }
    }
    else
    {
        console && console.log && console.log("TopoDataDiag: No IFrame data!");
    }
}

// TopoGetXMLNet creates a Iframe and ataches it to the DOM-tree
function TopoGetXMLNet()
{
    var URL_Para_String = location.search;
    var URL_Para;

    var Dummy = 0;

    GlobTopoNetDataReceived = false;

    IframeObjXMLData = top.document.createElement("iframe");
    IframeObjXMLData.name = "TopoXMLData";
    IframeObjXMLData.id = "TopoXMLData";
    IframeObjXMLData.scrolling = "yes";
    IframeObjXMLData.width = "0px";
    IframeObjXMLData.height = "0px";
    IframeObjXMLData.frameBorder = "0";

    // set supported event listener depending on browser engine
    // and set trigger function if load of Iframe is completed
    if(window.addEventListener)
    {
        IframeObjXMLData.addEventListener("load", ReceivedXMLData, false); // FF
    }
    else if(window.attachEvent)
    {
        IframeObjXMLData.attachEvent("onload", ReceivedXMLData);
    }
    else
    {
        IframeObjXMLData.onload = ReceivedXMLData;
    }

    URL_Para = URL_Para_String.replace ("?","");
    if (URL_Para.search(/&Sel=/) == -1)
        URL_Para = URL_Para + '&Sel=Soll';
    IframeObjXMLData.src = '../ClientArea/TopoDataNet.mwsl?TopoMode=' + Dummy + '&TopoDbg=' + DebugModeURL + '&' + URL_Para;

    top.document.getElementById("XMLData").appendChild(IframeObjXMLData);

    // activate interval function to check if Iframe reception is completed
    switch(ModeGlob)
    {
        case "TopoGraph":
        case "TopoGraphUpdate":
//        case "TopoGraphPrint": no print page for topo graph
        case "TopoBrief":
        case "TopoBriefUpdate":
        case "TopoBriefPrint":
        case "TopoTable":
        case "TopoTableUpdate":
        case "TopoTablePrint":
        {
            break;
        }

        default:
        {
            console && console.log && console.log("Erroneous Topo-IFrame request mode:" + ModeGlob);
        }
    }
}

// TopoGetXMLDiag creates a Iframe and ataches it to the DOM-tree
function TopoGetXMLDiag()
{
    var URL_Para_String = location.search;
    var URL_Para;

    var Dummy = 0;

    GlobTopoDiagDataReceived = false;

    IframeObjXMLDiag = top.document.createElement("iframe");

    IframeObjXMLDiag.name = "TopoXMLDiag";
    IframeObjXMLDiag.id = "TopoXMLDiag";
    IframeObjXMLDiag.scrolling = "yes";
    IframeObjXMLDiag.width = "0px";
    IframeObjXMLDiag.height = "0px";
    IframeObjXMLDiag.frameBorder = "0";

    // set supported event listener depending on browser engine
    // and set trigger function if load of Iframe is completed
    if(window.addEventListener)
    {
        IframeObjXMLDiag.addEventListener("load", ReceivedXMLDiag, false); // FF
    }
    else if(window.attachEvent)
    {
        IframeObjXMLDiag.attachEvent("onload", ReceivedXMLDiag);
    }
    else
    {
        IframeObjXMLDiag.onload = ReceivedXMLDiag;
    }

    URL_Para = URL_Para_String.replace ("?","");
    if (URL_Para.search(/&Sel=/) == -1)
        URL_Para = URL_Para + '&Sel=Soll';
    IframeObjXMLDiag.src = '../ClientArea/TopoDataDiag.mwsl?TopoMode=' + Dummy + '&TopoDbg=' + DebugModeURL + '&' + URL_Para;

    top.document.getElementById("XMLData").appendChild(IframeObjXMLDiag);

    // activate interval functions to check if Iframe reception is completed

    switch(ModeGlob)
    {
        case "TopoGraph":
        case "TopoGraphUpdate":
//        case "TopoGraphPrint": no print page for topo graph
        case "TopoBrief":
        case "TopoBriefUpdate":
        case "TopoBriefPrint":
        case "TopoTable":
        case "TopoTableUpdate":
        case "TopoTablePrint":
        {
            break;
        }

        default:
        {
            console && console.log && console.log("Erroneous Diag-IFrame request mode:" + ModeGlob);
        }
    }
}

// TopoUpdateCheck is called by the auto update
function TopoUpdateCheck(mode)
{
    if((GlobTopoUpdateEnable) && (!GlobNodeHighLiEnabled))
    {
        ModeGlob = mode;
        // disable auto update during running update process
        GlobTopoUpdateEnable = false;
        // start update of graphical topo view
        TopoGetXMLNet();
    }
}

// TopoUpdateTimeDate updates the date and time values at graphical view of topology and topology overview
function TopoUpdateTimeDate()
{
    var dateSpan = top.document.getElementById("date");
    var timeSpan = top.document.getElementById("time");
    
    dateSpan.innerHTML = TopoListXML.GetNodesDate();
    timeSpan.innerHTML = TopoListXML.GetNodesTime();
}

// TopoGraphUpdate checks if topology changed and update is necessary
function TopoGraphUpdate()
{
    var TopoEqual = false;
    // import global data from the Iframe into the Topo-JavaScript
    TopoGlobalData = new TopoGlobalData_New();
    TopoGenGlobalData(TopoGlobalData, IframeObjXMLData);
    // import topology data from the Iframe into the Topo-JavaScript
    TopoListXML = new NodeListXML_New();
    TopoGenModuleList(TopoListXML, IframeObjXMLData);
    // compare if topology changed
    TopoEqual = TopoCompareGraphTopology(TopoListXMLSave, TopoListXML);

    if(false == TopoEqual)
    {
        // topology changed -> new topo calculation
        TopoGraphHandle();
    }
    else 
    {
        RTM.StartRTM(RTMDiagPrint, "Ausgabe: Diagnose");
        // topology didn't change ->
        // update device stati and
    	TopoOverviewUpdateNodes(TopoListXMLSave, TopoListXML);
        // update connection stati
        TopoUpdateNodePortConnStati(TopoListXMLSave, TopoListXML);
        RTM.StopRTM(RTMDiagPrint);

        DebugOutput();
    }
    if((0 == TopoGlobalData.GetDebugModeCPU()) || (0 == DebugModeURL))
    {
        GlobTopoUpdateEnable = true;
    }
}

// TopoGraphDiag checks if topology changed
// -> if yes error; network of IFrame-TopoXMLData and IFrame-TopoXMLDiag should be equal
function TopoGraphDiag()
{
    var TopoEqual = false;
    if(false == GlobNodeHighLiEnabled)
    {
        RTM.StartRTM(RTMImportDiagIFrame, "Datenimport: IFrameDiag");
        // import global data from the Iframe into the Topo-JavaScript
        TopoGlobalData = new TopoGlobalData_New();
        TopoGenGlobalData(TopoGlobalData, IframeObjXMLDiag);
        // import topology data from the Iframe into a Topo-JavaScript
        TopoListXMLDiag = new NodeListXML_New();
        TopoGenModuleList(TopoListXMLDiag, IframeObjXMLDiag);

        RTM.StopRTM(RTMImportDiagIFrame);
        // compare if topology changed
        TopoEqual = TopoCompareGraphTopology(TopoListXMLSave, TopoListXMLDiag);

        if(TopoEqual)
        {
            RTM.StartRTM(RTMDiagPrint, "Ausgabe: Diagnose");
            // topology didn't change ->
            // update device stati and
            TopoOverviewUpdateNodes(TopoListXMLSave, TopoListXMLDiag);
            // update connection stati
            TopoUpdateNodePortConnStati(TopoListXMLSave, TopoListXMLDiag);

            RTM.StopRTM(RTMDiagPrint);
            RTM.StopRTM(RTMTopoStart2Diag);

            DebugOutput();
        }
        else
        {
//                alert("Error: Network and diagnostic XML-data do not match!")
        }

        if((0 == TopoGlobalData.GetDebugModeCPU()) || (0 == DebugModeURL))
        {
            GlobTopoUpdateEnable = true;
        }
    }
}

// TopoOverviewUpdate checks if topo overview changed and update is necessary
function TopoOverviewUpdate()
{
    var TopoEqual = false;

    // import global data from the Iframe into the Topo-JavaScript
    TopoGlobalData = new TopoGlobalData_New();
    TopoGenGlobalData(TopoGlobalData, IframeObjXMLData);
    // import topology data from the Iframe into a Topo-JavaScript
    TopoListXML = new NodeListXML_New();
    TopoGenModuleList(TopoListXML, IframeObjXMLData);
    // compare if topo overview changed
    TopoEqual = TopoCompareOverviewTopology(TopoListXMLSave, TopoListXML); // AP00762625
    if(false == TopoEqual)
    {
        // topo overview changed -> new topo overview calculation
        TopoOverviewHandle();                  // AP00762625
    }
    else
    {
    	TopoOverviewUpdateNodes(TopoListXMLSave, TopoListXML);
    }

    if((0 == TopoGlobalData.GetDebugModeCPU()) || (0 == DebugModeURL))
    {
        GlobTopoUpdateEnable = true;
    }
}

// TopoOverviewDiag checks if topo overview changed and update is necessary
function TopoOverviewDiag()
{
    var TopoEqual = false;
    // import global data from the Iframe into the Topo-JavaScript
    TopoGlobalData = new TopoGlobalData_New();
    TopoGenGlobalData(TopoGlobalData, IframeObjXMLDiag);
    // import topology data from the Iframe into a Topo-JavaScript
    TopoListXMLDiag = new NodeListXML_New();
    TopoGenModuleList(TopoListXMLDiag, IframeObjXMLDiag);
    // compare if topo overview changed
    TopoEqual = TopoCompareOverviewTopology(TopoListXMLSave, TopoListXMLDiag); // AP00762625
    if(TopoEqual)
    {
        // topo overview didn't change -> update device stati
        TopoOverviewUpdateNodes(TopoListXMLSave, TopoListXMLDiag);
    }
    else
    {
//        alert("Error: TopoOverview: Network and diagnostic XML-data do not match!")
    }

    GlobTopoUpdateEnable = true;
}

// TopoTableUpdate checks if topo overview changed and update is necessary
function TopoTableUpdate()
{
    var TopoEqual = false;

    // import global data from the Iframe into the Topo-JavaScript
    TopoGlobalData = new TopoGlobalData_New();
    TopoGenGlobalData(TopoGlobalData, IframeObjXMLData);
    // import topology data from the Iframe into a Topo-JavaScript
    TopoListXML = new NodeListXML_New();
    TopoGenModuleList(TopoListXML, IframeObjXMLData);
    // compare if topo overview changed
    TopoEqual = TopoCompareGraphTopology(TopoListXMLSave, TopoListXML); // AP00762625
    if(false == TopoEqual)
    {
        // topo table changed -> new topo table calculation
        TopoTableHandle();
    }
    else 
    {
    	// topo table has not changed -> update only diag
    	TopoOverviewUpdateNodes(TopoListXMLSave, TopoListXML);
    }
    if((0 == TopoGlobalData.GetDebugModeCPU()) || (0 == DebugModeURL))
    {
        GlobTopoUpdateEnable = true;
    }
}


// TopoTableDiag checks if topo overview changed and update is necessary
function TopoTableDiag()
{
    var TopoEqual = false;
    // import global data from the Iframe into the Topo-JavaScript
    TopoGlobalData = new TopoGlobalData_New();
    TopoGenGlobalData(TopoGlobalData, IframeObjXMLDiag);
    // import topology data from the Iframe into a Topo-JavaScript
    TopoListXMLDiag = new NodeListXML_New();
    TopoGenModuleList(TopoListXMLDiag, IframeObjXMLDiag);
    // compare if topo overview changed
    TopoEqual = TopoCompareGraphTopology(TopoListXMLSave, TopoListXMLDiag);
    if(TopoEqual)
    {
        // topo overview didn't change -> update device stati
        TopoOverviewUpdateNodes(TopoListXMLSave, TopoListXMLDiag);
    }
    else
    {
//        alert("Error: TopoTable: Network and diagnostic XML-data do not match!")
    }

    GlobTopoUpdateEnable = true;
}

// TopoOverviewUpdateNodes checks if node attibute, diag info or diag sub info changed
function TopoOverviewUpdateNodes(TopoXMLSaved, TopoXMLNew)
{
    var NoOfNodes = 0;
    var NodeIdxUpd = 0;

    var NodeName = "", NodeNameUpd = "";
    var NodeAttrib = 0, NodeAttribUpd = 0;
    var NodeDeviceType = "", NodeDeviceTypeUpd = "";
    var NodeDiagInfo = "", NodeDiagInfoUpd = "";
    var NodeDiagInfoSub = "", NodeDiagInfoSubUpd = "";
    var NodeURL_BGZ = "", NodeURL_BGZUpd = "";


    var OverHeadDivObj = "";
    var OverDiagInfoDivObj = "";
    var OverDiagInfoSubDivObj = "";
    var OverDeviceTypeDivObj = "";
    var OverNodeURL_BGZObj = "";

    var TableStatusImgObj = "";

    // tool tip processing
    var ReferenceID = 0;
    var ToolTipIdx = 0;

    var i = 0;
/****************************************************************************************/

    NoOfNodes = TopoXMLSaved.GetNoOfNodes();
    for(i = 0; i < NoOfNodes; i++)
    {
        NodeName = TopoXMLSaved.GetNodeNameAtNodeIdx(i);
        NodeIdxUpd = TopoXMLNew.GetIdxOfNodeByName(NodeName);
        if(null != NodeIdxUpd)
        {
            NodeURL_BGZ = TopoXMLSaved.GetNodeURL_BGZAtIdx(i);
            NodeURL_BGZUpd = TopoXMLNew.GetNodeURL_BGZAtIdx(NodeIdxUpd);
            OverNodeURL_BGZObj = TopoXMLSaved.GetOverNodeURL_BGZObjAtIdx(i);

            /***********************************************************************/
            // check node attribute ************************************************
            NodeAttrib =    TopoXMLSaved.GetNodeAttribAtIdx(i);
            NodeAttribUpd = TopoXMLNew.GetNodeAttribAtIdx(NodeIdxUpd);

            if(NodeAttrib != NodeAttribUpd)
            {
                TopoXMLSaved.SetNodeAttribAtIdx(i, NodeAttribUpd);

                if(("TopoTable" == ModeGlob) ||
                   ("TopoTablePrint" == ModeGlob) ||
                   ("TopoTableUpdate" == ModeGlob))
                {
                    TableStatusImgObj = TopoTableGetNodeStatusImgObj(i, TableStatusImgObjPosAttrib)
                    ProcessNodeAttribAtoGif(TableStatusImgObj, NodeAttribUpd, NodeStateIconSizeX, NodeStateIconSizeY);
                }
                else
                {
                    // TopoGraph... + TopoBrief
                    TopoOverChangeNodeAttribute(i, NodeAttribUpd);
                }
            }
            /***********************************************************************/
            // check node diag info*************************************************
            NodeDiagInfo    = TopoXMLSaved.GetNodeDiagInfoAtIdx(i);
            NodeDiagInfoUpd = TopoXMLNew.GetNodeDiagInfoAtIdx(NodeIdxUpd);

            if(NodeDiagInfo != NodeDiagInfoUpd)
            {
                TopoXMLSaved.SetNodeDiagInfoAtIdx(i, NodeDiagInfoUpd);

                OverDiagInfoDivObj = TopoXMLSaved.GetOverDiagInfoDivObjAtIdx(i);

                if(("TopoTable" == ModeGlob) ||
                   ("TopoTablePrint" == ModeGlob) ||
                   ("TopoTableUpdate" == ModeGlob))
                {
                    TableStatusImgObj = TopoTableGetNodeStatusImgObj(i, TableStatusImgObjPosDiag);
                    ProcessDiagInfoAtoGif(TableStatusImgObj, NodeDiagInfoUpd, DiagInfoIconSizeX, DiagInfoIconSizeY);
                }
                else
                {
                    // TopoGraph... + TopoBrief
                    TopoOverChangeDiagInfo(OverDiagInfoDivObj, NodeDiagInfoUpd);
                }
            }
            /***********************************************************************/
            // check node diag info sub ********************************************
            NodeDiagInfoSub    = TopoXMLSaved.GetNodeDiagInfoSubAtIdx(i);
            NodeDiagInfoSubUpd = TopoXMLNew.GetNodeDiagInfoSubAtIdx(NodeIdxUpd);

            if(NodeDiagInfoSub != NodeDiagInfoSubUpd)
            {
                TopoXMLSaved.SetNodeDiagInfoSubAtIdx(i, NodeDiagInfoSubUpd);

                OverDiagInfoSubDivObj = TopoListXMLSave.GetOverDiagInfoSubDivObjAtIdx(i);

                if(("TopoTable" == ModeGlob) ||
                   ("TopoTablePrint" == ModeGlob) ||
                   ("TopoTableUpdate" == ModeGlob))
                {
                    TableStatusImgObj = TopoTableGetNodeStatusImgObj(i, TableStatusImgObjPosSubDiag);
                    ProcessDiagInfoAtoGif(TableStatusImgObj, NodeDiagInfoSubUpd, DiagInfoIconSizeX, DiagInfoIconSizeY);
                }
                else
                {
                    // TopoGraph... + TopoBrief
                    TopoOverChangeDiagInfo(OverDiagInfoSubDivObj, NodeDiagInfoSubUpd);
                }
            }
            /***********************************************************************/
            // check device type text **********************************************
            /* device type never changes!
            NodeDeviceType = TopoListXMLSave.GetNodeDeviceTypeAtIdx(i);
            NodeDeviceTypeUpd = TopoListXML.GetNodeDeviceTypeAtIdx(NodeIdxUpd);

            if(NodeDeviceType != NodeDeviceTypeUpd)
            {
                TopoListXMLSave.SetNodeDeviceTypeAtIdx(i, NodeDeviceTypeUpd);

                OverDeviceTypeDivObj = TopoListXMLSave.GetOverDeviceTypeDivObjAtIdx(i);
                // update device type at tool tip
                ReferenceID = OverDeviceTypeDivObj.id;
                ToolTipIdx = ToolTipArray.GetTooTipIdxByReferenceID(ReferenceID);
                SetToolTipDevType(ToolTipIdx, NodeDeviceTypeUpd);
            }
            */
        }
    }

    if(false == PrintOutput)
    {
        // update date and time
        TopoUpdateTimeDate();
    }
}
/****************************************************************************************/
function TopoOverChangeDiagInfo(DiagInfoObj, DiagInfo)
{
    if(0 == DiagInfo)
    {
        DiagInfoObj.style.zIndex = '9';
    }
    else
    {
        DiagInfoObj.getElementsByTagName("img")[0].src = DiagAtoGifs[DiagInfo];
        DiagInfoObj.style.zIndex = '12';
    }
}


function TopoOverChangeNodeAttribute(NodeIdx, NodeAttribUpd)
{
    var OverHeadDivObj = "";
    var OverDiagInfoDivObj = "";
    var OverDiagInfoSubDivObj = "";
    var OverNodeNameDivObj = "";
    var OverDeviceTypeDivObj = "";
    var NodeSizeX = 0;
    var NodeSizeY = 0;
    // tool tip processing
    var ReferenceID = 0;
    var ToolTipIdx = 0;

    OverHeadDivObj        = TopoListXMLSave.GetOverHeadDivObjAtIdx(NodeIdx);
    OverDiagInfoDivObj    = TopoListXMLSave.GetOverDiagInfoDivObjAtIdx(NodeIdx);
    OverDiagInfoSubDivObj = TopoListXMLSave.GetOverDiagInfoSubDivObjAtIdx(NodeIdx);
    OverNodeNameDivObj    = TopoListXMLSave.GetOverNodeNameDivObjAtIdx(NodeIdx);
    OverDeviceTypeDivObj  = TopoListXMLSave.GetOverDeviceTypeDivObjAtIdx(NodeIdx);

    NodeSizeX = OverHeadDivObj.offsetWidth;
    NodeSizeY = OverHeadDivObj.offsetHeight;

    ProcessImgObjHead(OverHeadDivObj.getElementsByTagName("img")[0], NodeAttribUpd, NodeSizeX, NodeSizeY);
    OverDiagInfoDivObj.setAttribute("class", ProcessAttribObjStyle(NodeAttribUpd));
    OverDiagInfoSubDivObj.setAttribute("class", ProcessAttribObjStyle(NodeAttribUpd));
    OverNodeNameDivObj.setAttribute("class", ProcessAttribObjStyle(NodeAttribUpd));
    OverNodeNameDivObj.setAttribute("class", ProcessAttribObjStyle(NodeAttribUpd));

    if(3 != OverNodeNameDivObj.childNodes[0].nodeType)
    {
        // DOM-nodetype is no text node; => node is a anchor
        ProcessStyleTextColor(OverNodeNameDivObj.getElementsByTagName("a")[0],
                              OverNodeNameDivObj.getAttributeNode("class").nodeValue);
        ProcessStyleTextColor(OverDeviceTypeDivObj.getElementsByTagName("a")[0],
                              OverDeviceTypeDivObj.getAttributeNode("class").nodeValue);
    }
    else
    {
        // DOM-nodetype is a text node
        ProcessStyleTextColor(OverNodeNameDivObj,
                              OverNodeNameDivObj.getAttributeNode("class").nodeValue);
        ProcessStyleTextColor(OverDeviceTypeDivObj,
                              OverDeviceTypeDivObj.getAttributeNode("class").nodeValue);
    }

    if(false == PrintOutput)
    {
        // update device status at tool tip
        ReferenceID = OverHeadDivObj.id;
        ToolTipIdx = ToolTipArray.GetTooTipIdxByReferenceID(ReferenceID);
        SetToolTipTextStatus(ToolTipIdx, NodeAttribUpd);
    }
}

// TopoUpdateNodePortConnStati checks if multi-port and connection stati changed
function TopoUpdateNodePortConnStati(TopoXMLSaved, TopoXMLNew)
{
    var NoOfNodes = 0;
    var NodeIdxUpd = 0;
    var NoOfConns = 0;
    var ConnStatus = 0;
    var ConnStatusUpd = 0;
    var MultiPort = false;
    var MuPoDestDev = "";
    var NodeIdxMuPoDestDev = "";
    var NodeAttrib = 0;
    var DivObjPortLabel = "";

    var i,j;
/****************************************************************************************/

    NoOfNodes = TopoXMLSaved.GetNoOfNodes();

    for(i = 0; i < NoOfNodes; i++)
    {
        NodeName = TopoXMLSaved.GetNodeNameAtNodeIdx(i);

        NodeIdxUpd = TopoXMLNew.GetIdxOfNodeByName(NodeName);

        if(null != NodeIdxUpd)
        {
            NoOfConns = TopoXMLSaved.GetNoOfConnAtNodeIdx(i);

            for(j = 0; j < NoOfConns; j++)
            {
                ConnStatus = (TopoXMLSaved.GetConnStatus(i, j) & ConnStatusMask);
                ConnStatusUpd = (TopoXMLNew.GetConnStatus(NodeIdxUpd, j) & ConnStatusMask);

                if(ConnStatus != ConnStatusUpd)
                {
                    // connection status changed ->
                    // save new connection status update port and connection paint
                    TopoXMLSaved.SetConnStatus(i, j, ConnStatusUpd);

                    TopoUpdateNodeConnectionPaint(i, j, ConnStatusUpd);
                }
/*
                // check if connection is a multiport connection
                MultiPort = TopoXMLSaved.GetConnMultiPort(i, j);
                if(true == MultiPort)
                {
                    // get device name of the first device connected to this port
                    MuPoDestDev = TopoXMLSaved.GetConnMuPoDestDev(i, j);
                    // get index of this device from the XML-List
                    NodeIdxMuPoDestDev = TopoXMLNew.GetIdxOfNodeByName(MuPoDestDev);
                    if(null != NodeIdxMuPoDestDev)
                    {
                        // get port label object of current multiport
                        DivObjPortLabel = TopoXMLSaved.GetPortLabelObj(i, j);

                        // get device attibute of first connected device
                        NodeAttrib = TopoXMLSaved.GetNodeAttribAtIdx(NodeIdxMuPoDestDev);
                        if((XMLNodeAttribDevNotAccessible == (XMLNodeAttribDevNotAccessible & NodeAttrib)) &&
                           (XMLNodeAttribDevDeactivated != (XMLNodeAttribDevDeactivated & NodeAttrib)))
                        {
                            // no devices connected to this multiport
                            DivObjPortLabel.style.color = '#D3D3D3';

                        }
                        else
                        {
                            // devices are connected to this multiport
                            DivObjPortLabel.style.color = '#000000';
                        }
                    }
                }
*/
            }// end of for(j = 0; j < NoOfConns; j++)
        }
    }
}

function TopoTableGetNodeStatusImgObj(NodeIdx, StatusType)
{
    var TableDeviceObjTR = "";
    var StatusImgObj = "";

    TableDeviceObjTR = TopoListXMLSave.GetTableDeviceObjTRAtIdx(NodeIdx);

    StatusImgObj = TableDeviceObjTR.childNodes[0].childNodes[StatusType];

    return StatusImgObj;
}

function GetPortStatusGif(PortCnType, ConnStatus, PortPosXInModule)
{
    var PortStatusGif = "";

    switch(PortCnType)
    {
        case cn_type_parent:
        case cn_type_connector_left:
        case cn_type_ring_left:
        {
            PortStatusGif = NodePortTypeAddStatus("left", ConnStatus);
            break;
        }

        case cn_type_child:
        {

            if(0 == PortPosXInModule)
            {
                // conneciton type child on the left side of node -> current node is part of a line
                PortStatusGif = NodePortTypeAddStatus("left", ConnStatus);
            }
            else
            {
                // conneciton type child on the right side of node -> current node is a star node
                PortStatusGif = NodePortTypeAddStatus("right", ConnStatus);
            }
            break;
        }

        case cn_type_not_conn:
        {
            PortStatusGif = mb_port_right_unplug;
            break;
        }

        case cn_type_corrupt:
        case cn_type_connector_right:
        case cn_type_ring_right:
        {
            PortStatusGif = NodePortTypeAddStatus("right", ConnStatus);
            break;
        }

        case cn_type_ring:
        {
            console && console.log && console.log("Connection type error!");
            break;
        }

        default:
        {
            break;
        }
    }

    return PortStatusGif;
}

function TopoUpdateNodeConnectionPaint(NodeIdx, ConnIdx, ConnStatus)
{

    var IdxOfTree = 0;
    var IdxOfNodeInTree = 0;
    var PortCnType = "";
    var DivObjPort = "";
    var PortStatusGif = "";

    var NoOfConnObj = 0;
    var ConnObj = "";
    var ConnStatusColor = "";

    var i;

    // get tree reference (tree index) of node
    IdxOfTree       = NodeInTreeRefNodeXML.GetTreeIdx(NodeIdx);
    // get node reference (node index) within IdxOfTree-tree
    IdxOfNodeInTree = NodeInTreeRefNodeXML.GetTreeNodeIdx(NodeIdx);
    // get connection type of this connection (ConnIdx)
    PortCnType      = TreeArray.GetNodeConnCnType(IdxOfTree, IdxOfNodeInTree, ConnIdx);
    // get x-offset of port within node -> position of port (left, right)
    PortPosXInModule = TreeArray.GetNodeConnPortPosX(IdxOfTree, IdxOfNodeInTree, ConnIdx);
    // get port gif corresponding to connection status and port side within node
    PortStatusGif = GetPortStatusGif(PortCnType, ConnStatus, PortPosXInModule);

   // update port paint
    DivObjPort = TopoListXMLSave.GetConnPortObj(NodeIdx, ConnIdx);
    DivObjPort.getElementsByTagName("img")[0].src = ModuleAtoGifs[PortStatusGif];

    // update connection line paint
    NoOfConnObj = TopoListXMLSave.GetNoOfConnPaintObjts(NodeIdx, ConnIdx);
    // for every part of painted connection line
    for(i = 0; i < NoOfConnObj; i++)
    {
        // get a part of the connection line
        ConnObj = TopoListXMLSave.GetConnPaintObjAtConnIdx(NodeIdx, ConnIdx, i);
        // get the connection gif(color) depending on connection status
        ConnStatusColor = GetConnStatusColor(ConnStatus);
        // change the connection color within the connection line div-object
        ConnObj.style.backgroundColor = ConnStatusColor;
    }
}

// TopoCompareGraphTopology compares if number of all nodes, number of all connections,
// NoS (names of stations), number of connections within the same saved and new node,
// connection descriptions within the same saved and new connections of a node changed
function TopoCompareGraphTopology(TopoListXML1, TopoListXML2)
{
    var NoOfNodes1 = 0;
    var NoOfNodes2 = 0;
    var NoOfAllConns1 = 0;
    var NoOfAllConns2 = 0;
    var NoOfConns1 = 0;
    var NoOfConns2 = 0;
    var SrcPort1 = "";
    var SrcPort2 = "";
    var DestNode1 = "";
    var DestNode2 = "";
    var DestPort1 = "";
    var DestPort2 = "";
    var NoS = "";
    var NodeIdx = 0;
    var i = 0, j = 0;
    var TopoEqual = true;

    NoOfNodes1 = TopoListXML1.GetNoOfNodes();
    NoOfNodes2 = TopoListXML2.GetNoOfNodes();

    NoOfAllConns1 = TopoListXML1.GetNoOfAllConn();
    NoOfAllConns2 = TopoListXML2.GetNoOfAllConn();

    if((NoOfNodes1 == NoOfNodes2) && (NoOfAllConns1 == NoOfAllConns2))
    {
        for(i = 0;((i < NoOfNodes1) && (true == TopoEqual)); i++)
        {
            NoS      = TopoListXML1.GetNodeNameAtNodeIdx(i);
            NodeIdx  = TopoListXML2.GetIdxOfNodeByName(NoS);

            if(null != NodeIdx)
            {
                // found corresponding node in current XML-List
                NoOfConns1 = TopoListXML1.GetNoOfConnAtNodeIdx(i);
                NoOfConns2 = TopoListXML2.GetNoOfConnAtNodeIdx(NodeIdx);

                if(NoOfConns1 == NoOfConns2)
                {
                    // nodes have equal number of connections
                    for(j = 0;((j < NoOfConns1)  && (true == TopoEqual)); j++)
                    {
                        //
                        SrcPort1  = TopoListXML1.GetConnDescrSrcPort(i,j);
                        DestNode1 = TopoListXML1.GetConnDescrDestNode(i, j);
                        DestPort1 = TopoListXML1.GetConnDescrDestPort(i, j);

                        SrcPort2  = TopoListXML2.GetConnDescrSrcPort(NodeIdx,j);
                        DestNode2 = TopoListXML2.GetConnDescrDestNode(NodeIdx, j);
                        DestPort2 = TopoListXML2.GetConnDescrDestPort(NodeIdx, j);

                        if((SrcPort1  != SrcPort2)  ||
                           (DestNode1 != DestNode2) ||
                           (DestPort1 != DestPort2))
                        {
                            TopoEqual = false;
                            // corresponding node has different connection description -> topo changed
                            // print new topo graph
//                            alert("Error: Different connection descriptions! @ node:" + NodeIdx); // for debugging
                        }
                    }
                }
                else
                {
                    TopoEqual = false;
                    // corresponding node has different number of connections -> topo changed
                    // print new topo graph
//                    alert("Error: Nodes have different number of connections!"); // for debugging
                }
            }
            else
            {
                TopoEqual = false;
                //  corresponding node in current XML-list not found -> topo changed
                // print new topo graph
//                alert("Error: No corresponding node found in XML-list!"); // for debugging
            }
        }// end of for(i = 0; i < NoOfNodes1; i++)
    }
    else
    {
        TopoEqual = false;
        // different number of nodes and connections within saved and current XML-list -> topo changed
        // print new topo graph
//        alert("Error: Different number of nodes or connections!"); // for debugging
    }

    return TopoEqual;
}


// TopoCompareOverviewTopology compares if number of nodes of project has changed and
// if all saved nodes have a corresponding new node
function TopoCompareOverviewTopology(TopoListXML1, TopoListXML2)
{
    var i = 0;
    var NodeIdx = 0;
    var NoOfNodes = 0;
    var NodeName = "";
    var NodeAttrib = "";
    var TopoEqual = true;

    // check if all saved nodes have a corresponding node with update data and
    // if these corresponding nodes are devices of project

    NoOfNodes = TopoListXML1.GetNoOfNodes();

    for(i = 0;((i < NoOfNodes) && (true == TopoEqual)); i++)
    {
        NodeName   = TopoListXML1.GetNodeNameAtNodeIdx(i);
        NodeIdx    = TopoListXML2.GetIdxOfNodeByName(NodeName);

        if(null == NodeIdx)
        {
            TopoEqual = false;
            //  corresponding node in current XML-list not found -> topo changed
        }
        else
        {
            NodeAttrib = TopoListXML2.GetNodeAttribAtIdx(NodeIdx);

            if(XMLNodeAttribDevOfProject != (NodeAttrib & XMLNodeAttribDevOfProject))
            {
                TopoEqual = false;
                //  corresponding node in current XML-list is not of project
            }
        }
    }

    // check if all new devices(nodes) of project have a corresponding node in the saved list of nodes

    NoOfNodes = TopoListXML2.GetNoOfNodes();

    for(i = 0;((i < NoOfNodes) && (true == TopoEqual)); i++)
    {

        NodeAttrib   = TopoListXML2.GetNodeAttribAtIdx(i);

        if(XMLNodeAttribDevOfProject == (NodeAttrib & XMLNodeAttribDevOfProject))
        {
            NodeName = TopoListXML2.GetNodeNameAtNodeIdx(i);
            NodeIdx  = TopoListXML1.GetIdxOfNodeByName(NodeName);

            if(null == NodeIdx)
            {
                TopoEqual = false;
                //  corresponding node in current XML-list not found -> topo changed
            }
        }
    }

    return TopoEqual;
}

// NodeBodyInit initialises the definition of node design (port order and position) concerning node types
function NodeBodyInit()
{
    NodeBody[node_type_line]      = new Array();
    NodeBody[node_type_line_last] = new Array();
    NodeBody[node_type_star]      = new Array();
    NodeBody[node_type_last]      = new Array();

    NodeBody[node_type_line][node_body_left_side] = new Array();
    NodeBody[node_type_line][node_body_right_side] = new Array();

    NodeBody[node_type_line_last][node_body_left_side] = new Array();
    NodeBody[node_type_line_last][node_body_right_side] = new Array();

    NodeBody[node_type_star][node_body_left_side] = new Array();
    NodeBody[node_type_star][node_body_right_side] = new Array();

    NodeBody[node_type_last][node_body_left_side] = new Array();
    NodeBody[node_type_last][node_body_right_side] = new Array();

    // node within a line
    NodeBody[node_type_line][node_body_left_side][0] = cn_type_parent;
    NodeBody[node_type_line][node_body_left_side][1] = cn_type_ring_left;
    NodeBody[node_type_line][node_body_left_side][2] = cn_type_connector_left;
    NodeBody[node_type_line][node_body_left_side][3] = cn_type_child;

    NodeBody[node_type_line][node_body_right_side][0] = cn_type_connector_right;
    NodeBody[node_type_line][node_body_right_side][1] = cn_type_not_conn;
    NodeBody[node_type_line][node_body_right_side][2] = cn_type_corrupt;

    // last node of a line
    NodeBody[node_type_line_last][node_body_left_side][0] = cn_type_parent;
    NodeBody[node_type_line_last][node_body_left_side][1] = cn_type_ring_left;
    NodeBody[node_type_line_last][node_body_left_side][2] = cn_type_connector_left;

    NodeBody[node_type_line_last][node_body_right_side][0] = cn_type_connector_right;
    NodeBody[node_type_line_last][node_body_right_side][1] = cn_type_not_conn;
    NodeBody[node_type_line_last][node_body_right_side][2] = cn_type_corrupt;

    // star node
    NodeBody[node_type_star][node_body_left_side][0] = cn_type_parent;
    NodeBody[node_type_star][node_body_left_side][1] = cn_type_ring_left;
    NodeBody[node_type_star][node_body_left_side][2] = cn_type_connector_left;

    NodeBody[node_type_star][node_body_right_side][0] = cn_type_child;
    NodeBody[node_type_star][node_body_right_side][1] = cn_type_ring_right;
    NodeBody[node_type_star][node_body_right_side][2] = cn_type_connector_right;
    NodeBody[node_type_star][node_body_right_side][3] = cn_type_not_conn;
    NodeBody[node_type_star][node_body_right_side][4] = cn_type_corrupt;

    // last node (parent is a star node)
    NodeBody[node_type_last][node_body_left_side][0] = cn_type_parent;
    NodeBody[node_type_last][node_body_left_side][1] = cn_type_ring_left;
    NodeBody[node_type_last][node_body_left_side][2] = cn_type_connector_left;

    NodeBody[node_type_last][node_body_right_side][0] = cn_type_not_conn;
    NodeBody[node_type_last][node_body_right_side][1] = cn_type_corrupt;
}


function ToolTipTypePosInit()
{
    ToolTipTypePos.Init(ToolTipAttribNodeHead,  0, 65, 15, 45);
    ToolTipTypePos.Init(ToolTipAttribNodeLabel, 0, 20, 15, 45);
    ToolTipTypePos.Init(ToolTipAttribPortLabel, 0, 14, 15, 40);
}


/* Gif images used within topology graphical view and overview */
function TopoInitAtoGifs()
{

    ModuleAtoGifs[mb_port_left_plug_ok]       = TopoAtoGifLinkPraefix + 'topo_module_port_left_plug_ok.gif';
    ModuleAtoGifs[mb_port_left_unplug]        = TopoAtoGifLinkPraefix + 'topo_module_port_left_unplug.gif';
    ModuleAtoGifs[mb_port_right_plug_ok]      = TopoAtoGifLinkPraefix + 'topo_module_port_right_plug_ok.gif';
    ModuleAtoGifs[mb_port_right_unplug]       = TopoAtoGifLinkPraefix + 'topo_module_port_right_unplug.gif';
    ModuleAtoGifs[mb_head]                    = TopoAtoGifLinkPraefix + 'topo_module_head.gif';
    ModuleAtoGifs[mb_head_not_available]      = TopoAtoGifLinkPraefix + 'topo_module_head_dev_not_available.gif';
    ModuleAtoGifs[mb_head_not_of_project]     = TopoAtoGifLinkPraefix + 'topo_module_head_dev_not_of_project.gif';
    ModuleAtoGifs[connector]                  = TopoAtoGifLinkPraefix + 'topo_connector.gif';
    ModuleAtoGifs[port_label]                 = TopoAtoGifLinkPraefix + 'topo_port_label_background.gif';
    ModuleAtoGifs[head_label]                 = TopoAtoGifLinkPraefix + 'topo_head_label_background.gif';
    ModuleAtoGifs[port_tooltip_background]    = TopoAtoGifLinkPraefix + 'topo_port_tooltip_background.gif';
    ModuleAtoGifs[mb_head_overview]           = TopoAtoGifLinkPraefix + 'topo_module_head_overview.gif';
    ModuleAtoGifs[head_label_overview]        = TopoAtoGifLinkPraefix + 'topo_head_label_background_overview.gif';
    ModuleAtoGifs[mb_port_left_plug_error]    = TopoAtoGifLinkPraefix + 'topo_module_port_left_plug_error.gif';
    ModuleAtoGifs[mb_port_right_plug_error]   = TopoAtoGifLinkPraefix + 'topo_module_port_right_plug_error.gif';
    ModuleAtoGifs[mb_port_left_plug_no_diag]  = TopoAtoGifLinkPraefix + 'topo_module_port_left_plug_no_diag.gif';
    ModuleAtoGifs[mb_port_right_plug_no_diag] = TopoAtoGifLinkPraefix + 'topo_module_port_right_plug_no_diag.gif';
}

function TopoInitDiagAtoGifs()
{
    DiagAtoGifs[DiagAtoGif_Null]         = TopoBgzLinkPraefix + 'Good.gif';
    DiagAtoGifs[DiagAtoGif_Unaccessible] = TopoBgzLinkPraefix + 'Unknown.gif';
    DiagAtoGifs[DiagAtoGif_Alarm]        = TopoBgzLinkPraefix + 'Fault.gif';
    DiagAtoGifs[DiagAtoGif_Maintenance2] = TopoBgzLinkPraefix + 'Demand.gif';
    DiagAtoGifs[DiagAtoGif_Maintenance1] = TopoBgzLinkPraefix + 'Required.gif';
    DiagAtoGifs[DiagAtoGif_Ok]           = TopoBgzLinkPraefix + 'Good.gif';
    DiagAtoGifs[DiagAtoGif_Deactivated]  = TopoBgzLinkPraefix + 'Disabled.gif';
    DiagAtoGifs[DiagAtoGif_SubFail]      = TopoBgzLinkPraefix + 'ConflictsBelow.gif';
    DiagAtoGifs[DiagAtoGif_NotAvailable] = TopoBgzLinkPraefix + 'NotAccessible.gif';
}

function TopoInitNodeStateAtoGifs()
{
    NodeStateAtoGifs[XMLNodeAttribDevOfProject]     = TopoAtoGifLinkPraefix + 'topo_state_accessible.gif';
    NodeStateAtoGifs[XMLNodeAttribDevNext2Project]  = TopoAtoGifLinkPraefix + 'topo_state_not_projected.gif';
    NodeStateAtoGifs[XMLNodeAttribDevNotAccessible] = TopoAtoGifLinkPraefix + 'topo_state_not_accessible.gif';
    NodeStateAtoGifs[XMLNodeAttribPNIORecReadError] = TopoAtoGifLinkPraefix + 'topo_state_no_neighbours.gif';
    NodeStateAtoGifs[XMLNodeAttribPNIORecNotPlaus]  = TopoAtoGifLinkPraefix + 'topo_state_no_neighbours.gif';
    NodeStateAtoGifs[XMLNodeAttribDevDeactivated]   = TopoAtoGifLinkPraefix + 'topo_state_accessible.gif';
}

function TopoInitGlobalParamaters()
{
    var DivObjTemp      = "";
    var TextObjTemp     = "";

    DivObjTemp = top.document.createElement("div");
    DivObjTemp.setAttribute("class", "DivObjTemp");
    DivObjTemp.style.lineHeight = (14 - 1) + "px";
    DivObjTemp.style.fontSize = 12;

    TextObjTemp = top.document.createTextNode("...");
    OutputDOMObj(DivObjTemp);
    DivObjTemp.appendChild(TextObjTemp);
    GlobTextObjSizeX = DivObjTemp.offsetWidth;

    RemoveDOMObj(DivObjTemp);
}

/*****************************************************************************/

// XMLNodePlausibCheck checks the xml-node-list if there is a NoS doublet
// - if there are, the xml-node-list is invalid and there is no further processing
function XMLNodePlausibCheck()
{
    var NoOfNodes = 0;

    var NodeNameSrc = "";
    var NodeNameChecking = "";

    var DeviceType1st = "";
    var DeviceType2nd = "";

    var DeviceConns1st = "";
    var DeviceConns2nd = "";

    var i,j;

    NoOfNodes = TopoListXML.GetNoOfNodes();
    // for every node (NoS)
    for(i=0; i < NoOfNodes; i++)
    {
        NodeNameSrc = TopoListXML.GetNodeNameAtNodeIdx(i);
        // for every node (NoS) left in the TopoListXML
        for(j = (i+1); j < NoOfNodes; j++)
        {
            NodeNameChecking = TopoListXML.GetNodeNameAtNodeIdx(j);
            // check if node names (NoS) are equal
            if(NodeNameSrc == NodeNameChecking)
            {
                DeviceType1st = TopoListXML.GetNodeDeviceTypeAtIdx(i);
                DeviceType2nd = TopoListXML.GetNodeDeviceTypeAtIdx(j);

                DeviceConns1st = TopoListXML.GetNoOfConnAtNodeIdx(i);
                DeviceConns2nd = TopoListXML.GetNoOfConnAtNodeIdx(j);

                console && console.log && console.log("Error: Devices got same NoS: " + "\n\n" +
                      "Device NoS: " + NodeNameSrc + "\n\n" +
                      "Dev1 index: " + i + "\n" +
                      "Dev1 type:  " + DeviceType1st + "\n" +
                      "Dev1 conns: " + DeviceConns1st + "\n\n" +
                      "Dev2 index: " + j + "\n" +
                      "Dev2 type:  " + DeviceType2nd + "\n" +
                      "Dev2 conns: " + DeviceConns2nd );
            }
        }
    }
}

// XMLNodeConnPlausibCheck checks the xml-node-list if every port of a node has a different label
// - if port labels are equal and actual topology is set, the connections of these ports are marked as invalid
function XMLNodeConnMultiPortCheck()
{
    var NoOfNodes = 0;
    var NoOfConns = 0;

    var PortNameSave = "";
    var PortName = "";

    var ConnValidity = false;

    var i,j,k;

    NoOfNodes = TopoListXML.GetNoOfNodes();
    // for every node
    for(i=0; i<NoOfNodes; i++)
    {
        NoOfConns = TopoListXML.GetNoOfConnAtNodeIdx(i);
        // for every connection (port name) within node
        for(j = 0; j < NoOfConns; j++)
        {
            ConnValidity = TopoListXML.GetConnValidity(i, j);
            // check if processed connection (port name) is valid
            if(true == ConnValidity)
            {
                PortNameSave = TopoListXML.GetConnDescrSrcPort(i, j);
                // for every further connection (port name) after connection (j)
                for(k = (j + 1); k < NoOfConns; k++)
                {
                    ConnValidity = TopoListXML.GetConnValidity(i, k);

                    if(true == ConnValidity)
                    {
                        PortName = TopoListXML.GetConnDescrSrcPort(i, k);

                        if(PortNameSave == PortName)
                        {
                            TopoListXML.SetConnMultiPort(i, j, true);
                            TopoListXML.SetConnMultiPort(i, k, true);
                        }
                    }
                }
            }
        }
    }
}

// XMLNodeConnPlausibCheckPartner checks corresponding connections between two nodes
// and markes them invalid if they are not bidirectional (connection status has to be also equal);
// further if one of the bidirectional corresponding connections is invalid by the former plausib
// both are marked as invalid;
function XMLNodeConnPlausibCheckPartner()
{
    var NoOfNodes = 0;
    var NoOfNodeConnsSrc  = 0;

    var NodeNameSrc = "";
    var PortNameSrc = "";

    var NodeNameDest = "";
    var PortNameDest = "";

    var PortNameAtDestConn = "";

    var XMLNodeIdxDest = 0;
    var XMLPortIdxDest = 0;

    var ConnValidity = false;


    var i,j;

    NoOfNodes = TopoListXML.GetNoOfNodes();
    // for every node
    for(i=0; i<NoOfNodes; i++)
    {
        NoOfNodeConnsSrc = TopoListXML.GetNoOfConnAtNodeIdx(i);
        // for every connection within node
        for(j = 0; j < NoOfNodeConnsSrc; j++)
        {
            ConnValidity = TopoListXML.GetConnValidity(i, j);
            // check if processed connection is still valid
            if(true == ConnValidity)
            {
                NodeNameSrc       = TopoListXML.GetNodeNameAtNodeIdx(i);
                PortNameSrc       = TopoListXML.GetConnDescrSrcPort(i, j);

                NodeNameDest      = TopoListXML.GetConnDescrDestNode(i, j);
                PortNameDest      = TopoListXML.GetConnDescrDestPort(i, j);
                // if node port is connected
                if(BlankString != NodeNameDest)
                {
                    // get index if connection partner within xml-node-list
                    XMLNodeIdxDest = TopoListXML.GetIdxOfNodeByName(NodeNameDest);
                    // if connection partner not found
                    if(null == XMLNodeIdxDest)
                    {
                        TopoListXML.SetConnValidity(i, j, false);
                    }
                    else
                    {
                        // connection partner found
                        // get index of connection description of found connection partner
                        // comparing destination port of origin with source port at destination
                        XMLPortIdxDest = TopoListXML.GetIdxOfDestConnBySrcAndPortName(NodeNameSrc, XMLNodeIdxDest, PortNameDest);
                        // destination node has no such source port
                        if(null == XMLPortIdxDest)
                        {
                            // set connection at origin as invalid
                            TopoListXML.SetConnValidity(i, j, false);
                        }
                        else
                        {
                            // get port label of destination node at destination node (= port label of origin port)
                            PortNameAtDestConn = TopoListXML.GetConnDescrDestPort(XMLNodeIdxDest, XMLPortIdxDest);
                            // if connection description of corresponding connections are not bidirectional
                            if(PortNameSrc != PortNameAtDestConn)
                            {
                                // set corresponding connections as invalid
                                TopoListXML.SetConnValidity(i, j, false);
                            }
                        }
                    }
                }
            }
        }
    }
}


/*********************************************************************************************************/

// TopoPrintSize processes the size(px) of the background image, that contains all node trees
function TopoPrintSize()
{

    var TreeTableSizeTemp = new MatrixSizeNew();
    var TableMatrixSize   = new MatrixSizeNew();
    var NodesAttrib = "";
    var TopoBGColor = "";
    var i;

    // for all node trees
    for(i = 0; i < TreeArray.GetNoOfTrees(); i++)
    {
        // add new tree size structure
        TreeMatrixSize.AddNewSizeElem(i);
        // process the size of one node tree starting with first node
        CalcTreeTableMatrixSize(i, 0);
        // get processed size of node tree (i)
        TreeTableSizeTemp = TreeMatrixSize.GetMatrixSize(i);
        // if new processed backgraound width is bigger than the saved one, save the new one as max. background width
        if(TableMatrixSize.SizeX < TreeTableSizeTemp.SizeX) TableMatrixSize.SizeX = TreeTableSizeTemp.SizeX;
        // increase the height of background image
        TableMatrixSize.SizeY += (TreeTableSizeTemp.SizeY + MatrixModuleSpacingY);
    }

    NodesAttrib = TopoListXMLSave.GetNodesAttrib();

    if(XMLNodesAttribActTopoBGColor == (NodesAttrib & XMLNodesAttribActTopoBGColor) && (false == PrintOutput))
    {
        TopoBGColor = "#EAEAEA";
    }
    else
    {
        TopoBGColor = "#EAEAEA";
    }
    // paint background image
    TopoPrintBackground(((TableMatrixSize.SizeX + 1) * PxMatrixCellSize) + NodeConnectorWidth + NodeConnectorLabelWidth,
                        ((TableMatrixSize.SizeY + 1) * PxMatrixCellSize),
                        TopoBGColor);
}


function TopoPrintBackground(SizeX, SizeY, BGColor)
{

    var TopoBackgroundDiv = "";
    var TopoWorkspaceTD = "";
    TopoBackgroundDiv = top.document.createElement("div");

    TopoBackgroundDiv.id = "TopoBackgroundDiv";
    TopoBackgroundDiv.style.position = 'relative';
    TopoBackgroundDiv.style.top  = '0px';
    TopoBackgroundDiv.style.left = '0px';

    // auto and other non number values don't work with px
    if (typeof SizeX == 'number' && typeof SizeY == 'number')
    {
        TopoBackgroundDiv.style.width  = (SizeX) + "px";
        TopoBackgroundDiv.style.height = (SizeY) + "px";
    }
    else
    {
        TopoBackgroundDiv.style.width  = SizeX;
        TopoBackgroundDiv.style.height = SizeY;
    }

    TopoBackgroundDiv.style.backgroundColor = "transparent";
    TopoBackgroundDiv.style.zIndex = '5';

    TopoWorkspaceTD = top.document.getElementById("TopoWorkspaceTD");
    TopoWorkspaceTD.style.backgroundColor = BGColor;

    top.document.getElementById("pic").appendChild(TopoBackgroundDiv);

    OutputObj = top.document.getElementById("TopoBackgroundDiv");
}

/********************************************************************************************************/

// TopoGenGlobalData imports global data from the Iframe into a Topo-JavaScript internal data structures
function TopoGenGlobalData(TopoGlobalDataObj, IframeObjXML)
{
    var RecordCnt;
    var RecordVar = "", RecordVal = "";
    var i;

    RecordCnt = TopoGetGlobalDataRecordCnt(IframeObjXML);

    for (i = 0; i < RecordCnt; i++)
    {
        RecordVar = TopoGetGlobDataRecordVar(i,IframeObjXML);
        RecordVal = TopoGetGlobDataRecordVal(i,IframeObjXML);

        TopoGlobalData.AddNewRecord(RecordVar, RecordVal);
    }
}

function TopoNameConvert(Nodename)
{
  Nodename = Nodename.replace(/&quot;/g, "\"");
  Nodename = Nodename.replace(/&lt;/g, "<");
  Nodename = Nodename.replace(/&gt;/g, ">");

  Nodename = Nodename.replace(/&amp;/g, "&");
  Nodename = Nodename.replace(/&lt;/g, "<");
  Nodename = Nodename.replace(/&lt;/g, "<");
  Nodename = Nodename.replace(/&nbsp;/g, " ");

  //alert(jetzt + "\n" + vormals);
  return Nodename;

}

// TopoGenModuleList imports topology data from the Iframe into a Topo-JavaScript
// internal data structures and deletes the Iframe afterwards
function TopoGenModuleList(TopoListXMLObj, IframeObjXML)
{
    var NodeCnt = TopoGetNodeCnt(IframeObjXML);
    var ConnCnt;
    var i,j;
    var NodeName = "", SrcPort = "", DestNode = "", DestPort = "", ConnStatus = 0;
    var NodeAttrib = 0;
    var NodeDeviceType = "", NodeDiagInfo = "", NodeDiagInfoSub = "",NodeURL_BGZ = "";
    var NodeNameHighlight = "";
    var NodesAttrib = "";
    var NodesDate = "";
    var NodesTime = "";


    NodeNameHighlight = TopoGetNodeHighlight(IframeObjXML);

    NodesAttrib = TopoGetNodesAttribute(IframeObjXML);

    NodesDate = TopoGetNodesDate(IframeObjXML);

    NodesTime = TopoGetNodesTime(IframeObjXML);

    TopoListXMLObj.SetNodesAttrib(NodesAttrib);

    TopoListXMLObj.SetNodesDate(NodesDate);

    TopoListXMLObj.SetNodesTime(NodesTime);

    for (i = 0; i < NodeCnt; i++)
    {
        TopoListXMLObj.AddNewNode();

        NodeName = TopoGetNode(i, IframeObjXML);
        NodeName = TopoNameConvert(NodeName);
        TopoListXMLObj.SetNodeNameAtIdx(i, NodeName);

        if(NodeNameHighlight == NodeName)
        {
            TopoListXMLObj.SetNodeHighlightAtIdx(i);
        }

        NodeAttrib = TopoGetAttrib(i, IframeObjXML);
        TopoListXMLObj.SetNodeAttribAtIdx(i, NodeAttrib);

        NodeDeviceType = TopoGetDeviceType(i, IframeObjXML);
        TopoListXMLObj.SetNodeDeviceTypeAtIdx(i, NodeDeviceType);

        NodeDiagInfo = TopoGetDiagInfo(i, IframeObjXML);
        TopoListXMLObj.SetNodeDiagInfoAtIdx(i, NodeDiagInfo);

        NodeDiagInfoSub = TopoGetDiagInfoSub(i, IframeObjXML);
        TopoListXMLObj.SetNodeDiagInfoSubAtIdx(i, NodeDiagInfoSub);

        NodeURL_BGZ = TopoGetURL_BGZ(i, IframeObjXML);
        TopoListXMLObj.SetNodeURL_BGZAtIdx(i, NodeURL_BGZ);

        ConnCnt = TopoGetNodeConnectionCnt(i, IframeObjXML);

        for (j = 0; j < ConnCnt; j++)
        {

            SrcPort    = TopoGetSrcPort(i,j,IframeObjXML);
            DestNode   = TopoGetDestNode(i,j,IframeObjXML);
            DestNode   = TopoNameConvert(DestNode);
            DestPort   = TopoGetDestPort(i,j,IframeObjXML);
            ConnStatus = TopoGetConnStatus(i,j,IframeObjXML);
            TopoListXMLObj.AddNewConn2Node(NodeName, SrcPort, DestNode, DestPort, ConnStatus);
        }
    }

    // DOM-Iframe with xml data will be deleted
    top.document.getElementById("XMLData").removeChild(IframeObjXML);
}


// TopoGenModuleListSave copies xml data from the TopoListXML data structure
// into TopoListXMLSave data structure for comparison of topo data during auto update
// AttribFilter defines the attribute of nodes that are saved for comparison e.g.
// graphical view = all nodes are saved; overview = only nodes of project are saved
function TopoGenModuleListSave(AttribFilter)
{
    var NodeCnt = TopoListXML.GetNoOfNodes();
    var ConnCnt;
    var NodeName = "", SrcPort = "", DestNode = "", DestPort = "", ConnStatus = 0, Multiport = "";
    var NodeAttrib = 0;
    var NodeDeviceType = "", NodeDiagInfo = "", NodeDiagInfoSub = "",NodeURL_BGZ = "";
    var i = 0, j = 0, k = 0;

    TopoListXMLSave = new NodeListXML_New();

    TopoListXMLSave.SetNodesAttrib(TopoListXML.GetNodesAttrib());

    for (i = 0; i < NodeCnt; i++)
    {
        NodeAttrib = TopoListXML.GetNodeAttribAtIdx(i);

        if((0 != (NodeAttrib & AttribFilter)) ||
           (0xFFFF == AttribFilter))
        {
            TopoListXMLSave.AddNewNode();

            NodeName = TopoListXML.GetNodeNameAtNodeIdx(i);
            TopoListXMLSave.SetNodeNameAtIdx(j, NodeName);

            if(TopoListXML.GetNodeHighlightAtIdx(i))
            {
                TopoListXMLSave.SetNodeHighlightAtIdx(j);
            }

            NodeAttrib = TopoListXML.GetNodeAttribAtIdx(i);
            TopoListXMLSave.SetNodeAttribAtIdx(j, NodeAttrib);

            NodeDeviceType = TopoListXML.GetNodeDeviceTypeAtIdx(i);
            TopoListXMLSave.SetNodeDeviceTypeAtIdx(j, NodeDeviceType);

            NodeDiagInfo = TopoListXML.GetNodeDiagInfoAtIdx(i);
            TopoListXMLSave.SetNodeDiagInfoAtIdx(j, NodeDiagInfo);

            NodeDiagInfoSub = TopoListXML.GetNodeDiagInfoSubAtIdx(i);
            TopoListXMLSave.SetNodeDiagInfoSubAtIdx(j, NodeDiagInfoSub);

            NodeURL_BGZ = TopoListXML.GetNodeURL_BGZAtIdx(i);
            TopoListXMLSave.SetNodeURL_BGZAtIdx(j, NodeURL_BGZ);

            ConnCnt = TopoListXML.GetNoOfConnAtNodeIdx(i);

            for (k = 0; k < ConnCnt; k++)
            {
                SrcPort       = TopoListXML.GetConnDescrSrcPort(i, k);
                DestNode      = TopoListXML.GetConnDescrDestNode(i, k);
                DestPort      = TopoListXML.GetConnDescrDestPort(i, k);
                ConnStatus    = TopoListXML.GetConnStatus(i, k);

                TopoListXMLSave.AddNewConn2Node(NodeName, SrcPort, DestNode, DestPort, ConnStatus);

                Multiport     = TopoListXML.GetConnMultiPort(i, k);
                TopoListXMLSave.SetConnMultiPort(i, k, Multiport);

                Validity      = TopoListXML.GetConnValidity(i, k);
                TopoListXMLSave.SetConnValidity(i, k, Validity);
            }

            j++;
        }
    }
}

// TreeGenerate processes one or more tree structures of nodes based on xml-node-list data
function TreeGenerate(ListXML, TreeIdx, TreeNodeIdxSrc)
{
    var i;
    var ChildNo = 0;
    var RingNo = 0;
    var XMLPortIdxCorrespRingConn = 0;

    var NodeNameSrc = "";
    var PortNameSrc = "";

    var NodeNameDest = "";
    var PortNameDest = "";

    var ConnDescrParentCheck = "";
    var ConnDescrCurrentCheck = "";

    var XMLNodeIdxDest = false;
    var TreeNodeIdxParent = 0;
    var XMLNodeIdxParent = 0;
    var XMLNodeConnIdx = 0;
    var RingConnNodeIdx = 0;
    var NodeIdxChild = 0;
    var ChildIdx = 0;
    var ConnValidity = false;
    var ConnStatus   = 0;
    var Multiport = false;

    var XMLNodeIdxSrc = TreeArray.GetIdxOfNodeInXMLList(TreeIdx, TreeNodeIdxSrc);
    var XMLNodeConnNoSrc = ListXML.GetNoOfConnAtNodeIdx(XMLNodeIdxSrc);

    //check if node will be highlighted
    if(ListXML.GetNodeHighlightAtIdx(XMLNodeIdxSrc))
    {
        // save tree index and node index within this tree of the highlighted node
        TreeArray.SetNodeHighlight(TreeIdx, TreeNodeIdxSrc);
    }

    // create XMLNodeConnNoSrc connection structs within node
    TreeArray.InitNodeConnStruct(TreeIdx, TreeNodeIdxSrc, XMLNodeConnNoSrc);

    for(i = 0; i < XMLNodeConnNoSrc; i++)
    {
        // copy port name from xml-node-list into tree struct
        PortNameSrc  = ListXML.GetConnDescrSrcPort(XMLNodeIdxSrc, i);
        TreeArray.SetNodeConnPortName(TreeIdx, TreeNodeIdxSrc, i, PortNameSrc);
        // copy connection status (e.g. ok, error, no diag) from xml-node-list into tree struct
        ConnStatus   = ListXML.GetConnStatus(XMLNodeIdxSrc, i);
        TreeArray.SetNodeConnStatus(TreeIdx, TreeNodeIdxSrc, i, ConnStatus);

        ConnValidity = ListXML.GetConnValidity(XMLNodeIdxSrc, i);
        // if connection is not valid, set connection type to corrupt
        if(false == ConnValidity)
        {
            TreeArray.SetNodeConnCnType(TreeIdx, TreeNodeIdxSrc, i, cn_type_corrupt);
        }
        else
        {
            // save index (i) of connection of xml-node-list that is currently processed
            TreeArray.SetIdxOfConnInXMLList(TreeIdx, TreeNodeIdxSrc, i);

            // get names of node and port of the origin connection
            NodeNameSrc       = ListXML.GetNodeNameAtNodeIdx(XMLNodeIdxSrc);
            PortNameSrc       = ListXML.GetConnDescrSrcPort(XMLNodeIdxSrc, i);

            // get names of node and port of the destination connection
            NodeNameDest      = ListXML.GetConnDescrDestNode(XMLNodeIdxSrc, i);
            PortNameDest      = ListXML.GetConnDescrDestPort(XMLNodeIdxSrc, i);

            // if there is no description of a destination node, this connection is not used (connected)
            if(BlankString == NodeNameDest)
            {
                // set connection type to not connected
                TreeArray.SetNodeConnCnType(TreeIdx, TreeNodeIdxSrc, i, cn_type_not_conn);
            }
            else
            {
                // if NodeNameSrc equals NodeNameDest => plausibility check failure
                if(NodeNameSrc != NodeNameDest)
                {
                    // get index of destination node within xml-node-list
                    XMLNodeIdxDest    = ListXML.GetIdxOfNodeByName(NodeNameDest);
                    // if found (destination) node is allready processed => currently processed connection type is a parent or a ring connection
                    // if found (destination) node is not processed yet  => currently processed connection type is a connection to a new node within
                    // the tree and has to be a child connection
                    if(NodeListXMLProcessedInTree[XMLNodeIdxDest] == true)
                    {
                        // this node (XMLNodeIdxDest) is allready processed => currently processed connection type is a parent or a ring connection
                        TreeNodeIdxParent = TreeArray.GetParentIdxOfNode(TreeIdx, TreeNodeIdxSrc);
                        XMLNodeIdxParent  = TreeArray.GetIdxOfNodeInXMLList(TreeIdx, TreeNodeIdxParent);
                        XMLNodeConnIdx    = TreeArray.GetIdxOfConnInXMLList(TreeIdx, TreeNodeIdxParent);
                        // get the origin connection description of parent node pointing at current node and
                        // get current processed connection description pointing at destination node
                        ConnDescrParentCheck  = ListXML.GetConnDescrSrc(XMLNodeIdxParent, XMLNodeConnIdx);
                        ConnDescrCurrentCheck = NodeNameDest + PortNameDest;
                        // if the connection descriptions of parent node and destination node do not match
                        // => currently processed connection type is a ringconnection
                        // if they match
                        // => currently processed connection type is a parent connection
                        if(ConnDescrParentCheck != ConnDescrCurrentCheck)
                        {
                            // this connection is a ring connection
                            // check if tree generation occurs within the same tree; this is a debug information
                            if(TreeIdx != NodeInTreeRefNodeXML.GetTreeIdx(XMLNodeIdxDest))
                            {
                                console && console.log && console.log("Wrong XML-Tree reference! \n\n" +
                                    "Src device: " + NodeNameSrc + "\n" +
                                    "Src device tree index: " + TreeIdx + "\n\n" +
                                    "Dst device: " + NodeNameDest + "\n" +
                                    "Dst device tree index: " + NodeInTreeRefNodeXML.GetTreeIdx(XMLNodeIdxDest));
                            }
                            // get index of destination node within current node tree
                            RingConnNodeIdx = NodeInTreeRefNodeXML.GetTreeNodeIdx(XMLNodeIdxDest);
                            // save index of destination node as a new ring connection
                            TreeArray.SetIdxOfRingConnNodeInNode(TreeIdx, TreeNodeIdxSrc, RingConnNodeIdx);
                            // set the type of currently processed connection to a ring connection
                            TreeArray.SetNodeConnCnType(TreeIdx, TreeNodeIdxSrc, i, cn_type_ring);
                            // assign the number of ring connections to currently processed connection
                            TreeArray.SetNodeConnRingNo(TreeIdx, TreeNodeIdxSrc, i, RingNo);
                            RingNo++;
                            // get index of connection of destination node in xml-node-list that has the correspoinding connection description to currently processed connection
                            XMLPortIdxCorrespRingConn =  ListXML.GetIdxOfConnAtCorrespRingNode(XMLNodeIdxDest, NodeNameSrc, PortNameSrc);
                            // assign index of corresponding node of this ring connection to currently processed connection
                            TreeArray.SetRingCnCorrespIdxOfNode(TreeIdx, TreeNodeIdxSrc, i, RingConnNodeIdx);
                            // assign index of corresponding connection of this ring connection to currently processed connection
                            TreeArray.SetRingCnCorrespIdxOfConn(TreeIdx, TreeNodeIdxSrc, i, XMLPortIdxCorrespRingConn);
                            //check if this is a multiport (e.g. tool changer)
                            Multiport = ListXML.GetConnMultiPort(XMLNodeIdxSrc, i);
                            // if multiport
                            // -> save the node name of the first device connected to this port
                            if(true == Multiport) ListXML.SetConnMuPoDestDev(XMLNodeIdxSrc, i, NodeNameDest);
                        }
                        else
                        {
                            // this connection type is a parent connection
                            TreeArray.SetNodeConnCnType(TreeIdx, TreeNodeIdxSrc, i, cn_type_parent);
                        }// end of if(ConnDescrParentCheck != ConnDescrCurrentCheck)
                    }
                    else
                    {
                        // this node (XMLNodeIdxDest) is not processed yet => currently processed connection type is a child connection
                        // set the type of currently processed connection to a child connection
                        TreeArray.SetNodeConnCnType(TreeIdx, TreeNodeIdxSrc, i, cn_type_child);
                        // add a new node element (child node) to current tree and set child node's reference (node index) to parent node
                        NodeIdxChild = TreeArray.AddNewTreeNodeWithParentIdx(TreeNodeIdxSrc);
                        // set the reference (node index) to new child node within it's parent (currently processed) node and
                        // get the index of currently added child connection index (= index of only child connections!)
                        // info: child connection references are stored in an array
                        ChildIdx = TreeArray.SetIdxOfChildNodeInParentNode(TreeIdx, TreeNodeIdxSrc, NodeIdxChild);
                        // assign current index of child connections to currently processed connection description
                        TreeArray.SetNodeConnChildNo(TreeIdx, TreeNodeIdxSrc, i, ChildIdx);
                        // assign it's reference within xml-node-list to child node within the node tree
                        TreeArray.SetIdxOfNodeInXMLList(TreeIdx, NodeIdxChild, XMLNodeIdxDest);
                        // assign some attibutes of child node within node tree by copying them from the xml-node-list
                        TreeArray.SetNodeName(TreeIdx, NodeIdxChild, NodeNameDest);
                        TreeArray.SetNodeAttrib(TreeIdx, NodeIdxChild, ListXML.GetNodeAttribAtIdx(XMLNodeIdxDest));
                        TreeArray.SetNodeDeviceType(TreeIdx,NodeIdxChild, ListXML.GetNodeDeviceTypeAtIdx(XMLNodeIdxDest));
                        TreeArray.SetNodeDiagInfo(TreeIdx,NodeIdxChild, ListXML.GetNodeDiagInfoAtIdx(XMLNodeIdxDest));
                        TreeArray.SetNodeDiagInfoSub(TreeIdx,NodeIdxChild, ListXML.GetNodeDiagInfoSubAtIdx(XMLNodeIdxDest));
                        TreeArray.SetNodeURL_BGZ(TreeIdx,NodeIdxChild, ListXML.GetNodeURL_BGZAtIdx(XMLNodeIdxDest));
                        // set child node as already processed
                        NodeListXMLProcessedInTree[XMLNodeIdxDest] = true;
                        // assign the reference of child node in node tree to array of nodes in xml-node-list
                        NodeInTreeRefNodeXML.AddNewXMLRef(XMLNodeIdxDest, TreeIdx, NodeIdxChild);
                        //check if this is a multiport (e.g. tool changer)
                        Multiport = ListXML.GetConnMultiPort(XMLNodeIdxSrc, i);
                        // if multiport
                        // -> save the node name of the first device connected to this port
                        if(true == Multiport) ListXML.SetConnMuPoDestDev(XMLNodeIdxSrc, i, NodeNameDest);
                        // check if child node has connections
                        if(0 != ListXML.GetNoOfConnAtNodeIdx(XMLNodeIdxDest))
                        {
                            // recursive function call of tree generator to process connections of child node
                            TreeGenerate(ListXML, TreeIdx, NodeIdxChild);
                        }
                    } // end of if(NodeListXMLProcessedInTree[XMLNodeIdxDest] == true)
                }
                else
                {
                    // NodeNameSrc equals NodeNameDest => plausibility check failure
                    //alert("ERROR: SrcNode->"+NodeNameSrc+" and DestNode->"+NodeNameDest+" are equal!" + "<p>");
                }// end of if(NodeNameSrc != NodeNameDest)
            }// end of if(BlankString == NodeNameDest)
        }// end of if(false == ConnValidity)
    }// end of for(i = 0; i < XMLNodeConnNoSrc; i++)
} // end of function TreeGenerate(TreeIdx, TreeNodeIdxSrc)


/******************************************************************************************************/

// TreeCalcNodeVertLayer relates every node to a vertical column according to node's type
function TreeCalcNodeVertLayer(TreeIdx, TreeNodeIdx, NodeVertLayer)
{
    var NodeConnCount = 0;
    var ChildNodeIdx = 0;
    var ChildNo = 0;
    var NoOfChildNodes = 0;
    var i;

    NoOfChildNodes = TreeArray.GetNoOfChildNodes(TreeIdx, TreeNodeIdx);
    // set node's vertical column
    TreeArray.SetNodeVertLayer(TreeIdx, TreeNodeIdx, NodeVertLayer);
    // if root (node index == parent index) node of tree
    if(TreeNodeIdx == TreeArray.GetParentIdxOfNode(TreeIdx, TreeNodeIdx))
    {
        // type of root node is always star node
        TreeArray.SetNodeType(TreeIdx, TreeNodeIdx, node_type_star);
        // get number of child connections
        NodeConnCount= TreeArray.GetNoOfNodeConn(TreeIdx, TreeNodeIdx);
        // for every connection of these node
        for(i = 0; i < NodeConnCount; i++)
        {
            // if connection type is child
            if(cn_type_child == TreeArray.GetNodeConnCnType(TreeIdx, TreeNodeIdx, i))
            {
                // get index of child node within node tree
                // call recursive function with increased vertical column for child node
                ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(TreeIdx, TreeNodeIdx, ChildNo);
                TreeCalcNodeVertLayer(TreeIdx, ChildNodeIdx, (NodeVertLayer + 1));
                ChildNo++;
            }
        }
        return 0;
    }
    else
    {
        // not a root node of tree
        if(0 == NoOfChildNodes)
        {
            // node has no child nodes, node type is last node
            TreeArray.SetNodeType(TreeIdx, TreeNodeIdx, node_type_last);
            return 0;
        }
        else if(1 == NoOfChildNodes)
        {
            // node is the last node of a line or a node within a line
            // while next nodes types are only nodes of a line
            while(NoOfChildNodes == 1)
            {
                // node has one child node, node type is node within a line
                TreeArray.SetNodeType(TreeIdx, TreeNodeIdx, node_type_line);
                // set node's vertical column
                TreeArray.SetNodeVertLayer(TreeIdx, TreeNodeIdx, NodeVertLayer);
                // get index of first child node of current node within node-array
                TreeNodeIdx   = TreeArray.GetIdxTreeNodeByChildIdx(TreeIdx, TreeNodeIdx, 0);
                // get number of child nodes of child node of current node
                NoOfChildNodes = TreeArray.GetNoOfChildNodes(TreeIdx, TreeNodeIdx);
            }

            if(NoOfChildNodes > 1)
            {
                // call recursive function with the same vertical column for child nodes
                TreeCalcNodeVertLayer(TreeIdx,TreeNodeIdx,NodeVertLayer);
                return 0;
            }

            // node has no child nodes, node type is last node of a line
            TreeArray.SetNodeType(TreeIdx, TreeNodeIdx, node_type_line_last);
            // set node's vertical column
            TreeArray.SetNodeVertLayer(TreeIdx, TreeNodeIdx, NodeVertLayer);
            return 0 ;
        }
        else
        {
            // number of child nodes > 1, node type is a star node
            TreeArray.SetNodeType(TreeIdx, TreeNodeIdx, node_type_star);

            ChildNo = 0;

            NodeConnCount= TreeArray.GetNoOfNodeConn(TreeIdx, TreeNodeIdx);
            // for every connection of these node
            for(i = 0; i < NodeConnCount; i++)
            {
                // if connection type is child
                if(cn_type_child == TreeArray.GetNodeConnCnType(TreeIdx, TreeNodeIdx, i))
                {
                    // get index of child node within node tree
                    // call recursive function with increased vertical column for child node
                    ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(TreeIdx, TreeNodeIdx, ChildNo);
                    TreeCalcNodeVertLayer(TreeIdx,ChildNodeIdx, (NodeVertLayer + 1));
                    ChildNo++;
                }
            }
            return 0;
        }
    }
}

// TreeNodeRingCheck defines the painting side of ring and connector ports of a node
function TreeNodeRingCheck(IdxOfTree, IdxOfNodeInTree)
{
    var ChildIdx = 0;
    var ChildNodeIdx = 0;
    var NodeConnCount = 0;
    var NodeVertLayer = 0;
    var CnType = 0;
    var i;

    NodeVertLayer = TreeArray.GetNodeVertLayer(IdxOfTree, IdxOfNodeInTree);
    // assign a node side to a node port of a ring nonnection
    RingConnCheck(IdxOfTree, IdxOfNodeInTree, NodeVertLayer);

    NodeConnCount = TreeArray.GetNoOfNodeConn(IdxOfTree, IdxOfNodeInTree);
    // for every connection of node
    for(i = 0; i < NodeConnCount; i++)
    {
        CnType = TreeArray.GetNodeConnCnType(IdxOfTree, IdxOfNodeInTree, i);
        if(CnType == cn_type_child)
        {
            // get index of child
            ChildIdx = TreeArray.GetNodeConnChildNo(IdxOfTree, IdxOfNodeInTree, i);
            // get index of child node of node-array
            ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(IdxOfTree, IdxOfNodeInTree, ChildIdx);
            // call recursive function and process child node
            TreeNodeRingCheck(IdxOfTree, ChildNodeIdx);
        }
    }
}

// TreeCalcNodeStructStarLeftLineLast defines the height of following node types
// line, line_last, last, star (only left side)
function TreeCalcNodeStructStarLeftLineLast(IdxOfTree, IdxOfNodeInTree)
{
    var ChildIdx = 0;
    var ChildNodeIdx = 0;
    var NodeConnCount = 0;

    var NodeRingPortPosX = 0;
    var NodeVertLayer = 0;
    var NodeType = 0;
    var NodeSize = 0;

    var CnType = 0;
    var i;

    NodeType = TreeArray.GetNodeType(IdxOfTree, IdxOfNodeInTree);

    if((NodeType == node_type_line) ||
       (NodeType == node_type_line_last) ||
       (NodeType == node_type_last))
    {
        NodeVertLayer = TreeArray.GetNodeVertLayer(IdxOfTree, IdxOfNodeInTree);

        NodeSize = CalcNodeSize(IdxOfTree, IdxOfNodeInTree, NodeType);

        TreeArray.SetNodeSizeX(IdxOfTree, IdxOfNodeInTree, NodeMatrixXSize);
        TreeArray.SetNodeSizeY(IdxOfTree, IdxOfNodeInTree, NodeSize);
        // set the port order in node concerning to the node type
        NodeNoStarCalcPortPosition(IdxOfTree, IdxOfNodeInTree);
    }

    if(NodeType == node_type_star)
    {
        NodeStarLeftSidePortPosition(IdxOfTree, IdxOfNodeInTree);
    }

    NodeConnCount = TreeArray.GetNoOfNodeConn(IdxOfTree, IdxOfNodeInTree);
    for(i = 0; i < NodeConnCount; i++)
    {
        CnType = TreeArray.GetNodeConnCnType(IdxOfTree, IdxOfNodeInTree, i);

        if(CnType == cn_type_child)
        {
            ChildIdx = TreeArray.GetNodeConnChildNo(IdxOfTree, IdxOfNodeInTree, i);

            ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(IdxOfTree, IdxOfNodeInTree, ChildIdx);
            // set the port order in node concerning to the node type
            TreeCalcNodeStructStarLeftLineLast(IdxOfTree, ChildNodeIdx);
        }
    }
}

// TreeClacNodeSize defines the height of a star node and line of nodes
function TreeClacNodeSize(TreeIdx, TreeNodeIdx)
{
    var MatrixNodeSize = 0;

    var NodeConnCount = 0;
    var ChildNodeIdx = 0;
    var ChildNo = 0;
    var NoOfChildNodes = 0;
    var NoOfNotConnected = 0;

    var CnType = "";

    var ModuleSpacingSum = 0;
    var ChildNodesYSize = 0;
    var LastChildNodeYSize = 0;

    var RingPortPosYFound = 0;
    var LastUsedChildPortY = 0;

    var NoOfPortFitY = 0;
    var LastUsedParentPortY = 0;
    var TreeNodeIdxTemp = 0;
    var SumSize = 0;
    var i;


    NoOfChildNodes = TreeArray.GetNoOfChildNodes(TreeIdx, TreeNodeIdx);

     // if root node of tree or star node
    if(TreeNodeIdx == TreeArray.GetParentIdxOfNode(TreeIdx, TreeNodeIdx) || (1 < NoOfChildNodes))
    {
        NodeConnCount = TreeArray.GetNoOfNodeConn(TreeIdx, TreeNodeIdx);
        // for every node connection
        for(i = 0; i < NodeConnCount; i++)
        {
            // if connection type is child connection
            if(cn_type_child == TreeArray.GetNodeConnCnType(TreeIdx, TreeNodeIdx, i))
            {
                // get index of child node in node-array
                ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(TreeIdx, TreeNodeIdx, ChildNo);
                // recursive function returns the grid height of nodes connected at this child connection
                MatrixNodeSize = TreeClacNodeSize(TreeIdx,ChildNodeIdx);
                // increase grid height by last result
                SumSize += MatrixNodeSize;
                // next child connection
                ChildNo++;
            }
        }
        // process grid node spacing depending on number of child nodes
        ModuleSpacingSum = ((ChildNo - 1) * MatrixModuleSpacingY);
        // increase grid height by node spacing of child nodes
        SumSize += ModuleSpacingSum;
        // copy var
        ChildNodesYSize = SumSize;
        // copy grid size (height) of last processed child node
        LastChildNodeYSize = MatrixNodeSize;
        // process grid height of star node port of last port that is connected to a child node
        // = whole grid height of star node (inludes the grid size (height) of last processed child node) -
        //   grid size (height) of last processed child node + grid height of node head (here head of the last processed child node)
        LastUsedChildPortY = ChildNodesYSize - LastChildNodeYSize + NodeCellHeadHeight;
        // get the last grid (height) position of a port that is connected to a ring connection on the left side of a node;
        // the grid (height) position of port is relative to child node (ChildNodeIdx)
        RingPortPosYFound = StarLastRightConnectionCheck(TreeIdx, TreeNodeIdx, ChildNodeIdx);
        // for every connection; get the number of not connected ports of this node at it's right side
        for(i = 0; i < NodeConnCount; i++)
        {
            CnType = TreeArray.GetNodeConnCnType(TreeIdx, TreeNodeIdx, i);

            if((CnType == cn_type_not_conn) ||
               (CnType == cn_type_connector_right) ||
               (CnType == cn_type_corrupt))
            {
                NoOfNotConnected += 1;
            }
        }
        // if ring connection found
        if(0 != RingPortPosYFound)
        {
            // adjust the grid height of the last connected port that is used by the (TreeNodeIdx) node
            LastUsedParentPortY = LastUsedChildPortY + (RingPortPosYFound - 1);
        }
        else
        {
            // the grid height of the last connected port of (TreeNodeIdx) node is the last port of a child connection
            LastUsedParentPortY = LastUsedChildPortY;
        }
        // calculate how many ports fit into the right side of a star node, before the star node height
        // exceeds the height of the last child node(s) of this star node
        NoOfPortFitY = ChildNodesYSize - LastUsedParentPortY - NodeCellBottHeight - 1; // -1 because if index base
        // if the star node height exceeds the size of last child node, adjust the star node size
        if(NoOfPortFitY < NoOfNotConnected) SumSize += (NoOfNotConnected - NoOfPortFitY);
        // set the width and height grid size of node
        TreeArray.SetNodeSizeX(TreeIdx, TreeNodeIdx, NodeMatrixXSize);
        TreeArray.SetNodeSizeY(TreeIdx, TreeNodeIdx, SumSize);

        return SumSize;
    }
    else
    {
        // if last child node of star node; ! not last node of a line, because all line elements are processed below
        if(0 == NoOfChildNodes)
        {

            NodeConnCount = TreeArray.GetNoOfNodeConn(TreeIdx, TreeNodeIdx);

            if(0 == NodeConnCount)
            {
                MatrixNodeSize = 1;
            }
            else if(1 == NodeConnCount)
                 {
                     // node has one connection -> one port; size (grid height) = node head(1) + node body(1) + node bottom (1)
                     MatrixNodeSize = 3;
                 }
                 else
                 {
                     // node has more than one connection -> get node grid height
                     MatrixNodeSize = CalcNodeSize(TreeIdx, TreeNodeIdx, node_type_last);
                 }
            // set the width and height grid size of node
            TreeArray.SetNodeSizeX(TreeIdx, TreeNodeIdx, NodeMatrixXSize);
            TreeArray.SetNodeSizeY(TreeIdx, TreeNodeIdx, MatrixNodeSize);

            return MatrixNodeSize;
        }
        else // no of child nodes == 1
        {
            // node is the beginning of a line
            TreeNodeIdxTemp = TreeNodeIdx;
            // while nodes parts of a line
            while(NoOfChildNodes == 1)
            {
                NodeConnCount = TreeArray.GetNoOfNodeConn(TreeIdx, TreeNodeIdxTemp);

                if(0 == NodeConnCount)
                {
                    SumSize++;
                    MatrixNodeSize = 1;
                }
                else if(1 == NodeConnCount)
                {
                    // node has one connection -> one port; size (grid height) = node head(1) + node body(1) + node bottom (1)
                    MatrixNodeSize = 3;
                }
                else if(NodeConnCount == 2)
                {
                    // node has two connections parent + child, both are on the left side -> node grid height = 4
                    MatrixNodeSize = 4;
                    }
                    else
                    {
                        // get node grid height
                        MatrixNodeSize = CalcNodeSize(TreeIdx, TreeNodeIdxTemp, node_type_line);
                    }

                // set the width and height grid size of node
                TreeArray.SetNodeSizeX(TreeIdx, TreeNodeIdxTemp, NodeMatrixXSize);
                TreeArray.SetNodeSizeY(TreeIdx, TreeNodeIdxTemp, MatrixNodeSize);
                // increase node line grid (height) size
                SumSize += (MatrixNodeSize + MatrixModuleSpacingY);
                // get index of child node within node-array
                TreeNodeIdxTemp   = TreeArray.GetIdxTreeNodeByChildIdx(TreeIdx, TreeNodeIdxTemp, 0);
                // get number of child nodes of upper (TreeNodeIdxTemp) child node
                NoOfChildNodes = TreeArray.GetNoOfChildNodes(TreeIdx, TreeNodeIdxTemp);
            }// end of while(NoOfChildNodes == 1)

            if(NoOfChildNodes > 1)
            {
                // recursive function returns the grid height of nodes connected to this star node
                MatrixNodeSize = TreeClacNodeSize(TreeIdx,TreeNodeIdxTemp);
                // set the width and height grid size of node
                TreeArray.SetNodeSizeX(TreeIdx, TreeNodeIdxTemp, NodeMatrixXSize);
                TreeArray.SetNodeSizeY(TreeIdx, TreeNodeIdxTemp, MatrixNodeSize);
                // set the height grid size of the node line
                TreeArray.SetLineSize(TreeIdx,TreeNodeIdx,(SumSize + MatrixNodeSize));

                return(SumSize + MatrixNodeSize);
            }
            else
            {
                // node has no child nodes -> last node of a line
                NodeConnCount = TreeArray.GetNoOfNodeConn(TreeIdx, TreeNodeIdxTemp);
                if(0 == NodeConnCount)
                {
                    MatrixNodeSize = 1;
                    // set the width and height grid size of node
                    TreeArray.SetNodeSizeX(TreeIdx, TreeNodeIdxTemp, NodeMatrixXSize);
                    TreeArray.SetNodeSizeY(TreeIdx, TreeNodeIdxTemp, MatrixNodeSize);

                    return SumSize;
                }
                else if(1 == NodeConnCount)
                {
                    // node has one connection -> one port; size (grid height) = node head(1) + node body(1) + node bottom (1)
                    MatrixNodeSize = 3;
                    // set the width and height grid size of node
                    TreeArray.SetNodeSizeX(TreeIdx, TreeNodeIdxTemp, NodeMatrixXSize);
                    TreeArray.SetNodeSizeY(TreeIdx, TreeNodeIdxTemp, MatrixNodeSize);
                }
                else
                {
                    // get node grid height
                    MatrixNodeSize = CalcNodeSize(TreeIdx, TreeNodeIdxTemp, node_type_line_last);
                    // set the width and height grid size of node
                    TreeArray.SetNodeSizeX(TreeIdx, TreeNodeIdxTemp, NodeMatrixXSize);
                    TreeArray.SetNodeSizeY(TreeIdx, TreeNodeIdxTemp, MatrixNodeSize);
                }
            }
            // set the height grid size of the node line
            TreeArray.SetLineSize(TreeIdx,TreeNodeIdx,(SumSize + MatrixNodeSize));

            return(SumSize + MatrixNodeSize);
        }
    }
}

// StarLastRightConnectionCheck processes the (relative to it's node) grid (height) position
// of the last port that is connected to a ring connection on the right side of a star node;
// this port position is determined by the port of the corresponding node of a ring connection
function StarLastRightConnectionCheck(TreeIdx, TreeNodeIdx, SearchNodeIdx)
{
    var NoOfChildNodes = 0;
    var NodeConnCount = 0;
    var CorrespNodeIdx = 0;
    var ChildNodeIdx = 0;
    var NodeSizeY = 0;
    var RingPortPosY = 0;
    var RingPortPosYFound = 0;
    var RingPortPosYMax = 0;
    var i;

    // get number of connections of node at SearchNodeIdx
    NodeConnCount = TreeArray.GetNoOfNodeConn(TreeIdx, SearchNodeIdx);
    // for every connection
    for(i = 0; i < NodeConnCount; i++)
    {
        // if this connection type is a ring connection on the left side of the node
        if(cn_type_ring_left == TreeArray.GetNodeConnCnType(TreeIdx, SearchNodeIdx, i))
        {
            // get index of node that corresponds to this ring connection
            CorrespNodeIdx = TreeArray.GetRingCnCorrespIdxOfNode(TreeIdx, SearchNodeIdx, i);
            // if both nodes are connected to a ring; for debugging
            if(TreeNodeIdx == CorrespNodeIdx)
            {
                // get grid position of ring connection within node
                RingPortPosYFound = TreeArray.GetNodeConnPortPosY(TreeIdx, SearchNodeIdx, i);
                // check if maximum grid position (height) of ring port should be increased
                if(RingPortPosYMax < RingPortPosYFound) RingPortPosYMax = RingPortPosYFound;
            }
            else
            {
                // for debugging
                console && console.log && console.log('ERROR: Ring conn left!');
            }
        }
    }

    NoOfChildNodes = TreeArray.GetNoOfChildNodes(TreeIdx, SearchNodeIdx);
    if(1 != NoOfChildNodes)
    {
        // port processing is ready for last and star nodes
        return RingPortPosYMax;
    }
    else
    {
        // node is part of a line
        NodeSizeY = TreeArray.GetNodeSizeY(TreeIdx, SearchNodeIdx);
        // get index of child node within node-array
        ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(TreeIdx, SearchNodeIdx, 0);
        // call recursive function and process child node
        RingPortPosY = StarLastRightConnectionCheck(TreeIdx, TreeNodeIdx, ChildNodeIdx);
        // if there was any more ring connection with port type reing connection on left side of node
        if(0 != RingPortPosY)
        {
            return (NodeSizeY + RingPortPosY + MatrixModuleSpacingY);
        }
        else
        {
            // there was no more ring connection, on the left side of node, found that will be painted
            return RingPortPosYMax;
        }
    }
}

// RingConnCheck assignes a port of a ring connection to the left or right node side
function RingConnCheck(TreeIdx, TreeNodeIdx, NodeVertLayer)
{

    var RingConnIdx = 0;
    var RingConnNodeIdx = 0;
    var RingConnNodeVertLayer = 0;
    var RingHorLayerDelta = 0;
    var NodeConnCount = 0;
    var NoOfStarNodes = 0;
    var ParentNodeIdx = 0;
    var NodeTypeSelf  = 0;
    var NodeTypeRingConn = 0;
    var i;

    NodeConnCount = TreeArray.GetNoOfNodeConn(TreeIdx, TreeNodeIdx);

    NodeTypeSelf = TreeArray.GetNodeType(TreeIdx, TreeNodeIdx);
    for(i = 0; i < NodeConnCount; i++)
    {
        if(cn_type_ring == TreeArray.GetNodeConnCnType(TreeIdx, TreeNodeIdx, i))
        {
            // get index of ring connection
            RingConnIdx = TreeArray.GetNodeConnRingNo(TreeIdx, TreeNodeIdx, i);
            // get index of node with corresponding ring connection port
            RingConnNodeIdx = TreeArray.GetIdxOfRingConnNode(TreeIdx, TreeNodeIdx, RingConnIdx);
            // get vertical column of corresponding node of ring connection
            RingConnNodeVertLayer = TreeArray.GetNodeVertLayer(TreeIdx, RingConnNodeIdx);
            // process delta of both vertical columns
            RingHorLayerDelta = NodeVertLayer - RingConnNodeVertLayer;
            // assign a node side to the processed ring port
            if(1 == Math.abs(RingHorLayerDelta))
            {
                // check node type of corresponding node and of current node of this ring connection
                // if node type of ring connection is a star node OR node type of current node is a star
                //      -> connection will be painted
                // else -> connectors will be painted

                NodeTypeRingConn = TreeArray.GetNodeType(TreeIdx, RingConnNodeIdx);
                if((node_type_star == NodeTypeRingConn) || (node_type_star == NodeTypeSelf))
                {
                    if(RingHorLayerDelta > 0)
                    {
                        // corresponding node on the left side
                        TreeArray.SetNodeConnCnType(TreeIdx, TreeNodeIdx, i, cn_type_ring_left);
                    }
                    else
                    {
                        // corresponding node on the right side
                        TreeArray.SetNodeConnCnType(TreeIdx, TreeNodeIdx, i, cn_type_ring_right);
                    }
                }
                else
                {
                    if(RingHorLayerDelta > 0)
                    {
                        // corresponding node on the left side
                        TreeArray.SetNodeConnCnType(TreeIdx, TreeNodeIdx, i, cn_type_connector_left);
                    }
                    else
                    {
                        // corresponding node on the right side
                        TreeArray.SetNodeConnCnType(TreeIdx, TreeNodeIdx, i, cn_type_connector_right);
                    }

                }
            }
            else if(0 == RingHorLayerDelta)
            {
                // corresponding node at the same horizontal layer
                TreeArray.SetNodeConnCnType(TreeIdx, TreeNodeIdx, i, cn_type_connector_right);
            }
            else if(RingHorLayerDelta > 0)
            {
                // corresponding node on the left side
                TreeArray.SetNodeConnCnType(TreeIdx, TreeNodeIdx, i, cn_type_connector_left);
            }
            else
            {
                // corresponding node on the right side
                TreeArray.SetNodeConnCnType(TreeIdx, TreeNodeIdx, i, cn_type_connector_right);
            }
        }
    }
}

// CalcNodeSize calculates the grid node height of a certain node type depending on
// the node design defined in NodeBody structures
function CalcNodeSize(TreeIdx, TreeNodeIdx, NodeType)
{
    var MatrixNodeSize = 0;
    var NodeBodySizeLeft = 0;
    var NodeBodySizeRight = 0;
    var CnType = "";
    var NodeConnCount = 0;
    var NodeBodyLeftElementCnt = 0;
    var NodeBodyRightElementCnt = 0;
    var i,j;

    NodeConnCount = TreeArray.GetNoOfNodeConn(TreeIdx, TreeNodeIdx);
    NodeBodyLeftElementCnt  = NodeBody[NodeType][node_body_left_side].length;
    NodeBodyRightElementCnt = NodeBody[NodeType][node_body_right_side].length;

    for(i = 0; i < NodeConnCount; i++)
    {
        CnType = TreeArray.GetNodeConnCnType(TreeIdx, TreeNodeIdx, i);
        // check elements of left node side
        for(j = 0; j < NodeBodyLeftElementCnt; j++)
        {
            if(CnType == NodeBody[NodeType][node_body_left_side][j]) NodeBodySizeLeft++;
        }
        // check elements of right node side
        for(j = 0; j < NodeBodyRightElementCnt; j++)
        {
            if(CnType == NodeBody[NodeType][node_body_right_side][j]) NodeBodySizeRight++;
        }

    }// end of for(i = 0; i < NodeConnCount; i++)

    if(NodeConnCount != (NodeBodySizeLeft + NodeBodySizeRight))
        console && console.log && console.log("Error: conn-elements (tree/node/type)"+ TreeIdx + "/" + TreeNodeIdx + "/" + NodeType);

    if(NodeBodySizeLeft > NodeBodySizeRight)
    {
        MatrixNodeSize = NodeBodySizeLeft;
    }
    else
    {
        MatrixNodeSize = NodeBodySizeRight;
    }
    // + head + bottom
    MatrixNodeSize += 2;

    return MatrixNodeSize;
}

function CreateNodeIdentifierObj(HeadDivSizeX, HeadDivSizeY, NodeNameOrig, NodeClassName, NodeURL_BGZ, NoSStringSizeStart)
{
    var NodeNameCrop = "";
    var NodeNameCropSave = "";
    var ToolTipIdx = 0;

    var TxtObjNodeNameCrop = "";
    var TxtObjNodeNameOrig = "";
    var AnkerObjHead = "";
    var AttribAnkerObjHeadStyle = "";
    var DivObjToolTip = "";
    var AttribObjToolTipStyle = "";

    var DivObjTemp = "";
    var DivObjTempStyle = "";
    var DivObjIdentifier = "";

    var AnchorObjTemp = "";
    var AnchorObjTempStyle = "";

    var TextObjTemp = "";

    var TextObjSizeX = 0;
    var TextObjSizeY = 0;

    var NodeNameSizeX = 0;
    var NodeNameSizeY = 0;

    var NodeIdFontSize = 0;

    var NoSStringSize = NoSStringSizeStart;
    NodeNameSizeX = HeadDivSizeX - (2*ImgObjHeadBorder) - (2*DiagInfoIconSizeX) - (2 * 4); // 4 for spacing left/right
    NodeNameSizeY = ((HeadDivSizeY - (2*ImgObjHeadBorder))>>1);

    if(NodeNameSizeY < 7)
    {
        ObjNodeName = top.document.createTextNode("");
    }
    else
    {
        DivObjTemp = top.document.createElement("div");
        DivObjTemp.setAttribute("class", "DivObjTemp");        
        DivObjTemp.style.lineHeight = (NodeNameSizeY - 1) + "px";
        DivObjTemp.style.fontSize = NodeNameSizeY - 2;

        TextObjTemp = top.document.createTextNode(NodeNameOrig);
        OutputDOMObj(DivObjTemp);
        DivObjTemp.appendChild(TextObjTemp);
        TextObjSizeX = DivObjTemp.offsetWidth;

        if(NodeNameSizeX < TextObjSizeX)
        {
            NodeNameCrop = NodeNameOrig.slice(0,NoSStringSize);
            TextObjTemp.data = NodeNameCrop;
            NodeNameCropSave = NodeNameCrop;
            //Iteration
            while(NodeNameSizeX > (DivObjTemp.offsetWidth + GlobTextObjSizeX))
            {
                NodeNameCropSave = NodeNameCrop;
                NodeNameCrop = NodeNameOrig.slice(0,NoSStringSize++);
                TextObjTemp.data = NodeNameCrop;
            }

            NodeNameCrop = NodeNameCropSave.concat("...");
            TxtObjNodeNameCrop = top.document.createTextNode(NodeNameCrop);
            ObjNodeName = TxtObjNodeNameCrop;
        }
        else
        {
            ObjNodeName = top.document.createTextNode(NodeNameOrig);
        }

        RemoveDOMObj(DivObjTemp);
        ObjNodeName = BindLink2Obj(NodeURL_BGZ, ObjNodeName, 'AnchorObjTemp');
    }

    DivObjIdentifier = top.document.createElement("div");
    DivObjIdentifier.setAttribute("class", NodeClassName);
    DivObjIdentifier.appendChild(ObjNodeName);
    OutputDOMObj(DivObjIdentifier);

    // if ObjNodeName has child nodes (here a text node) it is a anchor(link) object
    // if ObjNodeName hasn't child nodes it is a text node
    // if ObjNodeName is an anchor(link) object then the anchor style "text color"
    // have to be the same as the style "text color" of its parent node
    if(ObjNodeName.hasChildNodes())
    {
        ProcessStyleTextColor(ObjNodeName, NodeClassName);
    }
    else
    {
        ProcessStyleTextColor(DivObjIdentifier, NodeClassName);
    }

//    DivObjIdentifier.style.height = (NodeNameSizeY) + "px";
    DivObjIdentifier.style.fontSize = NodeNameSizeY - 2;
    return DivObjIdentifier;
}

function CreatePortNameObj(LLDPPortID, DivObjPortLabel, ToolTipXPosPx, ToolTipYPosPx, PortLabelAlign)
{
    var ToolTipIdx = 0;
    var TxtObjPortNameCrop = "";
    var TxtObjPortName = "";

    var DivObjToolTip = "";
    var ToolTipSizeX = 0;
    var ToolTipPosXAdjust = 0;

    var ToolTipBackGroundDivObj = "";

    var PortNameBegin = "P";
    var PortNameEnd = "";
    var PortName = "";
    var PortNamePrint = "";
    var PortNamePadding = "...";

    var PortNameToolTip = "";

    var SlotNameBegin = "M";
    var SlotNameEnd = "";
    var SlotName = "";

    var PortID = "";
    var PortIDVal = "";

    PortID = LLDPPortID.substr(5,3);
    PortIDVal = parseInt(PortID, 10);

    PortNameEnd = String(PortIDVal);
    PortName = PortNameBegin.concat(PortNameEnd);

    switch(LLDPPortID.length)
    {
        case LLDPPortIDEmpty:
        {
            PortNamePrint = LLDPPortID;
            TxtObjPortNameCrop = top.document.createTextNode(PortNamePrint);
            break;
        }

        case LLDPPortIDLong:
        {
            SlotID = LLDPPortID.substr(9,5);
            SlotIDVal = parseInt(SlotID, 10);

            SlotNameEnd = String(SlotIDVal);
            SlotName = SlotNameBegin.concat(SlotNameEnd);

            if((SlotName.length + PortName.length) > PortNameLengthMax)
            {
                PortNamePrint = PortNamePadding.concat(PortName);
                PortNameToolTip = SlotName.concat(PortName);

                ToolTipIdx = ToolTipArray.AddNewToolTip(ToolTipAttribPortLabel);

                TxtObjPortName = top.document.createTextNode(PortNameToolTip);

                DivObjToolTip    = top.document.createElement("div");
                DivObjToolTip.id = ToolTipArray.GetToolTipID(ToolTipIdx);

                if(false == PrintOutput)
                {
                    DivObjToolTip.setAttribute("class", "DivTopoToolTip");
                }
                else
                {
                    DivObjToolTip.setAttribute("class", "DivTopoToolTipPrint");
                }

                DivObjToolTip.appendChild(TxtObjPortName);

                OutputDOMObj(DivObjToolTip);

                ToolTipSizeX = DivObjToolTip.offsetWidth;
                ToolTipSizeY = DivObjToolTip.offsetHeight;

                if(port_label_align_left == PortLabelAlign)
                {
                    if(NodeCellPortWidth < ToolTipSizeX)
                    {
                        ToolTipPosXAdjust = ToolTipSizeX - NodeCellPortWidth;
                        ToolTipXPosPx -= ToolTipPosXAdjust;
                    }

                    ToolTipArray.SetToolTipDefaultPosX(ToolTipIdx, ToolTipXPosPx - 2); // - 2 border
                }
                else
                {
                    ToolTipArray.SetToolTipDefaultPosX(ToolTipIdx, ToolTipXPosPx);
                }

                ToolTipArray.SetToolTipDefaultPosY(ToolTipIdx, ToolTipYPosPx + PortLabelObjAdjustmentPxY);

                DivObjToolTip.style.left = ToolTipArray.GetToolTipDefaultPosX(ToolTipIdx) + "px";
                DivObjToolTip.style.top  = ToolTipArray.GetToolTipDefaultPosY(ToolTipIdx) + "px";

                TxtObjPortNameCrop = top.document.createTextNode(PortNamePrint);

                if(false == PrintOutput)
                {
                    DivObjPortLabel.id = ToolTipArray.GetReferenceID(ToolTipIdx);

                    DivObjPortLabel.onmouseover = ToolTipVisible;  // Opera + FF + IE
                    DivObjPortLabel.onmouseout  = ToolTipHidden; // Opera + FF + IE
                }
                else
                {
                    DivObjToolTip.style.visibility = "visible";

                    ToolTipBackGroundDivObj = top.document.createElement("div");
                    ToolTipBackGroundDivObj.setAttribute("class", "DivTopoToolTipBackground");

                    ToolTipBackGroundDivObj.style.width  = (ToolTipSizeX + 2) + "px"; // +2 border
                    ToolTipBackGroundDivObj.style.height = (ToolTipSizeY + 2) + "px"; // +2 border

                    OutputDOMObj(ToolTipBackGroundDivObj);

                    ToolTipBackGroundDivObj.style.left = (ToolTipArray.GetToolTipDefaultPosX(ToolTipIdx) - 1) + "px";
                    ToolTipBackGroundDivObj.style.top  = (ToolTipArray.GetToolTipDefaultPosY(ToolTipIdx) - 1) + "px";
                }
            }
            else
            {
                PortNamePrint = SlotName.concat(PortName);
                TxtObjPortNameCrop = top.document.createTextNode(PortNamePrint);
            }
            break;
        }

        case LLDPPortIDShort:
        default:
        {
            PortNamePrint = PortName;
            TxtObjPortNameCrop = top.document.createTextNode(PortNamePrint);
            break;
        }
    }

    DivObjPortLabel.style.textAlign = PortLabelAlign;
    DivObjPortLabel.appendChild(TxtObjPortNameCrop);
}


function CreateNodeHeadToolTipDiv(ToolTipXPosPx, ToolTipYPosPx)
{
    var ToolTipIdx = null;

    var DivObjToolTip = "";

    var ToolTipTable = "";
    var TableRow = "";
    var TableDataCol1 = "";
    var TableDataCol2 = "";
    var TableDataText1 = "";
    var TableDataText2 = "";
    var i = 0;

	var ToolTipNoSPrefix = top.topo_name; //"Name:";
	var ToolTipDevTypePrefix = top.topo_type; //"Type:";
	var ToolTipDevStatusPrefix = top.topo_status; //"Status:";

    ToolTipIdx = ToolTipArray.AddNewToolTip(ToolTipAttribNodeHead);
    DivObjToolTip    = top.document.createElement("div");
    DivObjToolTip.id = ToolTipArray.GetToolTipID(ToolTipIdx);
    DivObjToolTip.setAttribute("class", "DivTopoToolTip");

    ToolTipTable = top.document.createElement("table");
    ToolTipTable.setAttribute("class", "TopoToolTipTable");

    for(i = 0; i <= 2; i++)
    {
        TableRow = ToolTipTable.insertRow(i);

        TableDataText1 = top.document.createTextNode("");
        TableDataText2 = top.document.createTextNode("");

        TableDataCol1 = top.document.createElement("td");
        TableDataCol1.style.whiteSpace = "nowrap";
        TableDataCol1.style.border = "0px solid #000000";
        TableDataCol1.style.padding = "0px";

        TableDataCol2 = top.document.createElement("td");
        TableDataCol2.style.whiteSpace = "nowrap";
        TableDataCol2.style.border = "0px solid #000000";
        TableDataCol2.style.paddingLeft = "2px";

        TableDataCol1.appendChild(TableDataText1);
        TableDataCol2.appendChild(TableDataText2);

        TableRow.appendChild(TableDataCol1);
        TableRow.appendChild(TableDataCol2);
        TableRow.style.padding = "0px";
    }

    DivObjToolTip.appendChild(ToolTipTable);

    OutputDOMObj(DivObjToolTip);

    SetToolTipPrefixNoS(ToolTipIdx, ToolTipNoSPrefix);
    SetToolTipPrefixDevType(ToolTipIdx, ToolTipDevTypePrefix);
    SetToolTipPrefixTextStatus(ToolTipIdx, ToolTipDevStatusPrefix);

    ToolTipArray.SetToolTipDefaultPosX(ToolTipIdx, ToolTipXPosPx);
    ToolTipArray.SetToolTipDefaultPosY(ToolTipIdx, ToolTipYPosPx);

    DivObjToolTip.style.left = (0) + "px"; // AP00845027 tool tip parking coordinates are (0,0)
    DivObjToolTip.style.top  = (0) + "px"; // because of scroll bar depending on maximal relative tool tip X extension

    return ToolTipIdx;
}

function SetToolTipText(ToolTipIdx, TableCol, TableRow, Text)
{
    var ToolTipID = "";
    var ToolTipObj = "";
    var TableObj = "";

    ToolTipID  = ToolTipArray.GetToolTipID(ToolTipIdx);

    ToolTipObj = top.document.getElementById(ToolTipID);

    TableObj = ToolTipObj.getElementsByTagName("tbody");

    TableObj[0].childNodes[TableRow].childNodes[TableCol].childNodes[0].nodeValue = Text;
}

function BindToolTip2Obj(ToolTipIdx, Obj)
{
    ToolTipIdxNew = 0;
    ToolTipID = 0;

    ToolTipIdxNew = ToolTipArray.AddNewToolTip(ToolTipAttribNodeHead);

    ToolTipID = ToolTipArray.GetToolTipID(ToolTipIdx);

    ToolTipArray.SetToolTipIDAtIdx(ToolTipIdxNew, ToolTipID);

    ToolTipArray.SetToolTipDefaultPosX(ToolTipIdxNew, ToolTipArray.GetToolTipDefaultPosX(ToolTipIdx));
    ToolTipArray.SetToolTipDefaultPosY(ToolTipIdxNew, ToolTipArray.GetToolTipDefaultPosY(ToolTipIdx));

    Obj.id = ToolTipArray.GetReferenceID(ToolTipIdxNew);

    Obj.onmouseover = ToolTipVisible; // Opera + FF + IE
    Obj.onmouseout  = ToolTipHidden;  // Opera + FF + IE
    Obj.onclick     = ToolTipHidden;  // Opera + FF + IE
}


function OutputDOMObj(Obj)
{
    OutputObj.appendChild(Obj);
}

function RemoveDOMObj(Obj)
{
    OutputObj.removeChild(Obj);
}

function ToolTipVisible()
{
    var ToolTipIdx = 0;
    var ReferenceID = "";
    var ToolTipID = "";
    var ToolTipAttrib = "";

    var DivObj = "";

    var ToolTipDefaultPosX = 0;
    var ToolTipDefaultPosY = 0;

    var ToolTipSizeX = 0;
    var ToolTipSizeY = 0;

    var ScrollOffsetX = 0;
    var ScrollOffsetY = 0;

    var ClientSizeX = 0;
    var ClientSizeY = 0;

    var ToolTipDisplayPosX = 0;
    var ToolTipDisplayPosY = 0;

    var TopoBackgroundDivPosX = 0;
    var TopoBackgroundDivPosY = 0;

    var PosDefRelX = 0;
    var PosDefRelY = 0;

    var PosAdjX = 0;
    var PosAdjY = 0;

    ReferenceID = this.id;

    ToolTipIdx = ToolTipArray.GetTooTipIdxByReferenceID(ReferenceID);
    ToolTipID  = ToolTipArray.GetToolTipID(ToolTipIdx);

    ToolTipDefaultPosX = ToolTipArray.GetToolTipDefaultPosX(ToolTipIdx);
    ToolTipDefaultPosY = ToolTipArray.GetToolTipDefaultPosY(ToolTipIdx);

    ToolTipSizeX = top.document.getElementById(ToolTipID).offsetWidth;
    ToolTipSizeY = top.document.getElementById(ToolTipID).offsetHeight;

    ScrollOffsetX = top.document.body.scrollLeft;
    ScrollOffsetY = top.document.body.scrollTop;

    ClientSizeX = top.document.body.clientWidth;
    ClientSizeY = top.document.body.clientHeight;

    TopoBackgroundDivPosX = top.document.getElementById("TopoBackgroundDiv").offsetLeft;
    TopoBackgroundDivPosY = top.document.getElementById("TopoBackgroundDiv").offsetTop;

    ToolTipAttrib = ToolTipArray.GetToolTipAttrib(ToolTipIdx);

    PosDefRelX = ToolTipTypePos.GetTTTPosDefRelX(ToolTipAttrib);
    PosDefRelY = ToolTipTypePos.GetTTTPosDefRelY(ToolTipAttrib);

    PosAdjX = ToolTipTypePos.GetTTTPosAdjX(ToolTipAttrib);
    PosAdjY = ToolTipTypePos.GetTTTPosAdjY(ToolTipAttrib);

    /* x-pos *************************************************************************************/
    if((ScrollOffsetX - TopoBackgroundDivPosX) > ToolTipDefaultPosX )
    {
        ToolTipDisplayPosX = ScrollOffsetX + PosAdjX - TopoBackgroundDivPosX;
    }
    else if((ScrollOffsetX + ClientSizeX - TopoBackgroundDivPosX) < (ToolTipDefaultPosX + ToolTipSizeX))
    {
        ToolTipDisplayPosX = (ScrollOffsetX + ClientSizeX - ToolTipSizeX) - PosAdjX - TopoBackgroundDivPosX;
    }
    else
    {
        ToolTipDisplayPosX = ToolTipDefaultPosX;
    }
    /* y-pos *************************************************************************************/
    if(ScrollOffsetY > (TopoBackgroundDivPosY + ToolTipDefaultPosY - PosDefRelY))
    {
        ToolTipDisplayPosY = ToolTipDefaultPosY + PosAdjY;
    }
    else
    {
        ToolTipDisplayPosY = ToolTipDefaultPosY - PosDefRelY;
    }
    /*********************************************************************************************/

    DivObj = top.document.getElementById(ToolTipID);

    DivObj.style.left = (ToolTipDisplayPosX) + "px";
    DivObj.style.top  = (ToolTipDisplayPosY) + "px";

    DivObj.style.visibility = "visible";
}

function ToolTipHidden()
{

    var ToolTipIdx = 0;
    var ReferenceID = "";
    var ToolTipID = "";
    var ToolTipObj = "";

    ReferenceID = this.id;

    ToolTipIdx = ToolTipArray.GetTooTipIdxByReferenceID(ReferenceID);
    ToolTipID  = ToolTipArray.GetToolTipID(ToolTipIdx);
    ToolTipObj = top.document.getElementById(ToolTipID);

    ToolTipObj.style.visibility = "hidden";
    ToolTipObj.style.left = (0) + "px";// AP00845027 tool tip parking coordinates are (0,0)
    ToolTipObj.style.top  = (0) + "px";// because of scroll bar depending on maximal relative tool tip X extension
}


function PortNameToolTipVisibleAll()
{

    var ToolTipIdx = 0;
    var ToolTipCount = 0;

    var ToolTipID = "";
    var DivObj = "";

    var ToolTipDefaultPosX = 0;
    var ToolTipDefaultPosY = 0;

    var ToolTipDisplayPosX = 0;
    var ToolTipDisplayPosY = 0;

    ToolTipCount = ToolTipArray.GetToolTipCount();

    for(ToolTipIdx = 0; ToolTipIdx < ToolTipCount; ToolTipIdx++)
    {
        if(ToolTipAttribPortLabel == ToolTipArray.GetToolTipAttrib(ToolTipIdx))
        {
            ToolTipID  = ToolTipArray.GetToolTipID(ToolTipIdx);

            ToolTipDisplayPosX = ToolTipArray.GetToolTipDefaultPosX(ToolTipIdx);
            ToolTipDisplayPosY = ToolTipArray.GetToolTipDefaultPosY(ToolTipIdx);

            DivObj = top.document.getElementById(ToolTipID);

            DivObj.style.left = (ToolTipDisplayPosX) + "px";
            DivObj.style.top  = (ToolTipDisplayPosY) + "px";

            DivObj.style.visibility = "visible";
        }
    }
}

function ProcessAttribObjStyle(NodeAttrib)
{
    var result = "";
    
    if (XMLNodeAttribDevNext2Project == (NodeAttrib & XMLNodeAttribDevNext2Project))
    {
        if(XMLNodeAttribDevNotAccessible == (NodeAttrib & XMLNodeAttribDevNotAccessible))
        {
            result = "DivTopoNodeHeadLabelDevNotAvailable";
        }
        else
        {
             result = "DivTopoNodeHeadLabelDevNotOfProject";
        }
    }
    else if(XMLNodeAttribDevDeactivated == (NodeAttrib & XMLNodeAttribDevDeactivated))
    {
        result = "DivTopoNodeHeadLabelDevDeactivated";
    }
    else if(XMLNodeAttribDevNotAccessible == (NodeAttrib & XMLNodeAttribDevNotAccessible))
    {
        result = "DivTopoNodeHeadLabelDevNotAvailable";
    }
    else if(XMLNodeAttribPNIORecReadError == (NodeAttrib & XMLNodeAttribPNIORecReadError))
    {
        if(("TopoGraph" == ModeGlob) || ("TopoGraphUpdate" == ModeGlob) || ("TopoGraphPrint" == ModeGlob))
        {
            result = "DivTopoNodeHeadLabel";
        }
        else if(("TopoBrief" == ModeGlob) || ("TopoBriefUpdate" == ModeGlob) || ("TopoBriefPrint" == ModeGlob))
        {
            result = "DivTopoNodeHeadLabelOverview";
        }
    }
    else if(XMLNodeAttribPNIORecNotPlaus == (NodeAttrib & XMLNodeAttribPNIORecNotPlaus))
    {   // should never happen but SCALANCE-X208 ...
        result.nodeValue = "DivTopoNodeHeadLabelDevNotOfProject";
    }
    else
    {
        if(("TopoGraph" == ModeGlob) || ("TopoGraphUpdate" == ModeGlob) || ("TopoGraphPrint" == ModeGlob))
        {
            result = "DivTopoNodeHeadLabel";
        }
        else if(("TopoBrief" == ModeGlob) || ("TopoBriefUpdate" == ModeGlob) || ("TopoBriefPrint" == ModeGlob))
        {
            result = "DivTopoNodeHeadLabelOverview";
        }
    }
    
    return result;
}

function ProcessStyleTextColor(Obj, CssClass)
{
    var TextColor = "#000000";

    // TextColor-Value should have the same value as the color element of of the corresponding css-class
    switch(CssClass)
    {
        case "DivTopoNodeHeadLabelDevNotAvailable":
        case "DivTopoNodeHeadLabelDevNotOfProject":
        case "DivTopoNodeHeadLabel":
        case "DivTopoNodeHeadLabelOverview":
        {
             TextColor = "#000000";
             break;
        }

        case "DivTopoNodeHeadLabelDevDeactivated":
        {
             TextColor = "#808080";
             break;
        }

        default:
        {
             console && console.log && console.log("Erronous CSS class");
             break;
        }
    }

    Obj.style.color = TextColor;
}


function PrintNodeDiv(IdxOfTree, IdxOfNodeInTree, NodeXPosPx, NodeYPosPx)
{
    var HeadDivSizeX = 0;
    var HeadDivSizeY = 0;

    var BodyDivSizeX = 0;

    var BottDivSizeX = 0;

    var DivObjHead = "";
    var DivObjBody = "";
    var DivObjBott = "";

    var ImgObjBody = "";
    var ImgObjHead = "";
    var DivObjHeadLabel = "";
    var ImgObjBott = "";

    var ImgObjDiagInfo = "";
    var DivObjDiagInfo = "";
    var DivObjDiagInfoStyle = "";

    var ImgObjDiagInfoSub = "";
    var DivObjDiagInfoSub = "";
    var DivObjDiagInfoSubStyle = "";


    var DivObjHeadDeviceType = "";
    var AttribObjDeviceTypeStyle = "";

    var DeviceTypeOffsetY = 0;

    var DiagInfoOffsetY = 0;

    var NodeNameSizeX = 0;

    var AttribObjHeadStyle = "";
    var AttribObjHeadLabelStyle = "";
    var AttribObjBodyStyle = "";
    var AttribObjBottStyle = "";

    var ObjNodeName = "";
    var TxtObjNodeNameOrig = "";
    var TxtObjNodeName = "";
    var AnkerObjHead = "";
    var SpanObjHead = "";
    var OuterSpanObjHead = "";

    var NodeHeadToolTipId = "";

    var NodeSizeYCrop = 0;

    var NodeNameOrig = "";
    var NodeNameShort = "";
    var NodeName = "";
    var NodeAttrib = 0;
    var DeviceType = "";
    var NodeDiagInfo = "";
    var NodeDiagInfoSub = "";
    var NodeURL_BGZ = "";

    var NodeIdxXMLList = 0;

    var BodySegmentNo = 0;
    var i;

    /*************************************************************************************/
    // head ******************************************************************************
    HeadDivSizeX = NodeCellWidth * PxMatrixCellSize;
    HeadDivSizeY = NodeCellHeadHeight * PxMatrixCellSize;

    NodeNameOrig = TreeArray.GetNodeName(IdxOfTree, IdxOfNodeInTree);
    NodeAttrib = TreeArray.GetNodeAttrib(IdxOfTree, IdxOfNodeInTree);
    /*************************************************************************************/
    // head label style ******************************************************************
    AttribObjHeadLabelStyle = ProcessAttribObjStyle(NodeAttrib);
    /*************************************************************************************/
    // head div **************************************************************************
    if(false == PrintOutput)
    {
        NodeURL_BGZ = TreeArray.GetNodeURL_BGZ(IdxOfTree, IdxOfNodeInTree);
    }

    DivObjHead = GenDivObj(NodeXPosPx, NodeYPosPx, HeadDivSizeX, HeadDivSizeY);
    DivObjHead.setAttribute("class", "DivTopoNodeHead");

    ImgObjHead = top.document.createElement("img");
    ProcessImgObjHead(ImgObjHead, NodeAttrib, HeadDivSizeX, HeadDivSizeY);
    // if link is required an anchor-node is the parent-node of the img-node
    // this binding is required because of IE.x (otherwise no link cursor is shown)
    // other browser also support an anchor-node as a parent-node of the div-node below
    ImgObjHead = BindLinkHead2Obj(NodeURL_BGZ, ImgObjHead, NodeNameOrig);

    DivObjHead.appendChild(ImgObjHead);

    OutputDOMObj(DivObjHead);
    // for node highlightning
    NodeIdxXMLList = TreeArray.GetIdxOfNodeInXMLList(IdxOfTree, IdxOfNodeInTree);

    TopoListXMLSave.SetOverHeadDivObjAtIdx(NodeIdxXMLList, DivObjHead);
    /*************************************************************************************/
	// DiagInfo position *****************************************************************
	if((HeadDivSizeY - ImgObjHeadBorder) < DiagInfoIconSizeY)
	{
	    DiagInfoIconSizeY = (HeadDivSizeY - ImgObjHeadBorder);
	}
	DiagInfoIconOffsetY = ((HeadDivSizeY - DiagInfoIconSizeY)>>1);

	DiagInfoIconOffsetX = DiagInfoIconOffsetY;
    /*************************************************************************************/
    // DiagInfo **************************************************************************
    NodeDiagInfo    = TreeArray.GetNodeDiagInfo(IdxOfTree, IdxOfNodeInTree);
    DivObjDiagInfo = GenDivObjDiagInfo((NodeXPosPx + ImgObjHeadBorder),
                                       (NodeYPosPx + DiagInfoIconOffsetY),
                                       DiagInfoIconSizeX,
                                       DiagInfoIconSizeY,
                                       NodeAttrib,
                                       NodeDiagInfo,
                                       NodeURL_BGZ);

    OutputDOMObj(DivObjDiagInfo);
    TopoListXMLSave.SetOverDiagInfoDivObjAtIdx(NodeIdxXMLList, DivObjDiagInfo);
    /*************************************************************************************/
    // DiagInfoSub ***********************************************************************
    NodeDiagInfoSub = TreeArray.GetNodeDiagInfoSub(IdxOfTree, IdxOfNodeInTree);
    DivObjDiagInfoSub = GenDivObjDiagInfo((NodeXPosPx + ImgObjHeadBorder + DiagInfoIconSizeX),
                                          (NodeYPosPx + DiagInfoIconOffsetY),
                                          DiagInfoIconSizeX,
                                          DiagInfoIconSizeY,
                                          NodeAttrib,
                                          NodeDiagInfoSub,
                                          NodeURL_BGZ);

    OutputDOMObj(DivObjDiagInfoSub);
    TopoListXMLSave.SetOverDiagInfoSubDivObjAtIdx(NodeIdxXMLList, DivObjDiagInfoSub);
    /*************************************************************************************/
    // head label ************************************************************************
//    NodeNameOrig = TreeArray.GetNodeName(IdxOfTree, IdxOfNodeInTree);

    NodeNameOrig = ProcessNodeName (NodeNameOrig, NodeAttrib);

    DivObjHeadLabel = CreateNodeIdentifierObj(HeadDivSizeX, HeadDivSizeY, NodeNameOrig, AttribObjHeadLabelStyle, NodeURL_BGZ, NoSStringSizeStart);

    TopoListXMLSave.SetOverNodeNameDivObjAtIdx(NodeIdxXMLList, DivObjHeadLabel);
    // head label position ***************************************************************
    DivObjHeadLabel.style.left = (NodeXPosPx + DiagInfoIconSizeX + ((HeadDivSizeX - DivObjHeadLabel.offsetWidth) >> 1)) + "px";
    DivObjHeadLabel.style.top  = (NodeYPosPx + ImgObjHeadBorder) + "px";
    /*************************************************************************************/
    // device type ***********************************************************************
    DeviceType = TreeArray.GetNodeDeviceType(IdxOfTree, IdxOfNodeInTree);

    DeviceTypeOffsetY = DeviceTypeNodeLabelOffsetY;

    DivObjHeadDeviceType = CreateNodeIdentifierObj(HeadDivSizeX, HeadDivSizeY, DeviceType, AttribObjHeadLabelStyle, NodeURL_BGZ, NoSStringSizeStart);

    DivObjHeadDeviceType.style.fontWeight = 'normal';

    TopoListXMLSave.SetOverDeviceTypeDivObjAtIdx(NodeIdxXMLList, DivObjHeadDeviceType);
    // head label position ***************************************************************
    DivObjHeadDeviceType.style.left = (NodeXPosPx + DiagInfoIconSizeX + ((HeadDivSizeX - DivObjHeadDeviceType.offsetWidth) >> 1)) + "px";
    DivObjHeadDeviceType.style.top  = (NodeYPosPx + ImgObjHeadBorder + DivObjHeadLabel.offsetHeight) + "px";
    /*************************************************************************************/
    // node head tool tip processing *****************************************************
    if(false == PrintOutput)
    {
        ToolTipIdx = CreateNodeHeadToolTipDiv(NodeXPosPx, NodeYPosPx);

        BindToolTip2Obj(ToolTipIdx, DivObjHead);
        BindToolTip2Obj(ToolTipIdx, DivObjDiagInfo);
        BindToolTip2Obj(ToolTipIdx, DivObjDiagInfoSub);
        BindToolTip2Obj(ToolTipIdx, DivObjHeadLabel);
        BindToolTip2Obj(ToolTipIdx, DivObjHeadDeviceType);

        SetToolTipNoS(ToolTipIdx, NodeNameOrig);
        SetToolTipDevType(ToolTipIdx, DeviceType);
        SetToolTipTextStatus(ToolTipIdx, NodeAttrib, NodeDiagInfoSub);
    }
    /*************************************************************************************/
    // body ******************************************************************************


    BodyDivSizeX = NodeCellWidth * PxMatrixCellSize;

    NodeSizeYCrop = TreeArray.GetNodeSizeYCrop(IdxOfTree, IdxOfNodeInTree);

    BodySegmentNo = (NodeSizeYCrop - (NodeCellHeadHeight + NodeCellBottHeight));

    DivObjBody = top.document.createElement("div");
    DivObjBody.style.top  = (NodeYPosPx + HeadDivSizeY) + "px";
    DivObjBody.style.left = (NodeXPosPx) + "px";
    DivObjBody.style.width  = (BodyDivSizeX) + "px";
    DivObjBody.style.height = ((BodySegmentNo * PxMatrixCellSize) + NodeCellBottHeightPx) + "px";
    DivObjBody.setAttribute("class", "DivTopoNodeBodyBackground");

    OutputDOMObj(DivObjBody);

    /*************************************************************************************/
    // bott ******************************************************************************
    BottDivSizeX = NodeCellWidth * PxMatrixCellSize;

    DivObjBott = top.document.createElement("div");
    DivObjBott.style.top  = (NodeYPosPx + HeadDivSizeY) + "px";
    DivObjBott.style.left = (NodeXPosPx + NodeCellBottHeightPx) + "px"; // NodeCellBottHeightPx = node body border

    DivObjBott.style.width  = (BottDivSizeX - (2 * NodeCellBottHeightPx)) + "px";
    DivObjBott.style.height = (BodySegmentNo * PxMatrixCellSize) + "px";

    DivObjBott.setAttribute("class", "DivTopoNodeBodyForeground");

    /*************************************************************************************/
    // OutputModulDIVs**** ***************************************************************

    OutputDOMObj(DivObjBott);
}

function CalcOverviewMatrix()
{
   var ClientSizeX = 0;
   var ClientSizeY = 0;

   var NodesNo = 0;
   var NodesNoX = 0;
   var NodesNoY = 0;


   var NodeSizeXCalc = 0;
   var NodeSizeYCalc = 0;

   var NoOfXMLNodes = 0;

   var PicObj = top.document.getElementById("pic");

   var ScrollOffsetX = top.document.body.scrollLeft;
   var ScrollOffsetY = top.document.body.scrollTop;

   var NodeScalingFac = 6.25;
   var SpacingScalingFac = 10;

   var SpacingXY = 0;

   var NodeSizeXDelta = 0;
   var NodeSizeYDelta = 0;
   var SpacingXYDelta = 0;

   ClientSizeX = document.body.clientWidth - (118 + TopoPaintPxOffsetX);
   //ClientSizeY = document.body.clientHeight - (186 + TopoPaintPxOffsetY);
   ClientSizeY = window.innerHeight - (186 + TopoPaintPxOffsetY);

/*
   var PicPosX = top.document.getElementById("pic").offsetWidth;
   var PicPosY = top.document.getElementById("pic").offsetHeight;

   alert("PicPosX:" + PicPosX + "\n" +
         "PicPosY:" + PicPosY);
*/
/*
   var ClienOuterSizeX = window.outerWidth;
   var ClienOuterSizeY = window.outerHeight;

   var ClienInnerSizeX = document.body.clientWidth;
   var ClienInnerSizeY = document.body.clientHeight;


   alert("OuterSizeX:" + ClienOuterSizeX + "OuterSizeY: " + ClienOuterSizeY + "\n" +
         "InnerSizeX:" + ClienInnerSizeX + "InnerSizeY: " + ClienInnerSizeY);
*/
   SpacingXY = TopoOverview.GetNodeSpacingXmax();

   NodeSizeXCalc = TopoOverview.GetNodeSizeXmax();//TopoOverview.GetNodeSpacingXmax();
   NodeSizeYCalc = TopoOverview.GetNodeSizeYmax();//TopoOverview.GetNodeSpacingYmax();

   NoOfXMLNodes = TopoListXMLSave.GetNoOfNodes();
   TopoOverview.SetNoOfNodesXML(NoOfXMLNodes);

   if(0 != NoOfXMLNodes)
   {
       // shrink node size if necessary

       NodesNoX = Math.floor(ClientSizeX/(NodeSizeXCalc + SpacingXY));
       NodesNoY = Math.floor(ClientSizeY/(NodeSizeYCalc + SpacingXY));

       if(0 == NodesNoX) NodesNoX = 1;

       NodesNo = NodesNoX * NodesNoY;

       while((NodesNo < NoOfXMLNodes) &&
             ((NodeSizeXCalc - NodeSizeXDelta) > TopoOverview.GetNodeSizeXmin()) &&
             ((NodeSizeYCalc - NodeSizeYDelta) > TopoOverview.GetNodeSizeYmin()) &&
             ((SpacingXY - SpacingXYDelta) > TopoOverview.GetNodeSpacingXmin()))
       {
           NodeSizeXDelta++;
           NodeSizeYDelta = Math.floor(NodeSizeXDelta/NodeScalingFac);
           SpacingXYDelta = Math.floor(NodeSizeXDelta/SpacingScalingFac);

           NodesNoX = Math.floor(ClientSizeX/((NodeSizeXCalc - NodeSizeXDelta) + (SpacingXY - SpacingXYDelta)));
           NodesNoY = Math.floor(ClientSizeY/((NodeSizeYCalc - NodeSizeYDelta) + (SpacingXY - SpacingXYDelta)));

           NodesNo = NodesNoX * NodesNoY;
       }

    NodeSizeXCalc -= NodeSizeXDelta;
    NodeSizeYCalc -= NodeSizeYDelta;
    SpacingXY -= SpacingXYDelta;

    /**********************************************/
    TopoOverview.SetNodePaintSizeX(NodeSizeXCalc);
    TopoOverview.SetNodePaintSizeY(NodeSizeYCalc);
    TopoOverview.SetNodeSpacingX(SpacingXY);
    TopoOverview.SetNodeSpacingY(SpacingXY);
    TopoOverview.SetNodesNoX(NodesNoX);
    TopoOverview.SetNodesNoY(NodesNoY);
    /**********************************************/
/*
alert("SizeX: " + NodeSizeXCalc + "\n" +
      "SizeY: " + NodeSizeYCalc + "\n" +
      "Spacing: " + SpacingXY);
*/
    /* print background div *******************************************************************/
    if(PrintOutput == true)
    {
       TopoPrintBackground((TopoOverview.GetPaintSizeX() + TopoPaintPxOffsetX),
                        (TopoOverview.GetPaintSizeY() + TopoPaintPxOffsetY),
                        '#FFFFFF');
    }
    else
    {
        TopoPrintBackground((TopoOverview.GetPaintSizeX() + TopoPaintPxOffsetX),
                        (TopoOverview.GetPaintSizeY() + TopoPaintPxOffsetY),
                        '#EAEAEA');
    }
    /******************************************************************************************/

    }
}

function PrintOverview()
{
   var NoOfNodes = 0;
   var NodesNoX = 0;

   var NodeXPosPx = 0;
   var NodeYPosPx = 0;

   var i = 0;
   var j = 0;

   NodeXPosPx = TopoPaintPxOffsetX;
   NodeYPosPx = TopoPaintPxOffsetY;

   NoOfNodes = TopoOverview.GetNoOfNodesXML();

   NodesNoX = TopoOverview.GetNodesNoX();


   while(i < NoOfNodes)
   {
       NodeXPosPx = TopoPaintPxOffsetX;

       while((j < NodesNoX) && (i < NoOfNodes))
       {
           PrintOverviewNodeDiv(i, NodeXPosPx, NodeYPosPx);
           // next column
           NodeXPosPx += (TopoOverview.GetNodePaintSizeX() + TopoOverview.GetNodeSpacingX());
           i++; // inc node number
           j++; // inc column number
       }

       NodeYPosPx += (TopoOverview.GetNodePaintSizeY() + TopoOverview.GetNodeSpacingY());
       j = 0;
   }
}


function ProcessNodeName (NodeNameOrig, NodeAttrib)
{
    var NodeNameReturn = "";
    var NodeNamePraefix = "device <";

    NodeNameReturn = NodeNameOrig;

    if((XMLNodeAttribDevNotAccessible == (NodeAttrib & XMLNodeAttribDevNotAccessible)) ||
       (XMLNodeAttribPNIORecReadError == (NodeAttrib & XMLNodeAttribPNIORecReadError)) ||
       (XMLNodeAttribPNIORecNotPlaus == (NodeAttrib & XMLNodeAttribPNIORecNotPlaus)))
    {
        if(!isNaN(NodeNameOrig))
        {
            NodeNameReturn = NodeNamePraefix.concat(NodeNameOrig);
            NodeNameReturn = NodeNameReturn.concat(">");
        }
    }

    return NodeNameReturn;
}

function ProcessImgObjHead(ImgObjHead, NodeAttrib, NodeSizeX, NodeSizeY)
{
    var NodeSizeXWithBorder = 0;
    var NodeSizeYWithBorder = 0;

    var NodeSizeXWithBorder = NodeSizeX - (2 * ImgObjHeadBorder);
    var NodeSizeYWithBorder = NodeSizeY - (2 * ImgObjHeadBorder);

    ImgObjHead.style.width  = (NodeSizeXWithBorder) + "px";
    ImgObjHead.style.height = (NodeSizeYWithBorder) + "px";
    ImgObjHead.style.borderWidth = (ImgObjHeadBorder) + "px";

    if (XMLNodeAttribDevNext2Project == (NodeAttrib & XMLNodeAttribDevNext2Project))
    {
        if(XMLNodeAttribDevNotAccessible == (NodeAttrib & XMLNodeAttribDevNotAccessible))
        {
             ImgObjHead.src = ModuleAtoGifs[mb_head_not_available];
             ImgObjHead.style.borderStyle = "dashed";
             ImgObjHead.style.borderColor = "#FF2557";
        }
        else
        {
             ImgObjHead.src = ModuleAtoGifs[mb_head_not_of_project];
             ImgObjHead.style.borderStyle = "dashed";
             ImgObjHead.style.borderColor = "#808080";
        }
    }
    else if(XMLNodeAttribDevDeactivated == (NodeAttrib & XMLNodeAttribDevDeactivated))
    {
       ImgObjHead.src = ModuleAtoGifs[mb_head_not_of_project];
       ImgObjHead.style.borderStyle = "solid";
       ImgObjHead.style.borderColor = "#808080";
    }
    else if(XMLNodeAttribDevNotAccessible == (NodeAttrib & XMLNodeAttribDevNotAccessible))
    {
        ImgObjHead.src = ModuleAtoGifs[mb_head_not_available];
        ImgObjHead.style.borderStyle = "solid";
        ImgObjHead.style.borderColor = "#FF2557";
    }
    else if(XMLNodeAttribPNIORecReadError == (NodeAttrib & XMLNodeAttribPNIORecReadError))
    {
        if(("TopoGraph" == ModeGlob) || ("TopoGraphUpdate" == ModeGlob) || ("TopoGraphPrint" == ModeGlob))
        {
            ImgObjHead.src = ModuleAtoGifs[mb_head];
            ImgObjHead.style.borderStyle = "solid";
            ImgObjHead.style.borderColor = "#808080";
        }
        else if(("TopoBrief" == ModeGlob) || ("TopoBriefUpdate" == ModeGlob) || ("TopoBriefPrint" == ModeGlob))
        {
            ImgObjHead.src = ModuleAtoGifs[mb_head_overview];
            ImgObjHead.style.borderStyle = "solid";
            ImgObjHead.style.borderColor = "#a9a9a9";
        }
    }
    else if(XMLNodeAttribPNIORecNotPlaus == (NodeAttrib & XMLNodeAttribPNIORecNotPlaus))
    {   // should never happen but SCALANCE-X208 ...
        ImgObjHead.src = ModuleAtoGifs[mb_head_not_of_project];
        ImgObjHead.style.borderStyle = "solid";
        ImgObjHead.style.borderColor = "#FF2557";
    }
    else if(XMLNodeAttribHighlight == (NodeAttrib & XMLNodeAttribHighlight))
    {
        ImgObjHead.style.borderStyle = "solid";
        ImgObjHead.style.borderColor = "#00FF00";
    }
    else
    {
        if(("TopoGraph" == ModeGlob) || ("TopoGraphUpdate" == ModeGlob) || ("TopoGraphPrint" == ModeGlob))
        {
            ImgObjHead.src = ModuleAtoGifs[mb_head];
            ImgObjHead.style.borderStyle = "solid";
            ImgObjHead.style.borderColor = "#808080";
        }
        else if(("TopoBrief" == ModeGlob) || ("TopoBriefUpdate" == ModeGlob) || ("TopoBriefPrint" == ModeGlob))
        {
            ImgObjHead.src = ModuleAtoGifs[mb_head_overview];
            ImgObjHead.style.borderStyle = "solid";
            ImgObjHead.style.borderColor = "#a9a9a9";
        }
    }
}

function GetNodeStatusText(NodeAttrib, DiagSubError)
{
    var StatusText = "";

    if (XMLNodeAttribDevNext2Project == (NodeAttrib & XMLNodeAttribDevNext2Project))
    {
        if(XMLNodeAttribDevNotAccessible == (NodeAttrib & XMLNodeAttribDevNotAccessible))
        {
            StatusText = top.topo_not_part_not_avail; //"device not available/reachable (not part of current PN-IO system)";
        }
        else
        {
            StatusText = top.topo_not_part; //"device not part of current PN-IO system";
        }
    }
    else if(XMLNodeAttribDevDeactivated == (NodeAttrib & XMLNodeAttribDevDeactivated))
    {
        StatusText = top.topo_deactivated; //"device deactivated";
    }
    else if(XMLNodeAttribDevNotAccessible == (NodeAttrib & XMLNodeAttribDevNotAccessible))
    {
        StatusText =  top.topo_not_avail; //"device not available/reachable";
    }
    else if(XMLNodeAttribPNIORecReadError == (NodeAttrib & XMLNodeAttribPNIORecReadError))
    {
        StatusText = top.topo_not_detect; //"network topology of device not detectable";
    }
    else if(XMLNodeAttribPNIORecNotPlaus == (NodeAttrib & XMLNodeAttribPNIORecNotPlaus))
    {   // should never happen but SCALANCE-X208 ...
        StatusText = top.topo_format_error; //"network topology of device not plausible / format error";
    }
    else
    {
        StatusText = top.topo_ok; //"device ok";
    }
    if(DiagSubError == DiagAtoGif_SubFail)
    {
       StatusText += ". " + top.topo_subfault;
    }

    return StatusText;
}


function GenDivObj(PosX, PosY, SizeX, SizeY)
{
    var DivObj = "";

    DivObj = top.document.createElement("div");
    DivObj.style.left = (PosX) + "px";
    DivObj.style.top  = (PosY) + "px";
    DivObj.style.width  = (SizeX) + "px";
    DivObj.style.height = (SizeY) + "px";

    return DivObj;
}

function GenDivObjDiagInfo(PosX, PosY, SizeX, SizeY, NodeAttrib, NodeDiagInfo, NodeURL_BGZ)
{
    var DivObjDiagInfo = "";
    var ImgObjDiagInfo = "";
    var DivObjDiagInfoStyle = "";

    DivObjDiagInfo = GenDivObj(PosX, PosY, SizeX, SizeY);

    ImgObjDiagInfo = top.document.createElement("img");

    if(0 == NodeDiagInfo)
    {
        ImgObjDiagInfo.src = ModuleAtoGifs[mb_head]; // as default gif
        DivObjDiagInfo.style.zIndex = '9';
    }
    else
    {
        ImgObjDiagInfo.src = DiagAtoGifs[NodeDiagInfo];
        DivObjDiagInfo.style.zIndex = '13';
    }

    ImgObjDiagInfo.style.width  = (SizeX) + "px";
    ImgObjDiagInfo.style.height = (SizeY) + "px";
    ImgObjDiagInfo.style.border = "0px solid #FFFFFF";

    DivObjDiagInfoStyle = ProcessAttribObjStyle(NodeAttrib);
    DivObjDiagInfo.setAttribute("class", DivObjDiagInfoStyle);

    ImgObjDiagInfo = BindLink2Obj(NodeURL_BGZ, ImgObjDiagInfo, 'AnchorObjTemp');

    DivObjDiagInfo.appendChild(ImgObjDiagInfo);

    return DivObjDiagInfo;
}


function PrintOverviewNodeDiv(IdxOfNode, NodeXPosPx, NodeYPosPx)
{
    var HeadDivSizeX = 0;
    var HeadDivSizeY = 0;

    var BodyDivSizeX = 0;

    var BottDivSizeX = 0;
    var BottDivSizeY = 0;

    var DivObjHead = "";
    var DivObjBody = "";
    var DivObjBott = "";

    var ImgObjBody = "";
    var ImgObjHead = "";
    var DivObjHeadLabel = "";
    var ImgObjBott = "";

    var ImgObjDiagInfo = "";
    var DivObjDiagInfo = "";
    var DivObjDiagInfoStyle = "";

    var ImgObjDiagInfoSub = "";
    var DivObjDiagInfoSub = "";
    var DivObjDiagInfoSubStyle = "";


    var DivObjHeadDeviceType = "";
    var AttribObjDeviceTypeStyle = "";

    var DeviceTypeOffsetY = 0;

    var DiagInfoOffsetY = 0;

    var NodeNameSizeX = 0;

    var AttribObjHeadStyle = "";
    var AttribObjHeadLabelStyle = "";
    var AttribObjBodyStyle = "";
    var AttribObjBottStyle = "";

    var ObjNodeName = "";
    var TxtObjNodeNameOrig = "";
    var TxtObjNodeName = "";
    var AnkerObjHead = "";
    var SpanObjHead = "";
    var OuterSpanObjHead = "";

    var NodeHeadToolTipId = "";

    var NodeSizeYCrop = 0;

    var NodeNameOrig = "";
    var NodeNameShort = "";
    var NodeName = "";
    var NodeAttrib = 0;
    var DeviceType = "";
    var NodeDiagInfo = "";
    var NodeDiagInfoSub = "";
    var NodeURL_BGZ = "";

    var DiagInfoIconOffsetY = 0;

    var BodySegmentNo = 0;
    var i;

    // head ******************************************************************************
    HeadDivSizeX = TopoOverview.GetNodePaintSizeX();
    HeadDivSizeY = TopoOverview.GetNodePaintSizeY();

    NodeAttrib = TopoListXMLSave.GetNodeAttribAtIdx(IdxOfNode);
    /*************************************************************************************/
    // head label style ******************************************************************
    AttribObjHeadLabelStyle = ProcessAttribObjStyle(NodeAttrib);
    /*************************************************************************************/
    // head div **************************************************************************
    if(false == PrintOutput)
    {
        NodeURL_BGZ = TopoListXMLSave.GetNodeURL_BGZAtIdx(IdxOfNode);
    }

    DivObjHead = GenDivObj(NodeXPosPx, NodeYPosPx, HeadDivSizeX, HeadDivSizeY);
    DivObjHead.setAttribute("class", "DivTopoNodeHead");

    ImgObjHead = top.document.createElement("img");
    ProcessImgObjHead(ImgObjHead, NodeAttrib, HeadDivSizeX, HeadDivSizeY);
    // if link is required an anchor-node is the parent-node of the img-node
    // this binding is required because of IE.x (otherwise no link cursor is shown)
    // other browser also support an anchor-node as a parent-node of the div-node below
    ImgObjHead = BindLink2Obj(NodeURL_BGZ, ImgObjHead, 'AnchorObjTemp');

    DivObjHead.appendChild(ImgObjHead);

    OutputDOMObj(DivObjHead);

    TopoListXMLSave.SetOverHeadDivObjAtIdx(IdxOfNode, DivObjHead);
    /*************************************************************************************/
    // DiagInfo position *****************************************************************
    if((HeadDivSizeX - (2 * ImgObjHeadBorder)) < (2 * DiagInfoIconSizeX))
    {
        DiagInfoIconSizeX = ((HeadDivSizeX - (2 * ImgObjHeadBorder))>>1);
    }

    if((HeadDivSizeY - (2 * ImgObjHeadBorder)) < DiagInfoIconSizeY)
    {
        DiagInfoIconSizeY = (HeadDivSizeY - (2 * ImgObjHeadBorder));
    }

    DiagInfoIconSizeX = Math.min(DiagInfoIconSizeX, DiagInfoIconSizeY);

    DiagInfoIconSizeY = DiagInfoIconSizeX;

    DiagInfoIconOffsetX = ImgObjHeadBorder;

    DiagInfoIconOffsetY = ((HeadDivSizeY - DiagInfoIconSizeY)>>1);
    /*************************************************************************************/
    // DiagInfo **************************************************************************
    NodeDiagInfo    = TopoListXMLSave.GetNodeDiagInfoAtIdx(IdxOfNode);

    DivObjDiagInfo = GenDivObjDiagInfo((NodeXPosPx + ImgObjHeadBorder),
                                       (NodeYPosPx + DiagInfoIconOffsetY),
                                       DiagInfoIconSizeX,
                                       DiagInfoIconSizeY,
                                       NodeAttrib,
                                       NodeDiagInfo,
                                       NodeURL_BGZ);

    OutputDOMObj(DivObjDiagInfo);
    TopoListXMLSave.SetOverDiagInfoDivObjAtIdx(IdxOfNode, DivObjDiagInfo);
    /*************************************************************************************/
    // DiagInfo & DiagInfoSub ************************************************************
    NodeDiagInfoSub = TopoListXMLSave.GetNodeDiagInfoSubAtIdx(IdxOfNode);
    DivObjDiagInfoSub = GenDivObjDiagInfo((NodeXPosPx + ImgObjHeadBorder + DiagInfoIconSizeX),
                                          (NodeYPosPx + DiagInfoIconOffsetY),
                                          DiagInfoIconSizeX,
                                          DiagInfoIconSizeY,
                                          NodeAttrib,
                                          NodeDiagInfoSub,
                                          NodeURL_BGZ);

    OutputDOMObj(DivObjDiagInfoSub);
    TopoListXMLSave.SetOverDiagInfoSubDivObjAtIdx(IdxOfNode, DivObjDiagInfoSub);
    /*************************************************************************************/
    // head label ************************************************************************
    NodeNameOrig = TopoListXMLSave.GetNodeNameAtNodeIdx(IdxOfNode);

    NodeNameOrig = ProcessNodeName (NodeNameOrig, NodeAttrib);

    DivObjHeadLabel = CreateNodeIdentifierObj(HeadDivSizeX, HeadDivSizeY, NodeNameOrig, AttribObjHeadLabelStyle, NodeURL_BGZ, NoSStringSizeStart);

    TopoListXMLSave.SetOverNodeNameDivObjAtIdx(IdxOfNode, DivObjHeadLabel);
    // head label position ***************************************************************
    DivObjHeadLabel.style.left = (NodeXPosPx + DiagInfoIconSizeX + ((HeadDivSizeX - DivObjHeadLabel.offsetWidth) >> 1)) + "px";
    DivObjHeadLabel.style.top  = (NodeYPosPx + ImgObjHeadBorder) + "px";
    /*************************************************************************************/
    // device type ***********************************************************************
    DeviceType = TopoListXMLSave.GetNodeDeviceTypeAtIdx(IdxOfNode);

    DeviceTypeOffsetY = DeviceTypeNodeLabelOffsetY;

    DivObjHeadDeviceType = CreateNodeIdentifierObj(HeadDivSizeX, HeadDivSizeY, DeviceType, AttribObjHeadLabelStyle, NodeURL_BGZ, NoSStringSizeStart);

    DivObjHeadDeviceType.style.fontWeight = 'normal';

    TopoListXMLSave.SetOverDeviceTypeDivObjAtIdx(IdxOfNode, DivObjHeadDeviceType);
    // device type label position ********************************************************
    DivObjHeadDeviceType.style.left = (NodeXPosPx + DiagInfoIconSizeX + ((HeadDivSizeX - DivObjHeadDeviceType.offsetWidth) >> 1)) + "px";
    DivObjHeadDeviceType.style.top  = (NodeYPosPx + ImgObjHeadBorder + DivObjHeadLabel.offsetHeight) + "px"; // 2 spacing
    /*************************************************************************************/
    // node head tool tip processing *****************************************************
    if(false == PrintOutput)
    {
        ToolTipIdx = CreateNodeHeadToolTipDiv(NodeXPosPx, NodeYPosPx);

        BindToolTip2Obj(ToolTipIdx, DivObjHead);
        BindToolTip2Obj(ToolTipIdx, DivObjDiagInfo);
        BindToolTip2Obj(ToolTipIdx, DivObjDiagInfoSub);
        BindToolTip2Obj(ToolTipIdx, DivObjHeadLabel);
        BindToolTip2Obj(ToolTipIdx, DivObjHeadDeviceType);

        SetToolTipNoS(ToolTipIdx, NodeNameOrig);
        SetToolTipDevType(ToolTipIdx, DeviceType);
        SetToolTipTextStatus(ToolTipIdx, NodeAttrib, NodeDiagInfoSub);
    }
    /*************************************************************************************/
}

function BindLinkHead2Obj(NodeURL_BGZ, Obj, NodeName)
{
    var AnchorObjTemp = "";

    AnchorObjTemp = BindLink2Obj(NodeURL_BGZ, Obj, 'AnchorObjTemp');

    if("" != NodeURL_BGZ)
        AnchorObjTemp.name = NodeName;

    return AnchorObjTemp;
}

function BindLink2Obj(NodeURL_BGZ, Obj, AnchorStyle)
{
    var AnchorObjTemp = "";

    if("" != NodeURL_BGZ)
    {
        AnchorObjTemp = top.document.createElement("a");
        AnchorObjTemp.href = NodeURL_BGZ;
        AnchorObjTemp.setAttribute("class", AnchorStyle);
        AnchorObjTemp.appendChild(Obj);
    }
    else
    {
        AnchorObjTemp = Obj;
    }

    return AnchorObjTemp;
}

var ToolTipTextPosNoS = 0;
var ToolTipTextPosDevT = 1;
var ToolTipTextPosDevStat = 2;

function SetToolTipNoS(ToolTipIdx, NodeNameOrig)
{
    SetToolTipText(ToolTipIdx, 1, ToolTipTextPosNoS, NodeNameOrig);
}

function SetToolTipDevType(ToolTipIdx, DeviceType)
{
    SetToolTipText(ToolTipIdx, 1, ToolTipTextPosDevT, DeviceType);
}

function SetToolTipTextStatus(ToolTipIdx, NodeAttrib, NodeDiagInfoSub)
{
    var StatusText = "";

    StatusText = GetNodeStatusText(NodeAttrib, NodeDiagInfoSub);

    SetToolTipText(ToolTipIdx, 1, ToolTipTextPosDevStat, StatusText);
}

function SetToolTipPrefixNoS(ToolTipIdx, Text)
{
    SetToolTipText(ToolTipIdx, 0, ToolTipTextPosNoS, Text);
}

function SetToolTipPrefixDevType(ToolTipIdx, Text)
{
    SetToolTipText(ToolTipIdx, 0, ToolTipTextPosDevT, Text);
}

function SetToolTipPrefixTextStatus(ToolTipIdx, Text)
{
    SetToolTipText(ToolTipIdx, 0, ToolTipTextPosDevStat, Text);
}

function NodePortTypeAddStatus(ConnSide, ConnStatus)
{
    var PortType = "";

    switch(ConnSide)
    {
        case "left":
        {
            if(ConnStatusConnectionOk == (ConnStatus & ConnStatusConnectionOk))
            {
                PortType = mb_port_left_plug_ok;
            }
            else if(ConnStatusConnectionError == (ConnStatus & ConnStatusConnectionError))
                 {
                    PortType = mb_port_left_plug_error;
                 }
                 else if(ConnStatusConnectionNoDiag == (ConnStatus & ConnStatusConnectionNoDiag))
                      {
                          PortType = mb_port_left_plug_no_diag;
                      }
                      else
                      {
                          console && console.log && console.log("ERROR: Unknown left connection status!");
                      }
            break;
        }

        case "right":
        {
            if(ConnStatusConnectionOk == (ConnStatus & ConnStatusConnectionOk))
            {
                PortType = mb_port_right_plug_ok;
            }
            else if(ConnStatusConnectionError == (ConnStatus & ConnStatusConnectionError))
                 {
                    PortType = mb_port_right_plug_error;
                 }
                 else if(ConnStatusConnectionNoDiag == (ConnStatus & ConnStatusConnectionNoDiag))
                      {
                          PortType = mb_port_right_plug_no_diag;
                      }
                      else
                      {
                          console && console.log && console.log("ERROR: Unknown right connection status!");
                      }

            break;
        }

        default:
        {
            console && console.log && console.log("ERROR: Unknown connection side!");
            break;
        }
    }

    return PortType;
}

function PrintNodePorts(IdxOfTree, IdxOfNodeInTree, NodeXPosPx, NodeYPosPx)
{
    var NoOfNodeConn = 0;

    var PortPosXInModule = 0;
    var PortPosYInModule = 0;
    var PortCnType = "";

    var LLDPPortID = "";

    var SlotID = "";
    var SlotIDVal = 0;

    var DivObjPort = "";
    var ImgObjPort = "";
    var DivObjPortLabel = "";

    var PortLabelAlign = port_label_align_left;

    var PortDivSizeX = 0;
    var PortDivSizeY = 0;
    var ConnectorIdx = 0;
    var i;
    var ConnStatus = 0;
    var PortStatusGif = "";

    var NodeIdxXMLList = 0;
    var MultiPort = false;

    NoOfNodeConn = TreeArray.GetNoOfNodeConn(IdxOfTree, IdxOfNodeInTree);

    for(i = 0; i < NoOfNodeConn; i++)
    {
        PortPosXInModule = TreeArray.GetNodeConnPortPosX(IdxOfTree, IdxOfNodeInTree, i);
        PortPosYInModule = TreeArray.GetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree, i);

        // portlabel
        PortDivSizeX = NodeCellPortWidth;
        PortDivSizeY = NodeCellPortHeight * PxMatrixCellSize;

        DivObjPortLabel = top.document.createElement("div");
        DivObjPortLabel.style.top  = (NodeYPosPx + (PortPosYInModule * PxMatrixCellSize) + PortLabelObjAdjustmentPxY) + "px";
        DivObjPortLabel.style.width  = (PortDivSizeX - PortLabelObjAdjustmentPxX) + "px";
        DivObjPortLabel.style.height = (PortLabelHeight) + "px";
        DivObjPortLabel.setAttribute("class", "DivTopoNodeConLabel");

        PortCnType = TreeArray.GetNodeConnCnType(IdxOfTree, IdxOfNodeInTree, i);

        // portimage
        DivObjPort = top.document.createElement("div");
        DivObjPort.style.top  = (NodeYPosPx + (PortPosYInModule * PxMatrixCellSize)) + "px";
        DivObjPort.style.left = (NodeXPosPx + (PortPosXInModule * PxMatrixCellSize)) + "px";
        DivObjPort.style.width  = (PortDivSizeX) + "px";
        DivObjPort.style.height = (PortDivSizeY) + "px";

        ImgObjPort = "";
        ImgObjPort = top.document.createElement("img");
        ImgObjPort.style.width = (PortDivSizeX) + "px";
        ImgObjPort.style.height = (PortDivSizeY) + "px";

        DivObjPort.setAttribute("class", "DivTopoNodeCon");

        ConnStatus = TreeArray.GetNodeConnStatus(IdxOfTree, IdxOfNodeInTree, i);

        PortStatusGif = GetPortStatusGif(PortCnType, ConnStatus, PortPosXInModule);

        switch(PortCnType)
        {
            case cn_type_parent:
            {
                ImgObjPort.src = ModuleAtoGifs[PortStatusGif];
                DivObjPortLabel.style.left = (NodeXPosPx + (PortPosXInModule * PxMatrixCellSize) + PortLabelObjAdjustmentPxX) + "px";
                PortLabelAlign = port_label_align_left;
                break;
            }

            case cn_type_child:
            {
                if(0 == PortPosXInModule)
                {
                     // conneciton type child on the left side of node -> current node is part of a line
                    ImgObjPort.src = ModuleAtoGifs[PortStatusGif];
                    DivObjPortLabel.style.left = (NodeXPosPx + (PortPosXInModule * PxMatrixCellSize) + PortLabelObjAdjustmentPxX) + "px";
                    PortLabelAlign = port_label_align_left;
                }
                else
                {
                    // conneciton type child on the right side of node -> current node is a star node
                    ImgObjPort.src = ModuleAtoGifs[PortStatusGif];
                    DivObjPortLabel.style.left = (NodeXPosPx + (PortPosXInModule * PxMatrixCellSize)) + "px";
                    PortLabelAlign = port_label_align_right;
                }

                break;
            }

            case cn_type_not_conn:
            {
                ImgObjPort.src = ModuleAtoGifs[PortStatusGif];
                DivObjPortLabel.style.left = (NodeXPosPx + (PortPosXInModule * PxMatrixCellSize)) + "px";
                PortLabelAlign = port_label_align_right;
                break;
            }

            case cn_type_connector_left:
            {
                ConnectorIdx = ConnectorPortArray.AddNewConnector();
                TreeArray.SetNodeConnectorPortIdx(IdxOfTree, IdxOfNodeInTree, i, ConnectorIdx);
                PortLabelAlign = port_label_align_left;
            }

            case cn_type_ring_left:
            {
                ImgObjPort.src = ModuleAtoGifs[PortStatusGif];
                DivObjPortLabel.style.left = (NodeXPosPx + (PortPosXInModule * PxMatrixCellSize) + PortLabelObjAdjustmentPxX) + "px";
                PortLabelAlign = port_label_align_left;
                break;
            }

            case cn_type_connector_right:
            {
                ConnectorIdx = ConnectorPortArray.AddNewConnector();
                TreeArray.SetNodeConnectorPortIdx(IdxOfTree, IdxOfNodeInTree, i, ConnectorIdx);
                PortLabelAlign = port_label_align_right;
            }

            case cn_type_corrupt:
            case cn_type_ring_right:
            {
                ImgObjPort.src = ModuleAtoGifs[PortStatusGif];
                DivObjPortLabel.style.left = (NodeXPosPx + (PortPosXInModule * PxMatrixCellSize)) + "px";
                PortLabelAlign = port_label_align_right;
                break;
            }
            case cn_type_ring:
            {
                console && console.log && console.log("Connection type error!");
                break;
            }

            default:
            {
                break;
            }
        }

        LLDPPortID = TreeArray.GetNodeConnPortName(IdxOfTree, IdxOfNodeInTree, i);

        CreatePortNameObj(LLDPPortID,
                          DivObjPortLabel,
                          (NodeXPosPx + (PortPosXInModule * PxMatrixCellSize)),
                          (NodeYPosPx + (PortPosYInModule * PxMatrixCellSize)),
                          PortLabelAlign);

        NodeIdxXMLList = TreeArray.GetIdxOfNodeInXMLList(IdxOfTree, IdxOfNodeInTree);

        // check if connection is a multiport connection
        MultiPort = TopoListXMLSave.GetConnMultiPort(NodeIdxXMLList, i);
        if(true == MultiPort)
        {
            // change the font style of DivObjPortLabel italic
            DivObjPortLabel.style.fontStyle = 'italic';
        }

        OutputDOMObj(DivObjPortLabel);

        TopoListXMLSave.SetPortLabelObj(NodeIdxXMLList, i, DivObjPortLabel);

        DivObjPort.appendChild(ImgObjPort);
        OutputDOMObj(DivObjPort);

        // save port obj for auto update
        TopoListXMLSave.SetConnPortObj(NodeIdxXMLList, i, DivObjPort);
    }
}


function PrintNodeConns(IdxOfTree, IdxOfNodeInTree, NodeXPosPx, NodeYPosPx)
{
    var NoOfNodeConn = 0;

    var ParentNodePosX = 0;
    var ParentNodePosY = 0;
    var ChildNodePosX = 0;
    var ChildNodePosY = 0;

    var ParentPortInNodePosX = 0;
    var ParentPortInNodePosY = 0;
    var ChildPortInNodePosX = 0;
    var ChildPortInNodePosY = 0;

    var ParentNodePortPosX = 0;
    var ParentNodePortPosY = 0;
    var ChildNodePortPosX = 0;
    var ChildNodePortPosY = 0;

    var CorrespNodePosX = 0;
    var CorrespPortPosX = 0;

    var ConnSizeX = 0;
    var ConnSizeY = 0;

    var ChildNo = 0;
    var ChildNodeIdx = 0;
    var ParentPortIdx = 0;

    var CorrespNodeIdx = 0;
    var CorrespConnIdx = 0;

    var CorrespConnectorPortIdx = 0;
    var ConnectorPortIdx = 0;
    var ConnectorLabel = "";

    var SourceNodePosX = 0;
    var SourceNodePosY = 0;
    var SourcePortInNodePosX = 0;
    var SourcePortInNodePosY = 0;

    var SourceNodePortPosX = 0;
    var SourceNodePortPosY = 0;

    var DestNodePosX = 0;
    var DestNodePosY = 0;
    var DestPortInNodePosX = 0;
    var DestPortInNodePosY = 0;

    var DestNodePortPosX = 0;
    var DestNodePortPosY = 0;

    var CnType = "";
    var CorrespCnType = "";
    var ConnStatus = 0;

    var ConnPaintObj = 0;
    var NodeIdxXMLList = 0;

    var i;

    // Ports *****************************************************************************

    NodeIdxXMLList = TreeArray.GetIdxOfNodeInXMLList(IdxOfTree, IdxOfNodeInTree);

    NoOfNodeConn = TreeArray.GetNoOfNodeConn(IdxOfTree, IdxOfNodeInTree);

    for(i = 0; i < NoOfNodeConn; i++)
    {
        CnType = TreeArray.GetNodeConnCnType(IdxOfTree, IdxOfNodeInTree, i);

        ConnStatus = TreeArray.GetNodeConnStatus(IdxOfTree, IdxOfNodeInTree, i);

        switch(CnType)
        {
            case cn_type_parent:
            {
                break;
            }

            case cn_type_child:
            {
                ChildNo = TreeArray.GetNodeConnChildNo(IdxOfTree, IdxOfNodeInTree, i);
                ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(IdxOfTree, IdxOfNodeInTree, ChildNo);

                ParentPortIdx = TreeArray.GetNodeConnParentPortIdx(IdxOfTree, ChildNodeIdx);

                ParentNodePosX = TreeArray.GetNodePosX(IdxOfTree, IdxOfNodeInTree);
                ParentNodePosY = TreeArray.GetNodePosY(IdxOfTree, IdxOfNodeInTree);
                ParentPortInNodePosX = TreeArray.GetNodeConnPortPosX(IdxOfTree, IdxOfNodeInTree, i);
                ParentPortInNodePosY = TreeArray.GetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree, i);

                ParentNodePortPosX = ParentNodePosX + ParentPortInNodePosX;
                ParentNodePortPosY = ParentNodePosY + ParentPortInNodePosY;


                ChildNodePosX = TreeArray.GetNodePosX(IdxOfTree, ChildNodeIdx);
                ChildNodePosY = TreeArray.GetNodePosY(IdxOfTree, ChildNodeIdx);

                ChildPortInNodePosX = TreeArray.GetNodeConnPortPosX(IdxOfTree, ChildNodeIdx, ParentPortIdx);
                ChildPortInNodePosY = TreeArray.GetNodeConnPortPosY(IdxOfTree, ChildNodeIdx, ParentPortIdx);

                ChildNodePortPosX = ChildNodePosX + ChildPortInNodePosX;
                ChildNodePortPosY = ChildNodePosY + ChildPortInNodePosY;

                if(ParentNodePortPosY == ChildNodePortPosY)
                {
                    // star node
                    ConnSizeX = ((ChildNodePortPosX - ParentNodePortPosX) - 2) * PxMatrixCellSize;

                    ConnPaintObj = PaintConnection(NodeXPosPx + ((ParentPortInNodePosX + 2) * PxMatrixCellSize),
                        NodeYPosPx + (ParentPortInNodePosY * PxMatrixCellSize) + ConnLineSpacingY,
                        ConnSizeX,
                        ConnLineThickness,
                        ConnStatus);

                    TopoListXMLSave.AddNewConnPaintObj2Conn(NodeIdxXMLList, i, ConnPaintObj);
                }
                else
                {
                     // line child node element
                    ConnSizeY = ((ChildNodePortPosY - ParentNodePortPosY) + 1) * PxMatrixCellSize;

                    // top
                    ConnPaintObj = PaintConnection(NodeXPosPx + ((ParentPortInNodePosX - 1) * PxMatrixCellSize) + ConnLineSpacingX,
                        NodeYPosPx + (ParentPortInNodePosY * PxMatrixCellSize) + ConnLineSpacingY,
                        PxMatrixCellSize - ConnLineSpacingX,
                        ConnLineThickness,
                        ConnStatus);

                    TopoListXMLSave.AddNewConnPaintObj2Conn(NodeIdxXMLList, i, ConnPaintObj);

                    // mid
                    ConnPaintObj = PaintConnection(NodeXPosPx + ((ParentPortInNodePosX - 1) * PxMatrixCellSize) + ConnLineSpacingX,
                        NodeYPosPx + (ParentPortInNodePosY * PxMatrixCellSize) + ConnLineSpacingY,
                        ConnLineThickness,
                        (ConnSizeY - (1 * PxMatrixCellSize) + ConnLineThickness),
                        ConnStatus);

                    TopoListXMLSave.AddNewConnPaintObj2Conn(NodeIdxXMLList, i, ConnPaintObj);

                     // bott
                    ConnPaintObj = PaintConnection(NodeXPosPx + ((ParentPortInNodePosX - 1) * PxMatrixCellSize)  + ConnLineSpacingX,
                        NodeYPosPx + (ParentPortInNodePosY * PxMatrixCellSize) + ((ChildNodePortPosY - ParentNodePortPosY) * PxMatrixCellSize) + ConnLineSpacingY,
                        PxMatrixCellSize - ConnLineSpacingX,
                        ConnLineThickness,
                        ConnStatus);

                    TopoListXMLSave.AddNewConnPaintObj2Conn(NodeIdxXMLList, i, ConnPaintObj);

                }
                break;
            }

            case cn_type_ring_right:
            {

                ParentNodePosX = TreeArray.GetNodePosX(IdxOfTree, IdxOfNodeInTree);
                ParentNodePosY = TreeArray.GetNodePosY(IdxOfTree, IdxOfNodeInTree);
                ParentPortInNodePosX = TreeArray.GetNodeConnPortPosX(IdxOfTree, IdxOfNodeInTree, i);
                ParentPortInNodePosY = TreeArray.GetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree, i);

                ParentNodePortPosX = ParentNodePosX + ParentPortInNodePosX;
                ParentNodePortPosY = ParentNodePosY + ParentPortInNodePosY;

                CorrespNodeIdx = TreeArray.GetRingCnCorrespIdxOfNode(IdxOfTree, IdxOfNodeInTree, i);
                CorrespNodePosX = TreeArray.GetNodePosX(IdxOfTree, CorrespNodeIdx);

                CorrespPortPosX = CorrespNodePosX;

                // star node
                ConnSizeX = ((CorrespPortPosX - ParentNodePortPosX) - 2) * PxMatrixCellSize;

                ConnPaintObj = PaintConnection(NodeXPosPx + ((ParentPortInNodePosX + 2) * PxMatrixCellSize),
                    NodeYPosPx + (ParentPortInNodePosY * PxMatrixCellSize) + ConnLineSpacingY,
                    ConnSizeX,
                    ConnLineThickness,
                    ConnStatus);

                TopoListXMLSave.AddNewConnPaintObj2Conn(NodeIdxXMLList, i, ConnPaintObj);
                break;
            }

            case cn_type_connector_right:
            {
                // horizontal connection
                ConnectorPortIdx = TreeArray.GetNodeConnectorPortIdx(IdxOfTree, IdxOfNodeInTree, i);

                ConnectorLabel = ConnectorPortArray.GetConnectorLabel(ConnectorPortIdx);
                if(BlankString == ConnectorLabel)
                {
                    ConnectorLabel = ConnectorConnsArray.AddNewConnectorLabel();

                    CorrespNodeIdx = TreeArray.GetRingCnCorrespIdxOfNode(IdxOfTree, IdxOfNodeInTree, i);
                    CorrespConnIdx = TreeArray.GetRingCnCorrespIdxOfConn(IdxOfTree, IdxOfNodeInTree, i);
                    CorrespConnectorPortIdx = TreeArray.GetNodeConnectorPortIdx(IdxOfTree, CorrespNodeIdx, CorrespConnIdx);

                    // set connector label of corresponding ports
                    ConnectorPortArray.SetConnectorLabel(ConnectorPortIdx, ConnectorLabel);
                    ConnectorPortArray.SetConnectorLabel(CorrespConnectorPortIdx, ConnectorLabel);

                    CorrespCnType = TreeArray.GetNodeConnCnType(IdxOfTree, CorrespNodeIdx, CorrespConnIdx);

                    SourceNodePosX = TreeArray.GetNodePosX(IdxOfTree, IdxOfNodeInTree);
                    SourceNodePosY = TreeArray.GetNodePosY(IdxOfTree, IdxOfNodeInTree);
                    SourcePortInNodePosX = TreeArray.GetNodeConnPortPosX(IdxOfTree, IdxOfNodeInTree, i);
                    SourcePortInNodePosY = TreeArray.GetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree, i);

                    SourceNodePortPosX = SourceNodePosX + SourcePortInNodePosX;
                    SourceNodePortPosY = SourceNodePosY + SourcePortInNodePosY;

                    DestNodePosX = TreeArray.GetNodePosX(IdxOfTree, CorrespNodeIdx);
                    DestNodePosY = TreeArray.GetNodePosY(IdxOfTree, CorrespNodeIdx);
                    DestPortInNodePosX = TreeArray.GetNodeConnPortPosX(IdxOfTree, CorrespNodeIdx, CorrespConnIdx);
                    DestPortInNodePosY = TreeArray.GetNodeConnPortPosY(IdxOfTree, CorrespNodeIdx, CorrespConnIdx);

                    DestNodePortPosX = DestNodePosX + DestPortInNodePosX;
                    DestNodePortPosY = DestNodePosY + DestPortInNodePosY;

                    // vertical connection

                    /*********************************************************************************************/
                    // top connector line
                    ConnPaintObj = PaintConnection(NodeXPosPx + ((SourcePortInNodePosX + 2) * PxMatrixCellSize),
                        NodeYPosPx + (SourcePortInNodePosY * PxMatrixCellSize) + ConnLineSpacingY,
                        NodeConnectorWidth,
                        ConnLineThickness,
                        ConnStatus);

                    TopoListXMLSave.AddNewConnPaintObj2Conn(NodeIdxXMLList, i, ConnPaintObj);

                    // top connector
                    PaintConnLabel(NodeXPosPx + ((SourcePortInNodePosX + 2) * PxMatrixCellSize) + NodeConnectorWidth,
                        NodeYPosPx + (SourcePortInNodePosY * PxMatrixCellSize) + LabelObjAdjustmentPxY,
                        NodeConnectorLabelWidth,
                        NodeConnectorLabelHeight,
                        ConnectorLabel);

                    if(CnType == CorrespCnType)
                    {
                         /*********************************************************************************************/
                         // bottom connector line
                         ConnPaintObj = PaintConnection(NodeXPosPx + ((SourcePortInNodePosX + 2) * PxMatrixCellSize),
                            NodeYPosPx + (SourcePortInNodePosY * PxMatrixCellSize) + ((DestNodePortPosY - SourceNodePortPosY) * PxMatrixCellSize) + ConnLineSpacingY,
                            NodeConnectorWidth,
                            ConnLineThickness,
                            ConnStatus);

                         TopoListXMLSave.AddNewConnPaintObj2Conn(NodeIdxXMLList, i, ConnPaintObj);

                         // bottom connector
                         PaintConnLabel(NodeXPosPx + ((SourcePortInNodePosX + 2) * PxMatrixCellSize) + NodeConnectorWidth,
                            NodeYPosPx + (SourcePortInNodePosY * PxMatrixCellSize) + ((DestNodePortPosY - SourceNodePortPosY) * PxMatrixCellSize) + LabelObjAdjustmentPxY,
                            NodeConnectorLabelWidth,
                            NodeConnectorLabelHeight,
                            ConnectorLabel);

                     }
                     else
                     {
                         /*********************************************************************************************/
                         // bottom connector line
                         ConnPaintObj = PaintConnection(TopoPaintPxOffsetX + (DestNodePortPosX * PxMatrixCellSize) - NodeConnectorWidth,
                            TopoPaintPxOffsetY + (DestNodePortPosY * PxMatrixCellSize) + ConnLineSpacingY,
                            NodeConnectorWidth,
                            ConnLineThickness,
                            ConnStatus);

                         TopoListXMLSave.AddNewConnPaintObj2Conn(NodeIdxXMLList, i, ConnPaintObj);

                         // bottom connector
                         PaintConnLabel(TopoPaintPxOffsetX + (DestNodePortPosX * PxMatrixCellSize) - NodeConnectorWidth - NodeConnectorLabelWidth,
                            TopoPaintPxOffsetY + (DestNodePortPosY * PxMatrixCellSize) + LabelObjAdjustmentPxY,
                            NodeConnectorLabelWidth,
                            NodeConnectorLabelHeight,
                            ConnectorLabel);
                     }
                }
                break;
            }

            case cn_type_corrupt:
            {
                 SourcePortInNodePosX = TreeArray.GetNodeConnPortPosX(IdxOfTree, IdxOfNodeInTree, i);
                 SourcePortInNodePosY = TreeArray.GetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree, i);

                 // connector line
                 ConnPaintObj = PaintConnection(NodeXPosPx + ((SourcePortInNodePosX + 2) * PxMatrixCellSize),
                    NodeYPosPx + (SourcePortInNodePosY * PxMatrixCellSize) + ConnLineSpacingY,
                    NodeConnectorWidth,
                    ConnLineThickness,
                    ConnStatus);

                 TopoListXMLSave.AddNewConnPaintObj2Conn(NodeIdxXMLList, i, ConnPaintObj);
                 // connector
                 PaintConnLabel(NodeXPosPx + ((SourcePortInNodePosX + 2) * PxMatrixCellSize) + NodeConnectorWidth,
                    NodeYPosPx + (SourcePortInNodePosY * PxMatrixCellSize) + LabelObjAdjustmentPxY,
                    NodeConnectorLabelWidth,
                    NodeConnectorLabelHeight,
                    "???");

                break;
            }

            case cn_type_not_conn:
            {
                // connection has no partner
                break;
            }

            case cn_type_connector_left:
            {
                // allready painted when corresponding right connector was painted
                break;
            }

            case cn_type_ring_left:
            {
                // allready painted when corresponding connection of right port was painted
                break;
            }

            case cn_type_ring:
            {
                console && console.log && console.log("Connection type error!");
                break;
            }

            default:
            {
                console && console.log && console.log("Connection type error!");
                break;
            }
        }
    }
}


function GetConnStatusColor(ConnStatus)
{
    var ConnStatusColor = "";

    if(ConnStatusConnectionOk == (ConnStatus & ConnStatusConnectionOk))
    {
        ConnStatusColor = "#006400";
    }
    else if(ConnStatusConnectionError == (ConnStatus & ConnStatusConnectionError))
    {
        ConnStatusColor = "#FF0000";
    }
    else if(ConnStatusConnectionNoDiag == (ConnStatus & ConnStatusConnectionNoDiag))
    {
        ConnStatusColor = "#FCFF00";
    }
    else
    {
        console && console.log && console.log("ERROR: Unknown horizontal connection status!");
    }

    return ConnStatusColor;
}


function PaintConnection(PosXPx, PosYPx, SizeXPx, SizeYPx, ConnStatus)
{
    var DivObjConnection = "";

    var ConnStatusColor = "";

    DivObjConnection = top.document.createElement("div");
    DivObjConnection.style.left = (PosXPx) + "px";
    DivObjConnection.style.top  = (PosYPx) + "px";
    DivObjConnection.style.width  = (SizeXPx) + "px";
    DivObjConnection.style.height = (SizeYPx) + "px";
    DivObjConnection.setAttribute("class", "DivTopoWire");

    ConnStatusColor = GetConnStatusColor(ConnStatus);

    DivObjConnection.style.backgroundColor = ConnStatusColor;

    OutputDOMObj(DivObjConnection);

    return DivObjConnection;
}


function PaintConnLabel(PosXPx, PosYPx, SizeXPx, SizeYPx, ConnLabel)
{
    var DivObjLabel = "";
    var TxtObjLabel = "";
    var ImgObjLabel = "";
    var DivObjLabelImg = "";
    TxtObjLabel = top.document.createTextNode(ConnLabel);

    /***********************************************************/
    DivObjLabel = top.document.createElement("div");
    DivObjLabel.style.left = (PosXPx) + "px";
    DivObjLabel.style.top  = (PosYPx) + "px";
    DivObjLabel.style.width  = (SizeXPx) + "px";
    DivObjLabel.style.height = (SizeYPx) + "px";

    DivObjLabel.appendChild(TxtObjLabel);
    DivObjLabel.setAttribute("class", "DivTopoConnectorLabel");


    ImgObjLabel = top.document.createElement("img");
    ImgObjLabel.width = (SizeXPx) + "px";
    ImgObjLabel.height = (SizeYPx) + "px";
    ImgObjLabel.src = ModuleAtoGifs[connector];

    DivObjLabelImg = top.document.createElement("div");
    DivObjLabelImg.style.left = (PosXPx) + "px";
    DivObjLabelImg.style.top  = (PosYPx) + "px";
    DivObjLabelImg.style.width  = (SizeXPx) + "px";
    DivObjLabelImg.style.height = (SizeYPx) + "px";

    DivObjLabelImg.appendChild(ImgObjLabel);
    DivObjLabelImg.setAttribute("class", "DivTopoConnector");
    /***********************************************************/

    OutputDOMObj(DivObjLabelImg);
    OutputDOMObj(DivObjLabel);
}

function TreeNode2OutputDiv(IdxOfTree, IdxOfNodeInTree, PxStartX, PxStartY)
{
    var TableMatrixX = 0;
    var TableMatrixY = 0;
    var DivXPos = 0;
    var DivYPos = 0;
    var ChildNodeIdx = 0;
    var i;
    var NoOfChildNodes = TreeArray.GetNoOfChildNodes(IdxOfTree, IdxOfNodeInTree);

    TableMatrixX = TreeArray.GetNodePosX(IdxOfTree, IdxOfNodeInTree);
    TableMatrixY = TreeArray.GetNodePosY(IdxOfTree, IdxOfNodeInTree);

    PrintNodeDiv(IdxOfTree, IdxOfNodeInTree, (PxStartX + (TableMatrixX * PxMatrixCellSize)), (PxStartY + (TableMatrixY * PxMatrixCellSize)));
    PrintNodePorts(IdxOfTree, IdxOfNodeInTree, (PxStartX + (TableMatrixX * PxMatrixCellSize)), (PxStartY + (TableMatrixY * PxMatrixCellSize)));

    if(NoOfChildNodes != 0)
    {
        for(i = 0; i < NoOfChildNodes; i++)
       {
          ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(IdxOfTree, IdxOfNodeInTree, i);

          TreeNode2OutputDiv(IdxOfTree, ChildNodeIdx, PxStartX, PxStartY);
       }
    }
}

function TreeNode2OutputDivConnections(IdxOfTree, IdxOfNodeInTree, PxStartX, PxStartY)
{
    var TableMatrixX = 0;
    var TableMatrixY = 0;
    var DivXPos = 0;
    var DivYPos = 0;
    var ChildNodeIdx = 0;
    var i;
    var NoOfChildNodes = TreeArray.GetNoOfChildNodes(IdxOfTree, IdxOfNodeInTree);

    TableMatrixX = TreeArray.GetNodePosX(IdxOfTree, IdxOfNodeInTree);
    TableMatrixY = TreeArray.GetNodePosY(IdxOfTree, IdxOfNodeInTree);

    PrintNodeConns(IdxOfTree, IdxOfNodeInTree, (PxStartX + (TableMatrixX * PxMatrixCellSize)), (PxStartY + (TableMatrixY * PxMatrixCellSize)));

    if(NoOfChildNodes != 0)
    {
        for(i = 0; i < NoOfChildNodes; i++)
        {
            ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(IdxOfTree, IdxOfNodeInTree, i);

            TreeNode2OutputDivConnections(IdxOfTree, ChildNodeIdx, PxStartX, PxStartY);
       }
    }
}

function NodeCropYSize(IdxOfTree, IdxOfNodeInTree)
{
    var NoOfChildNodes = 0;
    var ChildNodeIdx   = 0;
    var NodeConnCount = 0;
    var NodeSizeY = 0;
    var NodeSizeYCrop = 0;
    var PortPosY = 0;
    var PortPosYMax = 0;
    var i;

    NodeConnCount = TreeArray.GetNoOfNodeConn(IdxOfTree, IdxOfNodeInTree);

    for(i = 0; i < NodeConnCount; i++)
    {
        PortPosY = TreeArray.GetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree,i);
        if(PortPosYMax < PortPosY) PortPosYMax = PortPosY;
    }

    NodeSizeYCrop = PortPosYMax + NodeCellHeadHeight + NodeCellBottHeight;

    TreeArray.SetNodeSizeYCrop(IdxOfTree, IdxOfNodeInTree, NodeSizeYCrop);

    NoOfChildNodes = TreeArray.GetNoOfChildNodes(IdxOfTree, IdxOfNodeInTree);

    if(NoOfChildNodes != 0)
    {
        for(i = 0; i < NoOfChildNodes; i++)
        {
            ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(IdxOfTree, IdxOfNodeInTree, i);

            NodeCropYSize(IdxOfTree, ChildNodeIdx);
        }
    }
}


function CalcTreeTableMatrixSize(IdxOfTree, IdxOfNodeInTree)
{
    var TreeMatrixSizeLoc = new MatrixSizeNew();
    var NoOfChildNodes = 0;
    var ChildNodeIdx   = 0;
    var NodeVertLayer = 0;
    var NodeMatrixSizeX = 0;
    var NodeMatrixSizeY = 0;
    var i;

    TreeMatrixSizeLoc = TreeMatrixSize.GetMatrixSize(IdxOfTree);

    NodeVertLayer = TreeArray.GetNodeVertLayer(IdxOfTree, IdxOfNodeInTree);
    NodeMatrixSizeX = (((NodeVertLayer + 1) * NodeMatrixXSize) + (NodeVertLayer * MatrixModuleSpacingX));
    NodeMatrixSizeY = TreeArray.GetNodeSizeY(IdxOfTree, IdxOfNodeInTree);

    if(TreeMatrixSizeLoc.SizeX < NodeMatrixSizeX) TreeMatrixSizeLoc.SizeX = NodeMatrixSizeX;
    if(TreeMatrixSizeLoc.SizeY < NodeMatrixSizeY) TreeMatrixSizeLoc.SizeY = NodeMatrixSizeY;

    TreeMatrixSize.SetMatrixSize(IdxOfTree,TreeMatrixSizeLoc);

    NoOfChildNodes = TreeArray.GetNoOfChildNodes(IdxOfTree, IdxOfNodeInTree);
    if(NoOfChildNodes != 0)
    {
        for(i = 0; i < NoOfChildNodes; i++)
        {
            ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(IdxOfTree, IdxOfNodeInTree, i);

            CalcTreeTableMatrixSize(IdxOfTree, ChildNodeIdx);
        }
    }
}

function NodeCalcNodePosition(IdxOfTree, IdxOfNodeInTree, MatrixOffsetX, MatrixOffsetY)
{
    var PosX = MatrixOffsetX;
    var PosY = MatrixOffsetY;
    var PosYSum = 0;
    var MSizeX, MSizeY = 0;
    var MLineSizeY = 0;
    var NoOfChildNodes = 0;
    var ChildNodeIdx = 0;
    var i;

    TreeArray.SetNodePosX(IdxOfTree, IdxOfNodeInTree, PosX);
    TreeArray.SetNodePosY(IdxOfTree, IdxOfNodeInTree, PosY);

    NoOfChildNodes = TreeArray.GetNoOfChildNodes(IdxOfTree, IdxOfNodeInTree);

    if(IdxOfNodeInTree == TreeArray.GetParentIdxOfNode(IdxOfTree, IdxOfNodeInTree))
    {
        MSizeX = TreeArray.GetNodeSizeX(IdxOfTree, IdxOfNodeInTree);

        PosX += MSizeX + MatrixModuleSpacingX;

        for(i = 0; i < NoOfChildNodes; i++)
        {
            ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(IdxOfTree, IdxOfNodeInTree, i);

            NodeCalcNodePosition(IdxOfTree, ChildNodeIdx, PosX, PosY);

            MSizeY = TreeArray.GetNodeSizeY(IdxOfTree, ChildNodeIdx);

            MLineSizeY = TreeArray.GetLineSize(IdxOfTree, ChildNodeIdx);

            if(0 != MLineSizeY) MSizeY = MLineSizeY;

            PosY += (MSizeY + MatrixModuleSpacingY);
        }
        
        return PosYSum;
    }
    else
    {
        if(NoOfChildNodes == 0)
        {

            MSizeY = TreeArray.GetNodeSizeY(IdxOfTree, IdxOfNodeInTree);
            return (MSizeY);
        }
        else if(NoOfChildNodes == 1)
        {
            ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(IdxOfTree, IdxOfNodeInTree, 0);

            PosX = MatrixOffsetX;

            MSizeY = TreeArray.GetNodeSizeY(IdxOfTree, IdxOfNodeInTree);
            PosY += MSizeY + MatrixModuleSpacingY;

            MSizeY = NodeCalcNodePosition(IdxOfTree, ChildNodeIdx, PosX, PosY);

            return(PosY + MSizeY);
        }
        else
        {
            MSizeX = TreeArray.GetNodeSizeX(IdxOfTree, IdxOfNodeInTree);
            PosX += MSizeX + MatrixModuleSpacingX;

            for(i = 0; i < NoOfChildNodes; i++)
            {
                ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(IdxOfTree, IdxOfNodeInTree, i);

                NodeCalcNodePosition(IdxOfTree, ChildNodeIdx, PosX, PosY);

                MSizeY = TreeArray.GetNodeSizeY(IdxOfTree, ChildNodeIdx);

                MLineSizeY = TreeArray.GetLineSize(IdxOfTree, ChildNodeIdx);

                if(0 != MLineSizeY) MSizeY = MLineSizeY;

                PosYSum += MSizeY;

                //vbeim letzten Childelement wird kein YSpacing addiert, da Ende
                if(i != (NoOfChildNodes - 1))
                {
                    PosYSum += MatrixModuleSpacingY;
                }

                PosY += (MSizeY + MatrixModuleSpacingY);
            }

            return PosYSum;
        }
    }// end of if CPU
}

function NodeCalcRingPortPosition(IdxOfTree, IdxOfNodeInTree)
{
    var ChildIdx = 0;
    var ChildNodeIdx = 0;
    var NodeConnCount = 0;
    var CorrespNodeIdx = 0;
    var CorrespConnIdx = 0;
    var CorrespPortPosY = 0;
    var CorrespNodePosY = 0;
    var NodeRingPortPosX = 0;
    var ParentNodePosY = 0;
    var CnType = "";
    var i;

    NodeConnCount = TreeArray.GetNoOfNodeConn(IdxOfTree, IdxOfNodeInTree);
    for(i = 0; i < NodeConnCount; i++)
    {
        CnType = TreeArray.GetNodeConnCnType(IdxOfTree, IdxOfNodeInTree, i);

        if(CnType == cn_type_ring_right)
        {
            ParentNodePosY = TreeArray.GetNodePosY(IdxOfTree, IdxOfNodeInTree);

            CorrespNodeIdx = TreeArray.GetRingCnCorrespIdxOfNode(IdxOfTree, IdxOfNodeInTree, i);
            CorrespConnIdx = TreeArray.GetRingCnCorrespIdxOfConn(IdxOfTree, IdxOfNodeInTree, i);

            CorrespNodePosY = TreeArray.GetNodePosY(IdxOfTree, CorrespNodeIdx);

            CorrespPortPosY = TreeArray.GetNodeConnPortPosY(IdxOfTree, CorrespNodeIdx, CorrespConnIdx);

            CorrespPortPosY += (CorrespNodePosY - ParentNodePosY);

            TreeArray.SetNodeConnPortPosX(IdxOfTree, IdxOfNodeInTree, i, NodeRingPortPosX + 2);
            TreeArray.SetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree, i, CorrespPortPosY);
        }

        if(CnType == cn_type_child)
        {
            ChildIdx = TreeArray.GetNodeConnChildNo(IdxOfTree, IdxOfNodeInTree, i);

            ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(IdxOfTree, IdxOfNodeInTree, ChildIdx);

            NodeCalcRingPortPosition(IdxOfTree, ChildNodeIdx);
        }
    }
}


function NodeCalcPortPosition(IdxOfTree, IdxOfNodeInTree)
{
    var NoOfChildNodes = 0;
    var ChildIdx = 0;
    var ChildNodeIdx = 0;
    var ChildNodeSize = 0;
    var ChildNodeLineSize = 0;
    var ChildPortPosY = 0;
    var NodeConnCount = 0;
    var NodeType = 0;
    var NodeBodyLeftElementCnt  = 0;
    var NodeBodyRightElementCnt = 0;
    var NodeBodyElementCnt = 0;
    var NodePortYOffset = 1;
    var CnType = "";
    var i,j;

    NoOfChildNodes = TreeArray.GetNoOfChildNodes(IdxOfTree, IdxOfNodeInTree);

    if(IdxOfNodeInTree == TreeArray.GetParentIdxOfNode(IdxOfTree, IdxOfNodeInTree))
    {
        // node of the first horizontal layer
        NodeConnCount = TreeArray.GetNoOfNodeConn(IdxOfTree, IdxOfNodeInTree);

        NodeType = TreeArray.GetNodeType(IdxOfTree, IdxOfNodeInTree);

        NodeBodyLeftElementCnt  = NodeBody[NodeType][node_body_left_side].length;
        NodeBodyRightElementCnt = NodeBody[NodeType][node_body_right_side].length;

        NodeBodyElementCnt = 0;

        for(j = 0; j < NodeConnCount; j++)
        {
            CnType = TreeArray.GetNodeConnCnType(IdxOfTree, IdxOfNodeInTree, j);

            if(CnType == cn_type_child)
            {
                TreeArray.SetNodeConnPortPosX(IdxOfTree, IdxOfNodeInTree, j, NodePortXOffset + 2);
                TreeArray.SetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree, j, (NodePortYOffset + ChildPortPosY));

                ChildIdx = TreeArray.GetNodeConnChildNo(IdxOfTree, IdxOfNodeInTree, j);

                ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(IdxOfTree, IdxOfNodeInTree, ChildIdx);

                ChildNodeSize = TreeArray.GetNodeSizeY(IdxOfTree, ChildNodeIdx);

                ChildNodeLineSize = TreeArray.GetLineSize(IdxOfTree, ChildNodeIdx);

                if(0 != ChildNodeLineSize) ChildNodeSize = ChildNodeLineSize;

                ChildPortPosY = ChildPortPosY + ChildNodeSize + MatrixModuleSpacingY;

                NodeCalcPortPosition(IdxOfTree, ChildNodeIdx);
            }
        }

        NodeBodyElementCnt = 0;

        NodePortYOffset = ChildPortPosY - ChildNodeSize + 1;

        for(j = 0; j < NodeConnCount; j++)
        {
            CnType = TreeArray.GetNodeConnCnType(IdxOfTree, IdxOfNodeInTree, j);

            if((CnType == cn_type_not_conn) ||
               (CnType == cn_type_corrupt))
            {
                TreeArray.SetNodeConnPortPosX(IdxOfTree, IdxOfNodeInTree, j, NodePortXOffset + 2);
                TreeArray.SetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree, j, (NodePortYOffset + NodeBodyElementCnt));
                NodeBodyElementCnt++;
            }
        }
    }
    else
    {

        if((NoOfChildNodes == 0) || (NoOfChildNodes == 1))
        {
            NodeConnCount = TreeArray.GetNoOfNodeConn(IdxOfTree, IdxOfNodeInTree);

            NodeType = TreeArray.GetNodeType(IdxOfTree, IdxOfNodeInTree);

            NodeBodyLeftElementCnt  = NodeBody[NodeType][node_body_left_side].length;
            NodeBodyRightElementCnt = NodeBody[NodeType][node_body_right_side].length;

            NodeBodyElementCnt = 0;

            // left side of module
            for(i = 0; i < NodeBodyLeftElementCnt; i++)
            {
                for(j = 0; j < NodeConnCount; j++)
                {
                    CnType = TreeArray.GetNodeConnCnType(IdxOfTree, IdxOfNodeInTree, j);

                    if(CnType == NodeBody[NodeType][node_body_left_side][i])
                    {
                        TreeArray.SetNodeConnPortPosX(IdxOfTree, IdxOfNodeInTree, j, NodePortXOffset);
                        TreeArray.SetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree, j, (NodePortYOffset + NodeBodyElementCnt));
                        NodeBodyElementCnt++;
                    }
                }
            }

            NodeBodyElementCnt = 0;

            // right side of module
            for(i = 0; i < NodeBodyRightElementCnt; i++)
            {
                for(j = 0; j < NodeConnCount; j++)
                {
                    CnType = TreeArray.GetNodeConnCnType(IdxOfTree, IdxOfNodeInTree, j);

                    if(CnType == NodeBody[NodeType][node_body_right_side][i])
                    {
                        TreeArray.SetNodeConnPortPosX(IdxOfTree, IdxOfNodeInTree, j, NodePortXOffset + 2);
                        TreeArray.SetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree, j, (NodePortYOffset + NodeBodyElementCnt));
                        NodeBodyElementCnt++;
                    }
                }
            }

            if(NoOfChildNodes == 1)
            {
                 ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(IdxOfTree, IdxOfNodeInTree, 0);
                 NodeCalcPortPosition(IdxOfTree, ChildNodeIdx);
            }
        }
        else
        { // star node

            // calc left side of a star node
            NodeConnCount = TreeArray.GetNoOfNodeConn(IdxOfTree, IdxOfNodeInTree);

            NodeType = TreeArray.GetNodeType(IdxOfTree, IdxOfNodeInTree);

            NodeBodyLeftElementCnt  = NodeBody[NodeType][node_body_left_side].length;
            NodeBodyRightElementCnt = NodeBody[NodeType][node_body_right_side].length;

            NodeBodyElementCnt = 0;

            for(i = 0; i < NodeBodyLeftElementCnt; i++)
            {
                for(j = 0; j < NodeConnCount; j++)
                {
                    CnType = TreeArray.GetNodeConnCnType(IdxOfTree, IdxOfNodeInTree, j);

                    if(CnType == NodeBody[NodeType][node_body_left_side][i])
                    {
                        TreeArray.SetNodeConnPortPosX(IdxOfTree, IdxOfNodeInTree, j, NodePortXOffset);
                        TreeArray.SetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree, j, (NodePortYOffset + NodeBodyElementCnt));
                        NodeBodyElementCnt++;
                    }
                }
            }
            // calc right side of a star node

            for(j = 0; j < NodeConnCount; j++)
            {
                CnType = TreeArray.GetNodeConnCnType(IdxOfTree, IdxOfNodeInTree, j);
                if(CnType == cn_type_child)
                {

                    TreeArray.SetNodeConnPortPosX(IdxOfTree, IdxOfNodeInTree, j, NodePortXOffset + 2);
                    TreeArray.SetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree, j, (NodePortYOffset + ChildPortPosY));

                    ChildIdx = TreeArray.GetNodeConnChildNo(IdxOfTree, IdxOfNodeInTree, j);

                    ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(IdxOfTree, IdxOfNodeInTree, ChildIdx);

                    ChildNodeSize = TreeArray.GetNodeSizeY(IdxOfTree, ChildNodeIdx);

                    ChildNodeLineSize = TreeArray.GetLineSize(IdxOfTree, ChildNodeIdx);

                    if(0 != ChildNodeLineSize) ChildNodeSize = ChildNodeLineSize;

                    ChildPortPosY = ChildPortPosY + ChildNodeSize + MatrixModuleSpacingY;
                    // ports der child-node bestimmen
                    NodeCalcPortPosition(IdxOfTree, ChildNodeIdx);
                }
            }

            NodeBodyElementCnt = 0;
            NodePortYOffset = ChildPortPosY - ChildNodeSize + 1;
            for(i = 2; i < NodeBodyLeftElementCnt; i++)
            {
                for(j = 0; j < NodeConnCount; j++)
                {
                    CnType = TreeArray.GetNodeConnCnType(IdxOfTree, IdxOfNodeInTree, j);

                    if((CnType == cn_type_not_conn) ||
                       (CnType == cn_type_corrupt))
                    {
                        TreeArray.SetNodeConnPortPosX(IdxOfTree, IdxOfNodeInTree, j, NodePortXOffset + 2);
                        TreeArray.SetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree, j, (NodePortYOffset + NodeBodyElementCnt));
                        NodeBodyElementCnt++;
                    }
                }
            }
        }
    }
}


function NodeConnectorRightAndUnusedPortPosition(IdxOfTree, IdxOfNodeInTree)
{
    var NodeType = 0;
    var NodeConnCount = 0;
    var NoOfChildNodes = 0;
    var ChildNodeIdx = 0;
    var PortRightPosY = 0;
    var PortRightPosYMax = 0;
    var NodeBodyRightElementCnt = 0;
    var NodeBodyElementCnt = 0;
    var CnType = "";
    var i,j;

    NodeType = TreeArray.GetNodeType(IdxOfTree, IdxOfNodeInTree);
    if(NodeType == node_type_star)
    {
        NodeConnCount = TreeArray.GetNoOfNodeConn(IdxOfTree, IdxOfNodeInTree);
        for(i = 0; i < NodeConnCount; i++)
        {
            CnType = TreeArray.GetNodeConnCnType(IdxOfTree, IdxOfNodeInTree, i);

            if((CnType == cn_type_child) ||
               (CnType == cn_type_ring_right))
            {
              PortRightPosY = TreeArray.GetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree,i);
              if(PortRightPosYMax < PortRightPosY) PortRightPosYMax = PortRightPosY;
            }
        }

        PortRightPosYMax += 1; // next free port position

        NodeBodyRightElementCnt = NodeBody[NodeType][node_body_right_side].length;

        NodeBodyElementCnt = 0;

        // right side of module
        for(i = 2; i < NodeBodyRightElementCnt; i++)
        {
            for(j = 0; j < NodeConnCount; j++)
            {
                CnType = TreeArray.GetNodeConnCnType(IdxOfTree, IdxOfNodeInTree, j);

                if(CnType == NodeBody[NodeType][node_body_right_side][i])
                {
                    TreeArray.SetNodeConnPortPosX(IdxOfTree, IdxOfNodeInTree, j, NodePortXOffset + 2);
                    TreeArray.SetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree, j, (PortRightPosYMax + NodeBodyElementCnt));
                    NodeBodyElementCnt++;
                }
            }
        }
    }

    NoOfChildNodes = TreeArray.GetNoOfChildNodes(IdxOfTree, IdxOfNodeInTree);
    if(NoOfChildNodes != 0)
    {
        for(i = 0; i < NoOfChildNodes; i++)
        {
            ChildNodeIdx = TreeArray.GetIdxTreeNodeByChildIdx(IdxOfTree, IdxOfNodeInTree, i);

            NodeConnectorRightAndUnusedPortPosition(IdxOfTree, ChildNodeIdx);
        }
    }
}

function NodeNoStarCalcPortPosition(IdxOfTree, IdxOfNodeInTree)
{
    var NodeConnCount = 0;
    var NodeBodyLeftElementCnt = 0;
    var NodeBodyRightElementCnt = 0;
    var NodeBodyElementCnt = 0;
    var NodePortYOffset = 1;
    var NodeType = 0;
    var CnType = "";
    var i,j;

    NodeConnCount = TreeArray.GetNoOfNodeConn(IdxOfTree, IdxOfNodeInTree);

    NodeType = TreeArray.GetNodeType(IdxOfTree, IdxOfNodeInTree);

    NodeBodyLeftElementCnt  = NodeBody[NodeType][node_body_left_side].length;
    NodeBodyRightElementCnt = NodeBody[NodeType][node_body_right_side].length;

    NodeBodyElementCnt = 0;

    // left side of module
    for(i = 0; i < NodeBodyLeftElementCnt; i++)
    {
        for(j = 0; j < NodeConnCount; j++)
        {
            CnType = TreeArray.GetNodeConnCnType(IdxOfTree, IdxOfNodeInTree, j);
            if(CnType == NodeBody[NodeType][node_body_left_side][i])
            {
                TreeArray.SetNodeConnPortPosX(IdxOfTree, IdxOfNodeInTree, j, NodePortXOffset);
                TreeArray.SetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree, j, (NodePortYOffset + NodeBodyElementCnt));
                NodeBodyElementCnt++;
            }
        }
    }

    NodeBodyElementCnt = 0;

    // right side of module
    for(i = 0; i < NodeBodyRightElementCnt; i++)
    {
        for(j = 0; j < NodeConnCount; j++)
        {
            CnType = TreeArray.GetNodeConnCnType(IdxOfTree, IdxOfNodeInTree, j);

            if(CnType == NodeBody[NodeType][node_body_right_side][i])
            {
                TreeArray.SetNodeConnPortPosX(IdxOfTree, IdxOfNodeInTree, j, NodePortXOffset + 2);
                TreeArray.SetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree, j, (NodePortYOffset + NodeBodyElementCnt));
                NodeBodyElementCnt++;
            }
        }
    }
}

function NodeStarLeftSidePortPosition(IdxOfTree, IdxOfNodeInTree)
{
    var NodeConnCount = 0;
    var NodeType = 0;
    var NodeBodyLeftElementCnt = 0;
    var NodeBodyElementCnt = 0;
    var NodePortYOffset = 1;
    var CnType = "";
    var i,j;

    NodeConnCount = TreeArray.GetNoOfNodeConn(IdxOfTree, IdxOfNodeInTree);

    NodeType = TreeArray.GetNodeType(IdxOfTree, IdxOfNodeInTree);

    NodeBodyLeftElementCnt  = NodeBody[NodeType][node_body_left_side].length;

    NodeBodyElementCnt = 0;

    // left side of module
    for(i = 0; i < NodeBodyLeftElementCnt; i++)
    {
        for(j = 0; j < NodeConnCount; j++)
        {
            CnType = TreeArray.GetNodeConnCnType(IdxOfTree, IdxOfNodeInTree, j);

            if(CnType == NodeBody[NodeType][node_body_left_side][i])
            {
                TreeArray.SetNodeConnPortPosX(IdxOfTree, IdxOfNodeInTree, j, NodePortXOffset);
                TreeArray.SetNodeConnPortPosY(IdxOfTree, IdxOfNodeInTree, j, (NodePortYOffset + NodeBodyElementCnt));
                NodeBodyElementCnt++;
            }
        }
    }
}
