(function () {
  MakePopup = function (opts) {
    // remove any existing popups from the DOM
    $("#popup-root", parent.document).remove();

    // create a new popup structure in the DOM
    var html = '<div id="popup-root"><div class="blocker"></div><div class="window"><div class="header"></div><table><tr><td class="icon"></td><td class="content"></td></tr></table><div class="buttons"></div></div></div>';
    $(parent.document.body).append(html);
    var popup_root = $("#popup-root", parent.document);

    // hide the page (fixes TAB ordering)
    var page = $('#page').add('#server_frame').hide();

    $(".header", popup_root).text(opts.title || '');
    $(".content", popup_root).text(opts.prompt || '');

    var buttons_div = $(".buttons", popup_root);
    $.each(opts.buttons, function(k, button){ 
      var b = $("<button>", {
        text: button.title,
        tabindex: opts.buttons.length - k,
        on: {
          click: function () {
            popup_root.remove();
            page.show();
            button.callback && button.callback();           
          }
        }
      });
      buttons_div.append(b);
    });
    $("button:last", buttons_div).focus();
  };
})();



