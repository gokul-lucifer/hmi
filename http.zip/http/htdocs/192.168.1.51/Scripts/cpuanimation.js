// Available LEDs
var POWER_LED_ID       = "LED_POWER";
var RUNSTOP_LED_ID     = "LED_RUNSTOP";
var ERROR_LED_ID       = "LED_ERROR";
var MAINTENANCE_LED_ID = "LED_MAINTENANCE";
var X1LK1_LED_ID       = "LED_X1LK1";
var X1LK2_LED_ID       = "LED_X1LK2";
var X2LK1_LED_ID       = "LED_X2LK1";

// Other elements
var DISPLAY_ID = "DISPLAY_STATUS";
var SWITCH_ID = "SWITCH";

// Available CSS-classes
var CPU_IN_STARTUP = "CPUInSTARTUP";
var CPU_IN_RUN = "CPUInRUN";
var CPU_IN_STOP = "CPUInSTOP";
var CPU_IN_MAINTENANCE = "CPUInMAINTENANCE";
var CPU_IN_OTHERSTATE = "CPUInOTHERSTATE";
var CPU_IN_ERROR = "CPUInERROR";
var CPU_IN_HOLD = "CPUInHOLD";
var CPU_POWERON = "POWERON";
var LED_DISABLED = "LED_DISABLED";
var IE_COMPAT_BLINK = "IE_COMPAT_BLINK";
    
function displayCPUState(actualState, switchState, x1lk1, x1lk2, x2lk1)
{    
    switch(actualState)
    {
        case "RUN":            
            changeStyle(DISPLAY_ID, CPU_IN_RUN);
            break;
        case "STOP":
            changeStyle(DISPLAY_ID, CPU_IN_STOP);
            break;
        case "STARTUP":
            changeStyle(DISPLAY_ID, CPU_IN_STARTUP);
            break;
        case "MAINTENENCE":
            //changeStyle(MAINTENANCE_LED_ID, CPU_IN_MAINTENANCE);
            break;
        case "HOLD":
            changeStyle(DISPLAY_ID, CPU_IN_HOLD);
            break;
        default:
            changeStyle(DISPLAY_ID, CPU_IN_OTHERSTATE);
    }
    
    if (switchState == "RUN")
    {
        changeStyle(SWITCH_ID, CPU_IN_RUN);
    }
    else
    {
        changeStyle(SWITCH_ID, CPU_IN_STOP);
    }
    
    // X1/X2 LEDs
    changeStyle(X1LK1_LED_ID, x1lk1);
    changeStyle(X1LK2_LED_ID, x1lk2);
    changeStyle(X2LK1_LED_ID, x2lk1);
}

function changeStyle(id, className)
{
    var element = document.getElementById(id);
    if (element != null)
    {
        element.className = className;
    }
    else
    {
        console.log("Error: Element not found with id:" + id);
    }
}