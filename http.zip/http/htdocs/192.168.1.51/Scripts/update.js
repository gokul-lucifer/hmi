// call subscribed functions after update complete
//
// Init - initialize update of the data on the page
// SubscribeFunction - to add function that will be called after update complete
// UnsubscribeFunction - to remove the function from subscribe list (the function will be also remover automaticaly if it not exist any more)
// CallSubscribeFunctions - called all subscribed functions (before call check functions for existing)
// ---------------------------------------------------------------------------------
(function (window, undefined) {
	var UpdatePageDataManager =(function(){
		// ---------------------------------------------------------------------------------
		// private properties
		// ---------------------------------------------------------------------------------
		var pTimer = null;
		
		// list of callback functions on update complete
		var subscribeFunctions_onUpdateComplete = [];
		
		// ---------------------------------------------------------------------------------
		// private functions
		// ---------------------------------------------------------------------------------
		
		// ---------------------------------------------------------------------------------
		// public properties and functions
		// ---------------------------------------------------------------------------------
		return{
			Init: function(){
				// wait for readyState is complete
				if (document.readyState !== "complete") {
					if(pTimer){
						clearTimeout(pTimer);
					}
					pTimer = setTimeout("UpdatePageDataManager.Init()", 100);
					return false;
				}
				
				if($("#dynamic_link").length > 0){
					// what page are we in
					if(window == top.server_frame){
						inUpdatePage = 1;
					} 
					
					if((url_to_update.search(/PriNav=Topo&SecNav=TopoGraph/) != -1) || (url_to_update.search(/PriNav=Topo&SecNav=TopoBrief/) != -1)){
						// topo_update_behandlung
						update_on();
					}
					else{
						//switch to automatic update or call update
						if(!inUpdatePage && (url_to_update != '0')){
							createFrame();
						}
						if(!inUpdatePage && (url_to_update != '0')){
							update_on();
						}
						if(inUpdatePage && (url_to_update != '0')){
							do_update();
						}
						if(!inUpdatePage){
							update_leds();
						}
					}
				}
			},
			
			// ---------------------------------------------------------------------------------
            SubscribeFunction: function (func) {
				for (var i = 0, length = subscribeFunctions_onUpdateComplete.length; i < length; i++) {
					if (subscribeFunctions_onUpdateComplete[i] === func) {
						return true;
					}
				}
				subscribeFunctions_onUpdateComplete.push(func);
                return true;
            },

            // ---------------------------------------------------------------------------------
            UnsubscribeFunction: function (func) {
				for (var i = 0, length = subscribeFunctions_onUpdateComplete.length; i < length; i++) {
					if (subscribeFunctions_onUpdateComplete[i] === func) {
						// delete function from array
						subscribeFunctions_onUpdateComplete.splice(i, 1);
						break;
					}
				}
                return true;
            },
			
			// ---------------------------------------------------------------------------------
			CallSubscribeFunctions: function() {
				// important! beginn to call of functions from end
				for (var i = subscribeFunctions_onUpdateComplete.length - 1; i >= 0; i--) {
					// if function not exist yet - delete it
					if (typeof subscribeFunctions_onUpdateComplete[i] === "undefined") {
						// delete method from array
						subscribeFunctions_onUpdateComplete.splice(i, 1);
						continue;
					}
					// call function with context NULL
					subscribeFunctions_onUpdateComplete[i].call();
				}
            }
		}
	})();

	window.UpdatePageDataManager = UpdatePageDataManager;
	UpdatePageDataManager.Init();
})(window);

var inUpdatePage = 0;

function call_topo_update(mode){
    timer_running = 0;
    //alert("topo graph update");
    TopoUpdateCheck(mode);
    setTimeout("start_update()", update_rate);
}

var update_rate = 0;
var timer_running = 0;

function start_update() {

    if (update_rate && !timer_running)
    {
        timer_running = 1;
        /*
        if(url_to_update.search(/PriNav=Start/) != -1)
        {
            setTimeout("updateStartPage()", update_rate);
        }
        else*/ if(url_to_update.search(/PriNav=Topo&SecNav=TopoGraph/) != -1)
        {
            call_topo_update("TopoGraphUpdate");
        }
        else if(url_to_update.search(/PriNav=Topo&SecNav=TopoBrief/) != -1)
        {
            call_topo_update("TopoBriefUpdate");
        }
        else if(url_to_update.search(/PriNav=Topo&SecNav=TopoTable/) != -1)
        {
            call_topo_update("TopoTableUpdate");
        }
        else
        {
            setTimeout("call_update()", update_rate);
        }
    }
}

function call_update() {
    timer_running = 0;
    if (!update_rate) return;
    // auf dem Client: Aufruf des Servers mit Wunsch nach neuen Daten
    // replace aendert history nicht, damit funktioniert der Back-Button noch
    // &ts anhaengen, um nicht im cache zu landen, TBD vorsicht, falls schon ?parameter an der URL sind
	// add "&ts" before hash (befor "#" sign if it exist)
    
	// get hash in URL if it exist
	var hash = /\#/i.test(url_to_update) == true ? url_to_update.replace(/.*?#/,"#") : "";
	
	// get URL without hash
	var urlplusparam = url_to_update.replace(/#.*/,"");
	
	// add a parameter to new URL
	var r = Math.random();
	urlplusparam += (/\?/i.test(urlplusparam) == true ? "&r=" : "?r=") + r;
	
	// add hash to new URL 
	if(hash != ""){
		urlplusparam += hash;
	}
	
    frames['server_frame'].location.replace(urlplusparam);
    //frames['server_frame'].location.replace(url_to_update);
}

function do_update() {
    if (!parent.update_interval) return;
    top.doUpdate = 1;
    // find all update divs and copy them to main page
    var a;
    var url;

    url = document.location.href;
    
    // update within frames 
    var iframes = document.getElementsByTagName("iframe");
    for(var ifr_count=0; ifr_count < iframes.length;ifr_count++){
      a = window.frames[iframes[ifr_count].name].document.getElementsByTagName("div");
      for (var i=0; i < a.length; i++) {
        if (hasCSSClass(a[i], "updatable")) {
          var id = a[i].id;
          var text = window.frames[iframes[ifr_count].name].document.getElementById(id).innerHTML;
          // When ident in module information is selected and state is loaded in the update page
          if(parent.frames[iframes[ifr_count].name].document.getElementById(id))
          {
             url = document.location.href;

             parent.frames[iframes[ifr_count].name].document.getElementById(id).innerHTML = text;
             if (url.search(/PriNav=Alarm/) != -1) 
             {
               if(parent.frames[iframes[ifr_count].name].sortables_init_fb_update != undefined)
               {
            	   parent.frames[iframes[ifr_count].name].sortables_init_fb_update(); 
               }
             }
          }
        }
      } // end for
    }
    
    a = document.getElementsByTagName("div");
    for (var i=0; i < a.length; i++) {
        if (hasCSSClass(a[i], "updatable")) 
        {
            var id = a[i].id;
            parent.$("#" + id)[0].innerHTML = $("#" + id)[0].innerHTML;
        }
    } // end for
    if ((url.search(/PriNav=Filebrowser/) != -1 ) ||
        (url.search(/PriNav=DataLogs/) != -1) ||
        (url.search(/PriNav=UserFiles/) != -1)) {
      if (parent.sortables_init_fb_update != undefined) {
        parent.sortables_init_fb_update();
      }
    }

    // Subframe Bgz/Alarm/Diag
    var subfr;
    if(window.frames.length>=2){
        // Bgz/Alarm/Diag Content
      if(window.frames[1].frames.length>=1)
      {  
        subfr = window.frames[1].frames[0];
        a = subfr.document.getElementsByTagName("div");
            for(var i=0; i < a.length; i++){
              if (hasCSSClass(a[i], "updatable")) {
                var id = a[i].id;
                var text = subfr.document.getElementById(id).innerHTML;
                if(parent.frames[1].frames[0] != undefined)
                {
                   if(parent.frames[1].frames[0].document.getElementById(id))
                   {
                      parent.frames[1].frames[0].document.getElementById(id).innerHTML = text;
                   }
                }
              }
            }  // end for
      } // end if
    }
    top.doUpdate = 0;
    parent.start_update();
	parent.UpdatePageDataManager.CallSubscribeFunctions();
}

function update_on() {
    var e;
    e = $("#dynamic_link")[0];
    e.innerHTML = parent.update_phrase_on;
    e.onclick = update_off;
    update_rate = parent.update_interval;
    start_update();
}
function update_off() {
    var e;
    e = $("#dynamic_link")[0];
    e.innerHTML = parent.update_phrase_off;
    update_rate = 0;
    e.onclick = update_on;
}

function updateStartPage()
{
    if (!update_rate || url_to_update.search(/PriNav=Start/) == -1)
    {
        return;
    }

    var url = "/Startpage/Startpage.json";
    $.ajax(
    {
        url: url,
        cache: false,
        dataType: "json",
        success: function(json)
        {
            $('#time').html(json.Time);
            $('#date').html(json.Date);
            $('#startpage_projectname_value').html(json.data.ProjectName);
            $('#startpage_tiaportalversion_value').html(json.data.TIAPortal);
            $('#startpage_stationname_value').html(json.data.StationName);
            $('#startpage_modulename_value').html(json.data.DeviceName);
            $('#startpage_moduletype_value').html(json.data.ModuleType);
            $('#startpage_operatingmode_value').html(json.data.OperatingMode);
            $('#startpage_status_id').html(json.data.Status)
            $('#startpage_status_image').attr('src', "../Icons/" + json.data.StatusImage);
            $('#startpage_modeselector_value').html(json.data.ModeSelector);

            $('#DISPLAY_STATUS').html(json.data.OperatingMode);
            $('#DISPLAY_CPU_NAME').html(json.data.ModuleType);
            $('#DISPLAY_CPU_MLFB').html(json.data.MLFB);
            displayCPUState(json.data.OperatingMode, json.data.ModeSelector);
        
            if (json.permissions.ShowLock)
            {
                $('#startpage_lock_row').show();
            }
            else
            {
                $('#startpage_lock_row').hide();
            }

            if (json.permissions.ShowFParameters)
            {
                $('#startpage_safetymode_value').html(json.data.SafetyMode);
                $('#startpage_overallsignature_value').html(json.data.OverallSignature);
                $('#startpage_lastmodification_value').html(json.data.LastModificationDate + " " + LastModificationTime);
            }
            else
            {
                $('#startpage_safetymode_value').html("");
                $('#startpage_overallsignature_value').html("");
                $('#startpage_lastmodification_value').html("");
            }
            
            for(var i = 0; i < max_leds; i++)
            {
                if (leds[i][3])
                {
                    leds[i][1] = leds[i][3];
                    leds[i][2] = null;
                    leds[i][3] = null;
                }
            }
            update_leds();
        }
    });

    setTimeout("updateStartPage()", update_rate);
}

function createFrame() {
    var i;
    i = document.createElement("iframe");
    i.setAttribute("id", "server_frame");
    i.setAttribute("name", "server_frame");
    //i.setAttribute("src","../ClientArea/Dummy.mwsl");
    i.style.width = "0px";
    i.style.height = "0px";
    i.style.top = "0px";
    i.style.left = "-2000px";
    i.style.position = "absolute";
    document.body.appendChild(i);
}

var max_leds = 20;
var current_index = 0;
var leds = new Array(max_leds);
var ledindex = 0;

for(var a=0;a<max_leds; a++)
{
    leds[a] = new Array(4);
    leds[a][0] = null;
    leds[a][1] = null;
    leds[a][2] = null;
    leds[a][3] = null;
    leds[a][4] = null;
}

function register_led(id, src, blink1, blink2, path)
{
    if(window == top.server_frame)
    {
        parent.leds[current_index][0] = id;
        parent.leds[current_index][1] = src;
        parent.leds[current_index][2] = blink1;
        parent.leds[current_index][3] = blink2;
        parent.leds[current_index][4] = path;
    }
    else
    {
        leds[current_index][0] = id;
        leds[current_index][1] = src;
        leds[current_index][2] = blink1;
        leds[current_index][3] = blink2;
        leds[current_index][4] = path;
    }
    
    current_index++;
}

function update_leds()
{
    if(location.href.search("PriNav=Start") != -1)
    {
        var ledObject;
        var className;
        
        for(var i = 0; i < max_leds; i++)
        {
            if($("#" + leds[i][0]).length > 0)
            {
                ledObject = $("#" + leds[i][0])[0];
                if(leds[i][2] != null)
                {
                   if((ledObject.className.search(leds[i][2])) != -1)
                   {
                       className = leds[i][3];
                   }
                   else if((ledObject.className.search(leds[i][3])) != -1)
                   {
                       className = leds[i][2];
                   }
                   else
                   {
                       className = leds[i][2];
                   }
                }
                else
                {
                   className = leds[i][1];
                }
                
                //console.log("Setting className of '" + ledObject.id + "' to '" + className + "'");
                ledObject.className = className;
            }
        }

        setTimeout("update_leds()", 250);
    }
}

function hasCSSClass(element, className)
{
    return (" " + element.className + " ").indexOf(" " + className + " ") > -1;
}
